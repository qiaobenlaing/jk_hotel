<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2018/8/21
 * Time: 15:57
 */

namespace Org\Util;

// 文件上传类
class NetUpfile{

    // 取得服务器根名录
    public function getURL(){
        return str_replace("index.php","",$_SERVER["SCRIPT_NAME"]);
    }


    //传入字符取得远程文件地址
    public function getimages($str){
        $match_str = "/((http:\/\/)+([^ \r\n\(\)\^\$!`\"'\|\[\]\{\}<>]*)((.gif)|(.jpg)|(.bmp)|(.png)|(.GIF)|(.JPG)|(.PNG)|(.BMP)))/";
        preg_match_all ($match_str,$str,$out,PREG_PATTERN_ORDER);
        return $out;
    }

    //取文件的扩展名
    public function getextension($filename){
        return substr(strrchr($filename,"."),1);
    }

    //重命名文件名称
    public function getnewname($file){
        $ext = self::getextension($file);
        $newname = md5(mac_rand(4).time().get_client_ip()).".".$ext;
        return $newname;
    }


    //传入文章内容保存远程文件和替换的图片连接
    function upLoadFile($str,$path="."){
        $htm = $str;
        //传入内容取得图片连接地址数组
        $img = self::getimages($htm);

        set_time_limit(1200);

        $sServerDir = $path;
        if(!file_exists($sServerDir)){mkdir($sServerDir);}//如果用户指定的文件不存在则创建一个

        $sServerDir .= date("Ym")."/";
        if(!file_exists($sServerDir)){mkdir($sServerDir);}//如果用户指定的文件不存在则创建一个

        //保存文件
        for($i=0;$i<count($img[0]);$i++){
            $fileUrl = $img[0][$i];

            //取得远程图片
            $data = join(file($fileUrl));
            //取得远程图片保存到本地名称

            $newname = self::getnewname($fileUrl);

            //把图片保存到本地硬盘
            $temp_data = fopen($sServerDir.$newname,"w");

            fwrite($temp_data,$data);

            fclose($temp_data);

            flush();
            $htm = str_replace($fileUrl,self::getURL().$sServerDir.$newname,$htm);

            $waterImage = $path.$logo;
        }
        return $htm;
    }


    /**
    + base64 to images
    +------------------------------------------
    + @param base64	图片 base64位代码
     */
    public function base64ToImages($base64 = ""){

        // 允许上传得mini类型

        $mini['data:image/png']			= ".png";
        $mini['data:image/jpeg']		= ".jpg";

        //返回路径
        $path = "";

        $base64Arr = explode(";base64,",$base64);

        if(strlen($mini[$base64Arr[0]]) > 0){

            //创建文件保存路径
            $catalog = toDate(time(),"Ym");
            $sServerDir = C("savePath");
            if(!file_exists($sServerDir)){mkdir($sServerDir);}

            $sServerDir = C("savePath").$catalog."/";
            if(!file_exists($sServerDir)){mkdir($sServerDir);}

            // 生成上传文件名
            $path = $sServerDir.$_SESSION['user_name']."_".rand(100,999)."_".microtime(true).$mini[$base64Arr[0]];


            // 保存图片
            $s = base64_decode($base64Arr[1]);

            file_put_contents($path, $s);

            // 返回绝对路径地址
            if(substr($path,0,1) != "/"){
                $path = "/".$path;
            }

        }else{
            if(strlen($base64 ) > 0 && strlen($base64 ) < 200){
                $path = $base64;
            }
        }

        return $path;

    }

}