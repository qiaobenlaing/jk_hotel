<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK IT ]
// +----------------------------------------------------------------------
// | Copyright (c) 2009 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------
// $Id$

/**
+------------------------------------------------------------------------------
 * DirectoryIterator实现类 PHP5以上内置了DirectoryIterator类
+------------------------------------------------------------------------------
 * @category   ORG
 * @package  ORG
 * @subpackage  Io
 * @author    liu21st <liu21st@gmail.com>
 * @version   $Id$
+------------------------------------------------------------------------------
 */
namespace Org\Util;
class Dir
{//类定义开始

    private $_values = array();
    /**
    +----------------------------------------------------------
     * 架构函数
    +----------------------------------------------------------
     * @access public
    +----------------------------------------------------------
     * @param string $path  目录路径
    +----------------------------------------------------------
     */
    function __construct($path,$pattern='*')
    {
        if(substr($path, -1) != "/")    $path .= "/";
        $this->listFile($path,$pattern);
    }

    /**
    +----------------------------------------------------------
     * 取得目录下面的文件信息
    +----------------------------------------------------------
     * @access public
    +----------------------------------------------------------
     * @param mixed $pathname 路径
    +----------------------------------------------------------
     */
    function listFile($pathname,$pattern='*')
    {
        static $_listDirs = array();
        $guid	=	md5($pathname.$pattern);
        if(!isset($_listDirs[$guid])){
            $dir = array();
            $list	=	glob($pathname.$pattern);
            foreach ($list as $i=>$file){
                $dir[$i]['filename']    = basename($file);
                $dir[$i]['pathname']    = realpath($file);
                $dir[$i]['owner']        = fileowner($file);
                $dir[$i]['perms']        = fileperms($file);
                $dir[$i]['inode']        = fileinode($file);
                $dir[$i]['group']        = filegroup($file);
                $dir[$i]['path']        = dirname($file);
                $dir[$i]['atime']        = fileatime($file);
                $dir[$i]['ctime']        = filectime($file);
                $dir[$i]['size']        = filesize($file);
                $dir[$i]['type']        = filetype($file);
                $dir[$i]['ext']      =  is_file($file)?strtolower(substr(strrchr(basename($file), '.'),1)):'';
                $dir[$i]['mtime']        = filemtime($file);
                $dir[$i]['isDir']        = is_dir($file);
                $dir[$i]['isFile']        = is_file($file);
                $dir[$i]['isLink']        = is_link($file);
                //$dir[$i]['isExecutable']= function_exists('is_executable')?is_executable($file):'';
                $dir[$i]['isReadable']    = is_readable($file);
                $dir[$i]['isWritable']    = is_writable($file);
            }
            $cmp_func = create_function('$a,$b','
			$k  =  "isDir";
			if($a[$k]  ==  $b[$k])  return  0;
			return  $a[$k]>$b[$k]?-1:1;
			');
            // 对结果排序 保证目录在前面
            usort($dir,$cmp_func);
            $this->_values = $dir;

            $_listDirs[$guid] = $dir;
        }else{
            $this->_values = $_listDirs[$guid];
        }
    }

    // 返回目录的数组信息
    function toArray() {
        return $this->_values;
    }

}//类定义结束

if(!class_exists('DirectoryIterator')) {
    class DirectoryIterator extends Dir {}
}
?>