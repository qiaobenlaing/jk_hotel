<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/6/23
 * Time: 11:28
 */

namespace Org\Util;

define("FASTDFS_PUBLIC_CLUSTER", 1);

/*
 * FDFSClient
 */

class FDFS
{

    function uploadByFileName($uploadFilePath = "", $extension, $typeFlag = FASTDFS_PUBLIC_CLUSTER)
    {
        $retData = array();
        $FDFSHaldler = new FastDFS($typeFlag);
        $trackerServer = $FDFSHaldler->tracker_get_connection();
        $storageServer = $FDFSHaldler->tracker_query_storage_store();

        if (!empty($storageServer)) {
            $storageServer['store_path_index'] = 1;
        }
        $fileInfo = $FDFSHaldler->storage_upload_by_filename($uploadFilePath, $extension, [], null, $trackerServer, $storageServer);
        if ($fileInfo)
            $retData = array('retCode' => 1, 'errMsg' => 'success', 'data' => $fileInfo);
        else
            $retData = array('retCode' => $FDFSHaldler->get_last_error_no(), 'errMsg' => $FDFSHaldler->get_last_error_info(), 'data' => '');
        $FDFSHaldler->tracker_close_all_connections();
        return $retData;
    }

    function uploadSlaveFile($masterFileID = '', $slaveFileName = '', $typeFlag = FASTDFS_PUBLIC_CLUSTER)
    {
        $retData = array();
        $FDFSHaldler = new FastDFS($typeFlag);
        $slaveFileID = $FDFSHaldler->storage_upload_slave_by_filename1($slaveFileName, $masterFileID, NULL, NULL);
        if ($slaveFileID)
            $retData = array('retCode' => 1, 'errMsg' => 'sucess', 'data' => $slaveFileID);
        else
            $retData = array('retCode' => $FDFSHaldler->get_last_error_no(), 'errMsg' => $FDFSHaldler->get_last_error_info(), 'data' => $slaveFileName);
        $FDFSHaldler->tracker_close_all_connections();
        return $retData;
    }

    function deleteFile($fileID = "", $typeFlag = FASTDFS_PUBLIC_CLUSTER)
    {
        $retData = array();
        if (Empty($fileID) || len($fileID) < FDFSFILEIDMINLEN) {
            $retData = array('retCode' => -1, 'errMsg' => 'fildID invalid', 'data' => $fileID);
            return $retData;
        }
        $FDFSHaldler = new FastDFS($typeFlag);
        $fileInfo = $FDFSHaldler->storage_delete_file1($fileID);
        if ($fileInfo)
            $retData = array('retCode' => 1, 'errMsg' => 'success', 'data' => $fileInfo);
        else
            $retData = array('retCode' => get_last_error_no(), 'errMsg' => get_last_error_info(), 'data' => '');
        $FDFSHaldler->tracker_close_all_connections();
        return $retData;
    }

    function multiDeleteFile($fileIDArray = array(), $typeFlag = FASTDFS_PUBLIC_CLUSTER)
    {
        $FDFSHaldler = new FastDFS($typeFlag);
        $retData = array();
        $errorData = array();
        $successData = array();
        $len = count($fileIDArray);
        $errorFlag = False;
        for ($i = 0; $i < $len; $i++) {
            $fileInfo = $FDFSHaldler->storage_delete_file1($fileIDArray[$i]);
            if ($fileInfo)
                $successData = array_push($successData, array('retCode' => 1, 'errMsg' => 'success', 'para' => $fileIDArray[$i], 'data' => $fileInfo));
            else {
                $errorFlag = True;
                $successData = array_push($successData, array('retCode' => $FDFSHaldler->get_last_error_no(), 'errMsg' => $FDFSHaldler->get_last_error_info(), 'para' => $fileIDArray[$i], 'data' => ''));
            }
        }
        if (!$errorFlag) {
            $retData = array('retCode' => 1, 'errMsg' => 'success', 'data' => $successData);
        } else
            $retData = array('retCode' => 0, 'errMsg' => 'error', 'data' => $successData);

        $FDFSHaldler->tracker_close_all_connections();
        return $retData;
    }

    function multiUploadByFileNameArray($fileNameArray = array(), $type = FASTDFS_PUBLIC_CLUSTER)
    {
        $FDFSHaldler = new FastDFS($type);
        $retData = array();
        $errorData = array();
        $successData = array();
        $len = count($fileNameArray);
        $errorFlag = False;
        for ($i = 0; $i < $len; $i++) {
            $fileInfo = $FDFSHaldler->storage_upload_by_filename1($fileNameArray[$i]);
            if ($fileInfo)
                $successData = array_push($successData, array('retCode' => 1, 'errMsg' => 'success', 'para' => $fileNameArray[$i], 'data' => $fileInfo));
            else {
                $errorFlag = True;
                $successData = array_push($successData, array('retCode' => $FDFSHaldler->get_last_error_no(), 'errMsg' => $FDFSHaldler->get_last_error_info(), 'para' => $fileNameArray[$i], 'data' => ''));
            }
        }
        if (!$errorFlag) {
            $retData = array('retCode' => 1, 'errMsg' => 'success', 'data' => $successData);
        } else
            $retData = array('retCode' => 0, 'errMsg' => 'error', 'data' => $successData);

        $FDFSHaldler->tracker_close_all_connections();
        return $retData;
    }

    function info($typeFlag = FASTDFS_PUBLIC_CLUSTER)
    {
        $FDFSHaldler = new FastDFS($typeFlag);
        $tracker = $FDFSHaldler->tracker_get_connection();
        var_dump($tracker);
        $server = $FDFSHaldler->connect_server($tracker['ip_addr'], $tracker['port']);
        var_dump($server);
        var_dump($FDFSHaldler->disconnect_server($server));
        var_dump($FDFSHaldler->tracker_query_storage_store_list());
        var_dump($FDFSHaldler->active_test($tracker));
        $FDFSHaldler->tracker_close_all_connections();
    }
}
