<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/7/20
 * Time: 13:09
 */

namespace Common\Model;


class CommentModel extends BaseModel
{

    protected $tableName = 'comment';

    // 自动验证设置
    protected $_validate = array(
        array('hotel_id', 'require', '所属酒店必须设置！'),
        array('badge', 'require', '标签必须选择'),
        array('comment', 'require', '评论内容必须设置'),
        array('type', 'require', '评价等级必须设置'),
    );

    //自动填充设置
    protected $_auto = array(
        array('create_time', 'time', '1', 'function'),
    );

}
