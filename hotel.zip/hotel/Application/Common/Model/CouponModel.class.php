<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/7/17
 * Time: 13:15
 */

namespace Common\Model;


class CouponModel extends BaseModel
{
    protected $tableName = 'coupon';

    // 自动验证设置
    protected $_validate = array(
        array('coupon_name', 'require', '优惠券名称必须填写！'),
        array('coupon_type', 'require', '优惠券类型必须选择'),
        array('coupon_img', 'require', '优惠券背景图必须设置'),
        array('function', 'require', '优惠券功能必须说明'),
        array('expire_time', 'require', '优惠券过期时间必须设置'),
        array('start_taking_time', 'require', '优惠券开始领用时间'),
        array('end_taking_time', 'require', '最后可领取时间'),
        array('start_using_time', 'require', '优惠券可以开始使用的时间'),
        array('day_start_using_time', 'require', '每日开始使用时间'),
        array('day_end_using_time', 'require', '每日结束使用时间'),
    );

    //自动填充设置
    protected $_auto = array(
        array('create_time', 'time', '1', 'function'),
        array('update_time', 'time', '3', 'function'),
        array('create_admin', 'CheckAdmin', '3', 'callback'),
    );

    //检查管理员
    function CheckAdmin()
    {
        $admin = $_SESSION["username"];
        if (strlen($admin) > 4) {
            return $admin;
        } else {
            return "";
        }
    }

}
