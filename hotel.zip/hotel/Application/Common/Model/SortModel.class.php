<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/4/14
 * Time: 11:01
 */

namespace Common\Model;


class SortModel extends BaseModel
{
    protected $tableName = 'sort';

    // 自动验证设置
    protected $_validate	 =	 array(
        array('title','require','分类名称必须填写！'),
        array('content','require','分类内容必须填写！'),
    );

    //自动填充设置
    protected $_auto	 =	 array(
        array('create_time','time','1','function'),
        array('update_time', 'time', '2', 'function'),
        array('create_admin','CheckAdmin','3','callback'),
    );

    //检查管理员
    function CheckAdmin(){
        $admin = $_SESSION["username"];
        if(strlen($admin)>4){
            return $admin;
        }else{
            return "";
        }
    }
}
