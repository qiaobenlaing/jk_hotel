<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/4/13
 * Time: 12:52
 */

namespace Common\Model;

class CityModel extends BaseModel
{
    protected $tableName = 'city';
    // 自动验证设置
    protected $_validate = array(
        array('city_name', 'require', '城市名称必须填写！'),
        array('city_name', '', '城市名称已存在！', 1, 'unique', '1'), // 在新增的时候验证activity_name字段是否唯一
        array('bg_img', 'require', '图片必须上传！'),
    );

}
