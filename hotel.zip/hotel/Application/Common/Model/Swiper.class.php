<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/4/13
 * Time: 12:05
 */

namespace Common\Model;


class Swiper extends BaseModel
{
    protected $tableName = 'swiper';

    public function getSwiperList(){
        return $this->order('create_time')->field('title,url,img')->select();
    }

}
