<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/5/9
 * Time: 13:07
 */

namespace Common\Model;


use function PHPSTORM_META\type;

class OrderModel extends BaseModel
{
    protected $tableName = 'order';


    /** 如果用户想订昨天的房间
     * @param $roomIn 入住日期
     * @return array 返回结果
     */
    public function preRoomLastDay($roomIn, $roomId)
    {
        $roomModel = new RoomModel();
        $hotelInfo = $roomModel->alias('R')->where(array('R.id' => $roomId))->join('tns_hotel as H ON R.hotel_id=H.id')->field('H.sold_end_time,H.sold_time_type')->find();
        $now_time = date("H:i:s", time());
        $sold_end_time = $hotelInfo['sold_end_time'];
        $last_date = date("Y-m-d", (time() - 3600 * 24)); //当前日期的前一天
        $now_date = date("Y-m-d", time());
        $next_date = date("Y-m-d", (time() + 3600 * 24)); //当前日期的下一天
        if ($hotelInfo['sold_time_type'] == 1) {
            if ($roomIn < $now_date) {
                return $this->returnJson(array('code' => \Consts::PARAMES_ERROR, 'message' => '最早只能预定' . $now_date));
            }
            if ($sold_end_time < $now_time) {
                return $this->returnJson(array('code' => \Consts::PARAMES_ERROR, 'message' => '当日的售卖时间已过'));
            }
        } elseif ($hotelInfo['sold_time_type'] == 2) {
            if ($roomIn == $last_date) {
                if ($sold_end_time < $now_time) {
                    return $this->returnJson(array('code' => \Consts::PARAMES_ERROR, 'message' => '最早只能在' . $sold_end_time . '之前预定' . $last_date));
                }
            } elseif ($roomIn < $last_date) {
                return $this->returnJson(array('code' => \Consts::PARAMES_ERROR, 'message' => '最早只能预定' . $last_date));
            }
        }
        return $this->returnJson(array('code' => \Consts::REQUEST_SUCCESS));
    }

    /** 判断是否可预订
     * @param $roomIn 入住日期
     * @param $roomOut 离店日期
     * @param $roomId 房型编号
     * @param $dayRoomType 房态类型
     * @param $is_breakfast 是否有早
     * @param $bed_type 床型
     * @param $refund_state 退订状态
     * @param $refund_remark 退订说明
     * @return mixed 返回结果状态
     */
    public function isCanBuy($roomIn, $is_breakfast, $bed_type, $refund_state, $refund_remark, $roomOut, $roomId, $dayRoomType, $sold_rule_id)
    {

        $last_room_out = date("Y-m-d", (strtotime($roomOut) - 3600 * 24)); //离店日期的前一天
        $preDayNum = dateNum($roomIn, $last_room_out); //返回时间段的日期数组(实际的预定天数范围)

        //判断星期及天数
        $weekarray = array(7, 1, 2, 3, 4, 5, 6);
        $soldRuleModel = new SoldRuleModel();
        $soldRuleInfo = $soldRuleModel->where(array('id' => $sold_rule_id))->find();
        $even_start_week = $weekarray[date('w', strtotime($roomIn))];
        $even_end_week = $weekarray[date('w', (strtotime($last_room_out)))];

        //判断是否连住
        if ($soldRuleInfo['is_even_live'] == 1) {
            //判断连住天数是否正确
            if (count($preDayNum) != $soldRuleInfo['even_live_num']) {
                return $this->returnJson(array('code' => \Consts::PARAMES_ERROR, 'message' => '预定天数和连住天数不符'));
            }
            if ($soldRuleInfo['week_set'] == 1) {
                if ($soldRuleInfo['even_week_start'] != $even_start_week || $soldRuleInfo['even_week_end'] != $even_end_week) {
                    return $this->returnJson(array('code' => \Consts::PARAMES_ERROR, 'message' => '入住日期和离店日期不符合连住要求'));
                }
            }
        }

        $roomStateModel = new RoomStateModel();
        $list = $roomStateModel->where(array('room_id' => $roomId, 'is_breakfast' => $is_breakfast, 'bed_type' => $bed_type,
            'refund_state' => $refund_state, 'day_room_type' => $dayRoomType, 'refund_remark' => $refund_remark,
            'sold_rule_id' => $sold_rule_id, 'date' => array('between', array($roomIn, $last_room_out))
        , 'state' => '1'))->select();

        if (count($list) != count($preDayNum)) {
            return $this->returnJson(array('code' => \Consts::PARAMES_ERROR, 'message' => '该时间段无可定房间'));
        } else {
            return $this->returnJson(array('code' => \Consts::REQUEST_SUCCESS, 'list' => $list, 'preDayNum' => $preDayNum));
        }
    }

    /** 判断是否能卖
     * @param $roomId 房型编号
     * @param $dayRoomType 房态类型
     * @return array 返回结果状态
     */
    public function isOutSold($ids, $dayRoomType)
    {
        $roomstateModel = new RoomStateModel();
        $out_sold = 2; //未超卖
        $sold_count = $roomstateModel->where(array('id' => array('IN', $ids)))->field(array('inventory', 'hotel_id',
            'index_day_price', 'is_out_sold', 'out_sold_count', 'day_sold_count'))->find();

        if ($sold_count['is_out_sold'] == 1) {
            $sold_total_count = $sold_count['inventory'] + $sold_count['out_sold_count'];
            if ($sold_count['day_sold_count'] >= $sold_total_count) {
                return $this->returnJson(array('code' => \Consts::PARAMES_ERROR, 'message' => '该房型已售完'));
            } elseif ($sold_count['day_sold_count'] >= $sold_count['inventory']) {
                $out_sold = 1; //超卖了
            }
        } else {
            if ($sold_count['day_sold_count'] >= $sold_count['inventory']) {
                return $this->returnJson(array('code' => \Consts::PARAMES_ERROR, 'message' => '该房型已售完'));
            }
        }
        return $this->returnJson(array('code' => \Consts::REQUEST_SUCCESS, 'out_sold' => $out_sold, 'sold_count' => $sold_count));
    }

    /** 计算总金额
     * @param $list 房态日历列表
     * @param $roomNum 预定的天数
     * @param $live 可住人数
     * @param $roomId 房型编号
     * @param $preDayNum 预定天数
     * @return array 返回指数和人民币数组
     */
    public function totalMoney($list, $userId, $is_use_coupon, $coupon_code, $roomNum, $roomId, $sold_rule_id, $is_index, $token)
    {
        //1.酒店的置换费，置换费只能使用元宝支付
        $roomModel = new RoomModel();
        $hotel_replace_type = $roomModel->where(array('R.id' => $roomId))->alias('R')
            ->join('tns_hotel as H ON H.id=R.hotel_id')->field('H.id,H.replace_money,H.room_money_type,H.hotel_type')->find();
        $replace_money = $hotel_replace_type['replace_money']; //置换费
        $hotel_type = $hotel_replace_type['hotel_type']; //酒店的定价方式
        $room_money_type = json_decode($hotel_replace_type['room_money_type'], true);//酒店的支付方式

        //2.售卖规则
        $sold_rule = D('sold_rule')->where(array('room_id' => $roomId, 'id' => $sold_rule_id))->find();

        if ($sold_rule['is_even_live'] == 1) {
            $totalBeforeZhi = $sold_rule['room_money'] * $roomNum;
            $totalBeforeRMB = $sold_rule['room_money_rmb'] * $roomNum;
        } else { //不连住，要计算用户的实际天数
            $not_even_live = count($list);
            $totalBeforeZhi = $sold_rule['room_money'] * $roomNum * $not_even_live;
            $totalBeforeRMB = $sold_rule['room_money_rmb'] * $roomNum * $not_even_live;
        }

        //3.使用优惠券
        $couponMoney = $this->couponMoney($is_use_coupon, $coupon_code, $roomId, $userId, $list, $sold_rule, $totalBeforeRMB, $totalBeforeZhi);
        if ($couponMoney['code'] != \Consts::REQUEST_SUCCESS) {
            return $couponMoney;
        }
        $discount_info = $couponMoney['discount_info'];  //优惠详情

        //现在应付的房费
        $totalmoneyZhi = $couponMoney['totalmoneyZhi'];
        $totalmoneyRMB = $couponMoney['totalmoneyRMB'];

        $discount_money_rmb = $couponMoney['discount_money_rmb'];
        $discount_money = $couponMoney['discount_money'];

        //4.是否使用指数
        if ($is_index == 1) {
            $totalBeforeRMB = 0;
            $totalmoneyRMB = 0;
            $discount_money_rmb = 0;
        } else {
            $totalBeforeZhi = 0;
            $totalmoneyZhi = 0;
            $discount_money = 0;
        }

        return array(
            'code' => \Consts::REQUEST_SUCCESS,
            'total_before_money' => $totalBeforeZhi,
            'total_before_money_rmb' => $totalBeforeRMB,
            'total_money' => $totalmoneyZhi,
            'total_money_rmb' => $totalmoneyRMB,
            'pay_type' => $room_money_type,
            'hotel_type' => $hotel_type,
            'hotel_id' => $hotel_replace_type['id'],
            'extend_price' => $sold_rule['extend_price'],
            'replace_money' => $replace_money,
            'vip_discount_money' => 0,
            'discount_money_rmb' => $discount_money_rmb,
            'discount_money' => $discount_money,
            'discount_info' => json_encode($discount_info, JSON_UNESCAPED_UNICODE),
        );
    }

    //优惠券优惠
    public function couponMoney($is_use_coupon, $couponArr, $roomId, $userId, $list, $sold_rule, $totalBeforeRMB, $totalBeforeZhi)
    {
        //优惠前房费总金额
        $totalmoneyZhi = $totalBeforeZhi;
        $totalmoneyRMB = $totalBeforeRMB;
        if ($is_use_coupon == 1) {
            $couponModel = new CouponModel();
            $couponList = $couponModel->alias('C')->where(array('UC.id' => array('IN', $couponArr),
                'UC.user_id' => $userId, 'UC.status' => '1'))
                ->join('tns_usercoupon as UC ON UC.coupon_id=C.id')
                ->field('C.*,UC.start_using_time as uc_start_using_time,UC.expire_time as uc_expire_time')->select();
            if (!$couponList) {
                return array('code' => \Consts::PARAMES_ERROR, 'message' => '优惠券不存在或已使用');
            }

            //判断优惠券是否能使用
            //1.预定日期是否包含了不可住日期
            $dis_used_date = explode(",", $couponList[0]['dis_used_date']);
            foreach ($list as $item => $val) {
                if (in_array($val['date'], $dis_used_date)) {
                    return array('code' => \Consts::PARAMES_ERROR, 'message' => '预定时间包含不可订日期');
                }
            }
            //未到使用时间，已过期
            $start_using_time = $couponList[0]['uc_start_using_time'];
            $expire_time = $couponList[0]['uc_expire_time'];
            if ($start_using_time > time() || $expire_time < time()) {
                return array('code' => \Consts::PARAMES_ERROR, 'message' => '优惠券已过期或未到使用时间');
            }

            //2.适用范围判断
            $coupon_belonging = $couponList[0]['coupon_belonging'];
            $hotelRoomArr = explode(",", $couponList[0]['hotel_ids']);
            if ($coupon_belonging == 1) {
                if (!in_array($roomId, $hotelRoomArr)) {
                    return array('code' => \Consts::PARAMES_ERROR, 'message' => '该酒店房型不在优惠券的使用范围内');
                }
            }
            //3.判断可用数量
            $limited_nbr = $couponList[0]['limited_nbr'];
            if ($limited_nbr < count($couponArr)) {
                return array('code' => \Consts::PARAMES_ERROR, 'message' => '超过了每单的使用数量');
            }

            //间夜数
            $day_num = $couponList[0]['day_num'];
            $room_num = $couponList[0]['room_num'];

            $discount_money = 0;
            $discount_money_rmb = 0;

            if ($couponList[0]['coupon_type'] == \Consts::COUPON_TYPE_EXPRENCE) {
                $not_even_live = count($couponArr);
                $discount_money = round($sold_rule['room_money'] * $day_num * $room_num * $not_even_live / $sold_rule['even_live_num'], 2);
                $discount_money_rmb = round($sold_rule['room_money_rmb'] * $day_num * $room_num * $not_even_live / $sold_rule['even_live_num'], 2);
            } else if ($couponList[0]['coupon_type'] == \Consts::COUPON_TYPE_REBATE) {
                $discount_money_rmb = $couponList[0]['instead_price'];
            }
            $discount_info = array('title' => $couponList[0]['coupon_name'], 'discount_money_rmb' => $discount_money_rmb,
                'discount_money' => $discount_money, 'content' => $couponList[0]['function']);

            $totalmoneyRMB = $totalBeforeRMB - $discount_money_rmb;
            $totalmoneyZhi = $totalBeforeZhi - $discount_money;


            if ($totalmoneyRMB < 0) {
                $totalmoneyRMB = 0;
            }

            if ($totalmoneyZhi < 0) {
                $totalmoneyZhi = 0;
            }
        }
        return array('code' => \Consts::REQUEST_SUCCESS, 'totalmoneyRMB' => $totalmoneyRMB, 'totalmoneyZhi' => $totalmoneyZhi, 'discount_money' => $discount_money,
            'discount_money_rmb' => $discount_money_rmb, 'discount_info' => $discount_info);
    }


    //会员等级打折金额
    public function vipDiscountMoney($totalmoneyRMB, $userId, $is_index, $token, $room_money_type)
    {
        //发送请求
        $header = ['token:' . $token];
        //测试/生产
        $url = 'http://jk.huift.com.cn';
        if ($_SERVER['HTTP_HOST'] == 'link.jkljdj.com') {
            $url = 'https://link.jkljdj.com';
        }

        $result = $this->curlRequest($url . '/api/v1/account/getDiscount ', array(), true, 10, $header);
        $data = json_decode($result, true);

        $cashDiscount = $data['data']['cashDiscount']; //现金折扣
        $balaceDiscount = $data['data']['balaceDiscount']; //余额折扣
        $futureDiscount = $data['data']['futureDiscount']; //未来比折扣

        if ($is_index == 1) { //指数不打折
            $discount = 1;
        } else {
            if (in_array(2, $room_money_type)) {
                $discount = $balaceDiscount / 10;
            } elseif (in_array(3, $room_money_type)) {
                $discount = $futureDiscount / 10;
            }
        }

        $vipDiscountRMB = $totalmoneyRMB - $discount * $totalmoneyRMB;
        return array('totalmoneyRMB' => $totalmoneyRMB, 'vipDiscountRMB' => $vipDiscountRMB);
    }


}
