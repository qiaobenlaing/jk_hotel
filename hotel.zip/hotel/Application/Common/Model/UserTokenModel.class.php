<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/4/11
 * Time: 16:20
 */

namespace Common\Model;
class UserTokenModel extends BaseModel
{
    const VALID_TIME = 172800;  //48小时
    protected $tableName = 'user_token';

    /** 验证令牌
     * @param $requestTime 请求时间
     * @param $vcode
     * @param $method
     * @param $param
     * @return int|mixed
     */
    public function validateToken($requestTime, $vcode, $method, $param)
    {

        //判断是否缺少必需的参数$requestTime,
        if (empty($requestTime) || empty($vcode) || empty($method) || !isset($param)) {
            return \Consts::INVALID_PARAMS;
        }
        if (empty($method) || !isset($param)) {
            return \Consts::INTERNAL_ERROR;
        }

//        $token = 'b36938b6-4ce2-41bc-973e-14f7e26d652a';
        //发送请求
        $header = ['token:' . $vcode];

        //测试/生产
        $url = 'http://jk.huift.com.cn';
        if ($_SERVER['HTTP_HOST'] == 'link.jkljdj.com') {
            $url = 'https://link.jkljdj.com';
        }

        $result = $this->curlRequest($url . '/api/v1/user/getUserInfo', array(), true, 10, $header);
        $data = json_decode($result, true);


        if ($data['status'] != 'ok') {
            return C('INVALID_TOKEN');
        }

        $userModel = new UserModel();
        $res = $userModel->where(array('id' => $data['data']['id']))->find();

        if (!$res) {
            $userInfo['id'] = $data['data']['id'];
            $userInfo['card_no'] = $data['data']['cardNo'];
            $userInfo['head_img'] = $data['data']['photo'];
//            $userInfo['nickname'] = $data['data']['nickName'];
            $userInfo['username'] = $data['data']['name'];
            $userInfo['telphone'] = $data['data']['mobile'];
            $userInfo['openid'] = $data['data']['openId'];
            $userInfo['vip_level'] = $data['data']['vipLevel'];
            $userInfo['create_time'] = time();
            $userInfo['login_time'] = time();
            $userModel->add($userInfo);
        }

        return C('SUCCESS');
    }

    /**
     * 生成一个令牌
     * @param string $userCode 用户编码
     * @param string $registrationId
     * @return string 成功返回主键，失败返回错误信息
     */
    public function createToken($user_id)
    {
        $this->delToken($user_id);
        $user_token_code = $this->create_uuid();
        $token_code = md5(uniqid(mt_rand(), true));
        $expireTime = time() + self::VALID_TIME;
        return $this->add(array(
            'user_token_code' => $user_token_code,
            'token_code' => $token_code,
            'expire_time' => $expireTime,
            'user_id' => $user_id,
        )) ? $user_token_code : C('API_INTERNAL_EXCEPTION');
    }


    /**
     * 获取令牌
     * @param string $user_token_code 用户token编码
     * @return array $logInfo
     */
    public function getToken($user_token_code)
    {
        $logInfo = $this
            ->field(array('token_code', 'expire_time'))
            ->where(array('user_token_code' => $user_token_code))
            ->order('expire_time desc')
            ->find();
        return $logInfo;
    }


    /**
     * 销毁用户token
     * @param string $userCode
     * @return mixed
     */
    public function delToken($user_id)
    {
        return $this->where(array('user_id' => $user_id))->delete() !== false ? C('SUCCESS') : C('API_INTERNAL_EXCEPTION');
    }
}
