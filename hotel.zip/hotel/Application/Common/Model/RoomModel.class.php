<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/4/14
 * Time: 13:48
 */

namespace Common\Model;


class RoomModel extends BaseModel
{
    protected $tableName = 'room';

    // 自动验证设置
    protected $_validate = array(
        array('title', 'require', '房间名称必须填写！'),
        array('hotel_id', 'require', '所属酒店必须选择！'),
//        array('inventory', 'require', '库存量必须填写！'),
//        array('out_sold_inventory', 'require', '超卖库存量必须填写！'),
        array('bed_type', 'require', '房间床型必须填写！'),
        array('area', 'require', '房间面积必须填写！'),
        array('live', 'require', '可住人数必须填写！'),
        array('refund_remark', 'require', '政策说明必须填写！'),
        array('img', 'require', '房间主图必须上传！'),
        array('imgarr', 'require', '图片数组必须上传！'),
    );


    //自动填充设置
    protected $_auto = array(
        array('create_time', 'time', '1', 'function'),
        array('update_time', 'time', '3', 'function'),
        array('create_admin', 'CheckAdmin', '3', 'callback'),
    );

    //检查管理员
    function CheckAdmin()
    {
        $admin = $_SESSION["username"];
        if (strlen($admin) > 4) {
            return $admin;
        } else {
            return "";
        }
    }

}
