<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/4/12
 * Time: 11:39
 */

namespace Common\Model;


class UserModel extends BaseModel
{
    protected $tableName = 'user';


}
