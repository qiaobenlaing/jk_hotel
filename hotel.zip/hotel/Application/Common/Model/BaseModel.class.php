<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/4/12
 * Time: 11:33
 */

namespace Common\Model;


use Think\Model;

include_once 'Application/Common/Conf/const.php';
class BaseModel extends Model
{
    protected $autoCheckFields = false;

    public function returnJson($info)
    {
        if ($info['code'] == \Consts::REQUEST_SUCCESS) {
            return array_merge($info, array('result_code' => \Consts::REQUEST_SUCCESS, 'message' => $info['message'] == '' ? '请求接口成功' : $info['message']));
        } elseif ($info['code'] == \Consts::REQUEST_ERROR) {
            return array_merge($info, array('result_code' => \Consts::REQUEST_SUCCESS, 'message' => $info['message'] == '' ? '请求接口失败' : $info['message']));
        } else {
            return array_merge($info, array('result_code' => \Consts::PARAMES_ERROR, 'message' => $info['message']));
        }
    }

    function curlRequest($url, $params = array(), $is_post = false, $time_out = 10, $header = array())
    {
        $str_cookie = isset($ext_params['str_cookie']) ? $ext_params['str_cookie'] : '';
        $ch = curl_init();//初始化curl
        curl_setopt($ch, CURLOPT_URL, $url);//抓取指定网页
        curl_setopt($ch, CURLOPT_HEADER, 0);//设置是否返回response header
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);//要求结果为字符串且输出到屏幕上
        //当需要通过curl_getinfo来获取发出请求的header信息时，该选项需要设置为true
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, $time_out);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $time_out);
        curl_setopt($ch, CURLOPT_POST, $is_post);
        if ($is_post) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
        }
        if ($str_cookie) {
            curl_setopt($ch, CURLOPT_COOKIE, $str_cookie);
        }
        if ($header) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        }
        $response = curl_exec($ch);
        //打印请求的header信息
        $request_header = curl_getinfo($ch, CURLINFO_HEADER_OUT);
        curl_close($ch);
        return $response;
    }


    public function login($openid, $telphone, $username,$headImg='https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=209621737,1953850165&fm=26&gp=0.jpg')
    {

        $rules = array(
            array('usernmae','require','用户名不能为空'),
            array('openid', 'require','openid不能为空'),
            array('telphone', 'require','手机号不能为空'),
            array('telphone', 'number', '手机号格式输入错误'),
        );

        $userModel = new UserModel();
        $userInfo = $userModel->where(array('openid' => $openid, 'telphone' => $telphone))->field('id')->find();
        //判断用户是否存在
        if (!empty($userInfo)) {
            $data = array(
                'openid' => $openid,
                'username'=>$username,
                'telphone'=>$telphone,
                'head_img'=>$headImg,
                'remark'=>'一旦选择，就要坚定走下去',
                'nickname'=>'淡淡的忧伤',
                'create_time'=> time(),
            );

            if($userModel->validate($rules)->create($data)){
                $userTokenModel = new UserTokenModel();
                //更新用户登陆时间
                $userModel->setField(array('login_time'=>time()));
                //创建令牌
                $user_token_code =   $userTokenModel->createToken($userInfo['id']);
                //获取令牌信息
                $user_token_info = $userTokenModel->getToken($user_token_code);
            }


            return array(
                'code' => C('SUCCESS'),
                'expires_time' => $user_token_info['expire_time'],
                'token_code' => $user_token_info['token_code'],
                'user_id'=>$userInfo['id'],
            );

        }else{
            return array('code'=>400,'msg'=>'用户不存在');
        }
    }

    /**
     * 过滤掉无用的筛选条件，主要是过滤掉值为空的选项。
     * 如果给定pager，从where条件中剥离出pager。
     * @param array $where 带过滤的where条件: array(字段名, 值);
     * @param null $assembles 组装where条件。格式: array(字段名, 组装方式). <br/>
     *      组装方式可以为：like, likeStart, likeEnd, neq, gt, egt, lt, elt. <br/>
     *      like: 组装为： '字段名 LIKE %{$where[字段名]}%' <br/>
     *      likeStart: 组装为： '字段名 LIKE %{$where[字段名]}' <br/>
     *      likeEnd: 组装为： '字段名 LIKE {$where[字段名]}%' <br/>
     *      neq: 组装为： '字段名 <> {$where[字段名]}' <br/>
     *      gt: 组装为： '字段名 > {$where[字段名]}' <br/>
     *      egt: 组装为： '字段名 >= {$where[字段名]}' <br/>
     *      lt: 组装为： '字段名 < {$where[字段名]}' <br/>
     *      elt: 组装为： '字段名 <= {$where[字段名]}'
     * @param Pager $pager 从where条件中剥离出pager
     * @return array
     */
    protected function filterWhere($where, $assembles = null, &$pager = null) {
        // 首先过滤掉值为空的字段，以及Pager的字段
        if ($where) {
            foreach ($where as $field => $val) {
                if (empty($where[$field]) && $val !== '0') {
                    unset($where[$field]);
                }
            }
        }

        // 从where条件中剥离出pager
        if ($pager) {
            if ($where['page']) {
                $pager->setPage($where['page']);
            }
            if ($where['pageSize']) {
                $pager->setPageSize($where['pageSize']);
            }
        }
        unset($where['page']);
        unset($where['pageSize']);

        // 处理where条件：like, likeStart, likeEnd, neq, gt, egt, lt, elt。将默认为“=”的条件换成给定的条件。
        $allowedAssembles = array('like', 'likeStart', 'likeEnd', 'neq', 'gt', 'egt', 'lt', 'elt', 'not in');
        if (!empty($where) && !empty($assembles)) {
            foreach ($assembles as $field => $assemble) {
                if ($where[$field] !== null && $where[$field] !== '') {
                    if (in_array($assemble, $allowedAssembles)) { // 检查是否允许
                        switch ($assemble) {
                            case 'like':
                                $where[$field] = array('like', "%{$where[$field]}%");
                                break;
                            case 'likeStart':
                                $where[$field] = array('like', "%{$where[$field]}");
                                break;
                            case 'likeEnd':
                                $where[$field] = array('like', "{$where[$field]}%");
                                break;
                            default: // 其他的将直接组装即可
                                $where[$field] = array($assemble, $where[$field]);
                                break;
                        }
                    } else {
                        throw_exception('不合法的where字段组装类型.');
                    }
                }
            }
        }
        return $where != null ? $where : array();
    }

    /**
     * 将给定数组中的空值过滤出去，只保留非空值
     * @param array $data 待过滤的的数组。
     * @param string $fields 如果给定，只过滤这个数组中的键；否则清除所有空值。
     * @param string $isKeepZero true：0不被当作空值；false：0将被当作空值清除。
     * @return Model 返回model本身
     */
    protected function filterEmpty(&$data, $fields = null, $isKeepZero = false) {
        foreach ($data as $key => $val) {
            if (empty($val) && (!$isKeepZero || $val != 0) && (!$fields || in_array($key, $fields))) {
                unset($data[$key]);
            }
        }
        return $this;
    }

    /**
     * PHP生成 uuid 唯一标识码
     * @param string $prefix
     * @return string
     */
    public function create_uuid($prefix = ""){    //可以指定前缀
        $str = md5(uniqid(mt_rand(), true));
        $uuid  = substr($str,0,8) . '-';
        $uuid .= substr($str,8,4) . '-';
        $uuid .= substr($str,12,4) . '-';
        $uuid .= substr($str,16,4) . '-';
        $uuid .= substr($str,20,12);
        return $prefix.$uuid;
    }

}
