<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/7/14
 * Time: 11:43
 */

namespace Common\Model;


class SoldRuleModel extends BaseModel
{
    public $tableName = 'sold_rule';

    // 自动验证设置
    protected $_validate = array(
        array('sold_title', 'require', '售卖规则名称必须填写！'),
        array('even_live_num', 'require', '连住天数必须填写！'),
        array('extend_price','require','酒店对外价格（人民币）必须填写！'),
    );

}
