<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/4/13
 * Time: 13:34
 */

namespace Common\Model;


class HotelModel extends BaseModel
{
    protected $tableName = 'hotel';

    // 自动验证设置
    protected $_validate = array(
        array('title', 'require', '酒店名称必须填写！'),
        array('title', '', '酒店名称已存在！', 1, 'unique', '1'), // 在新增的时候验证title字段是否唯一
        array('hotel_type', 'require', '酒店定价方式必须选择！'),
        array('index_day_price','require','酒店指数间夜单价'),
        array('sold_start_time', 'require', '开始售卖时间必须设置！'),
        array('sold_end_time', 'require', '结束售卖时间必须设置！'),
        array('city', 'require', '酒店所属城市必须选择！'),
        array('lat', 'require', '酒店经纬度必须设置！'),
        array('address', 'require', '酒店地址必须填写！'),
        array('address_introduce', 'require', '酒店地址介绍必须填写！'),
        array('facilities', 'require', '酒店设施必须选择！'),
        array('service', 'require', '酒店服务必须选择！'),
        array('img', 'require', '酒店背景主图必须上传！'),
        array('imgarr', 'require', '酒店图片数组必须上传！'),
    );


    //自动填充设置
    protected $_auto = array(
        array('create_time', 'time', '1', 'function'),
        array('update_time', 'time', '3', 'function'),
        array('create_admin', 'CheckAdmin', '3', 'callback'),
    );

    //检查管理员
    function CheckAdmin()
    {
        $admin = $_SESSION["username"];
        if (strlen($admin) > 4) {
            return $admin;
        } else {
            return "";
        }
    }

}
