<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/5/26
 * Time: 15:22
 */

namespace Common\Model;


class RoomStateModel extends BaseModel
{

    public $tableName = 'day_price';

    // 自动验证设置
    protected $_validate = array(
        array('hotel_id', 'require', '所属酒店必须选择！'),
        array('room_id', 'require', '酒店房型必须选择！'),
        array('bed_type', 'require', '床型必须设置！'),
        array('live', 'require', '可住人数必须设置！'),
        array('inventory', 'require', '库存数量必须设置！'),
        array('date', 'require', '日期必须设置！'),
        array('sold_rule_id', 'require', '售卖规则必须选择！'),
        array('refund_remark', 'require', '政策说明必须填写！'),
    );

    //自动填充设置
    protected $_auto = array(
        array('create_time', 'time', '1', 'function'),
        array('update_time', 'time', '2', 'function'),
        array('create_admin', 'CheckAdmin', '3', 'callback'),
    );

    //检查管理员
    function CheckAdmin()
    {
        $admin = $_SESSION["username"];
        if (strlen($admin) > 4) {
            return $admin;
        } else {
            return "";
        }
    }

}
