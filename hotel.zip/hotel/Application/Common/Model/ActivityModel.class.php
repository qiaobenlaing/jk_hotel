<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/5/16
 * Time: 15:00
 */

namespace Common\Model;


class ActivityModel extends BaseModel
{

    protected $tableName = 'activity';

    // 自动验证设置
    protected $_validate = array(
        array('activity_name', 'require', '活动名称必须填写！'),
        array('activity_name', '', '不能有相同的活动名称！', 1, 'unique', '1'), // 在新增的时候验证activity_name字段是否唯一
        array('badge', 'require', '活动标签必须设置 ！'),
        array('hotel_id', 'require', '必须选择对应酒店商家！'),
        array('content', 'require', '活动内容必须填写！'),
        array('content', 'checklength', '活动内容必须在3-45字符之间！', 0, 'callback', 3, array(3, 45)),
        array('sort_id', 'require', '优惠类别必须选择！'),
        array('start_time', 'require', '开始时间必须设置！'),
        array('end_time', 'require', '结束时间必须设置！'),

    );


//    验证长度
    function checklength($str, $min, $max)
    {
        preg_match_all("/./u", $str, $matches);
        $len = count($matches[0]);
        if ($len < $min || $len > $max) {
            return false;
        } else {
            return true;
        }
    }

    //自动填充设置
    protected $_auto = array(
        array('create_time', 'time', '1', 'function'),
        array('create_admin', 'CheckAdmin', '3', 'callback'),
    );

    //检查管理员
    function CheckAdmin()
    {
        $admin = $_SESSION["username"];
        if (strlen($admin) > 4) {
            return $admin;
        } else {
            return "";
        }
    }

}
