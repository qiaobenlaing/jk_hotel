<?php

return array(
    //设置默认URL访问模式
    'URL_MODEL' => 2,
    //设置默认拒绝访问模块
    'MODULE_DENY_LIST' => array('Common', 'Runtime'),
    //设置默认允许访问模块
    'MODULE_ALLOW_LIST' => array('Admin', 'Home', 'Api', 'Web'),
    //设置默认访问模块
    'DEFAULT_MODULE' => 'Admin',
    //设置默认访问控制器
    'DEFAULT_CONTROLLER' => 'Login',
    //设置默认访问方法
    'DEFAULT_ACTION' => 'login',
    'URL_CASE_INSENSITIVE' => false,
    'TMPL_ACTION_ERROR' => "", //默认错误跳转到Public文件夹下面的error.html文件
    'TMPL_ACTION_SUCCESS' => "",//默认成功跳转到对应的Public文件夹下面的success.html文件

    'SHOW_PAGE_TRACE' => false,
    //设置数据库访问配置(TP访问数据库使用的是PDO，需要在php.ini中开启)
    'DB_TYPE' => 'mysqli',       // 数据库类型
    'DB_HOST' => '192.168.235.111',   // 服务器地址
    'DB_NAME' => 'ths_hotel',          // 数据库名
    'DB_USER' => 'ths_hotel',       // 用户名
    'DB_PWD' => '%Hj39Vce@Yg0S@&E52Nx!',       // 密码
    'DB_PORT' => '3306',        // 端口
    'DB_PREFIX' => 'tns_',         // 数据库表前缀
    'DB_CHARSET' => 'utf8',        // 数据库编码默认采用utf8

    'store_path_index'=>1, //fastDFS

    //服务器域名和fastDFS访问域名
    'formal_host' => 'link.jkljdj.com',
    'fast_dfs_url'=>'https://link.jkljdj.com/',

    //退款请求会员卡系统public_key
    'public_key' => '-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDSJ5taRrECCRpUq2vhrn9CR0gysZ5/FhHPhhfZI4kMgAqS7obqmA1HachB/i5b3/2QhXpi5ykur9uy2R5CyRJPZ5Blsm3j7EnNN6HzyqNCcfKahQ36b0Q2C4Y93bhM4iO9QFPKCgiJeMvyGthQXZfVtmQxKU6OWZ29807XuVIOyQIDAQAB
-----END PUBLIC KEY-----',

    //审核订单回调地址
    'REFUND_URL' => 'https://link.jkljdj.com/api/v1/order/refundOrder',

    // 系统异常
    'API_INTERNAL_EXCEPTION' => 20000,  //服务端（API）内部异常
    'CLIENT_INTERNAL_EXCEPTION' => 20001,  // 客户端内部异常。
    'CLIENT_OFFLINE' => 20102,  // 客户端未联网
    'INTERNET_EXCEPTION' => 20103,  // 网络异常
    'TOKEN_OVERTIME' => 20204,  // 会话令牌超时失效 （Session Out）
    'INVALID_TOKEN' => 20205,  // 会话验证错误（令牌token非法，或者vcode非法）
    'USER_NO_AUTHORITY' => 20206,  // 用户无权限访问资源
    'COMPULSORY_LOGOFF' => 20209,  // 用户被强制退出

    'SUCCESS' => 50000,   // 成功

    'YES' => '1', //是
    'NO' => '0', //否

);
