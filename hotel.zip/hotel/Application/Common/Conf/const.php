<?php

/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/4/11
 * Time: 20:54
 */
class Consts
{

    // JSON-RPC异常
    const INVALID_REQUEST = -32600;  // Invalid Request, The JSON sent is not a valid Request object.
    const INVALID_METHOD = -32601;// Method not found, The method does not exist / is not available.
    const INVALID_PARAMS = -32602;// Invalid params, Invalid method parameter(s).
    const INTERNAL_ERROR = -32603;// Internal error
    const INVALID_JSON = -32700;// Parse error, Invalid Json.


    const  INVALID_TOKEN = 20205;  // 会话验证错误（令牌token非法，或者vcode非法）

    const IS_VALIDATE_TOKEN_EXPIRE = '1'; // 是否验证token是否过期，0表示不验证，1表示验证

    //接口返回
    const REQUEST_SUCCESS = 200; //成功
    const PARAMES_ERROR = 400; //参数错误
    const  REQUEST_ERROR = 500; //失败
    
    const ORDER_NOT_CODE = 401; //订单未支付

    //酒店定价方式
    const INDEX_DING = 1; //指数定价
    const RMB_DING = 2;//人民币定价
    const INDEX_RMB_DING = 3;// 双币种定价

    //酒店支付方式
    const INDEX_PAY = 1; //指数支付
    const YUANBAO_PAY = 2;// 元宝支付
    const WEILAIBI_PAY = 3;// 未来币支付
    const INDEX_YUANBAO_PAY=4;// 指数+元宝支付
    const INDEX_WEILAIBI_PAY =5;// 指数+未来币支付


    //订单状态
    const ORDER_NOTPAY = 1; //待支付
    const ORDER_PAYED = 2; //已支付
    const ORDER_CLOSE = 3; //已关闭
    const ORDER_CONFIRM = 4; //已确认
    const ORDER_COMPLETED = 5; //已完成
    const ORDER_CANCEL = 6; //已取消
    const ORDER_CONFIRM_FAIL = 7; //审核失败

    //退款状态
    const CANCEL_NOT = 1; //未申请取消
    const CANCEL_APPLYING = 2; //申请取消中
    const CANCEL_REJECT = 3; //拒绝申请
    const CANCEL_REFUND = 4;// 已退款


    //优惠券相关
    const APP_SHOW = 1; //客户端显示
    const APP_HIDE = 2; // 客户端隐藏

    const VALIDE_NEVER = 0; //永久有效
    const VALIDE_NO = -1; //按日期算有效期

    const UNIVELSAL_YES = 1; //平台券(所有商家通用)
    const UNIVELSAL_NO = 2; //商户券（指定商家可用）


    const COUPON_TYPE_NBUY = 1; //N元购
    const COUPON_TYPE_REBATE =3; //抵扣券
    const COUPON_TYPE_DISCOUNT = 4; //折扣券
    const COUPON_TYPE_PIK = 5;//实物券
    const COUPON_TYPE_EXPRENCE = 6;// 体验券
    const COUPON_TYPE_VOUCHER = 7; //兑换券
    const COUPON_TYPE_CASH = 8;// 代金券
    const COUPON_TYPE_NEW_USER_DISCOUN =32 ;//送新用户的抵扣券
    const COUPON_TYPE_INVITE =33 ;//送邀请人的优惠券


    const RAND_RMB_INDEX = 100;// 指数/人民币=100 （兑换比率）

}
