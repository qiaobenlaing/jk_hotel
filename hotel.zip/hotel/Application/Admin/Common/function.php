<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2018/7/31
 * Time: 22:14
 */
/**
 * 将数组拼接为字符，主要用再分页查询
 * +--------------------------------------------
 * $idarr        SQL查询数组
 * $field        传入字段名称
 * +--------------------------------------------
 * string        返回字符串，例如：1,2,3,4
 * +--------------------------------------------
 */
function array_to_string($idarr = array(), $field = 'id')
{
    $id = array();
    foreach ($idarr as $key => $vo) {
        $id[] = $vo[$field];
    }
    return implode(",", $id);
}

// 选中判断
function isCheck($iCid, $arrId, $ed = "checked", $html = "")
{
    if ($iCid != $arrId) {
        $ed = $html;
    }
    return $ed;
}

/**
 * 将SQL查询结果重新排序为树型数组
 * +--------------------------------------------
 * $list        SQL查询数组
 * $pk            主建名称
 * $pid        父主键ID
 * $child        子内容数组
 * $root        开始数组 默认0
 * +--------------------------------------------
 * $array        返回树形数组
 * +--------------------------------------------
 */
function array_tree($list, $pk = 'id', $pid = 'pid', $child = '_child', $root = 0)
{
    // 创建Tree
    $tree = array();
    if (is_array($list)) {
        // 创建基于主键的数组引用
        $refer = array();

        foreach ($list as $key => $data) {
            $refer[$data[$pk]] =& $list[$key];
        }

        foreach ($list as $key => $data) {
            // 判断是否存在parent
            $parentId = $data[$pid];

            if ($root == $parentId) {
                $tree[] =& $list[$key];
            } else {

                if (isset($refer[$parentId])) {
                    $parent =& $refer[$parentId];
                    $parent[$child][] =& $list[$key];
                }
            }
        }
    }
    return $tree;
}

//获取星期几描述
function getWeekTxt($value)
{
    $txt = '';
    switch ($value) {
        case 1:
            $txt = '周一';
            break;
        case 2:
            $txt = '周二';
            break;
        case 3:
            $txt = '周三';
            break;
        case 4:
            $txt = '周四';
            break;
        case 5:
            $txt = '周五';
            break;
        case 6:
            $txt = '周六';
            break;
        case 7:
            $txt = '周日';
            break;
    }
    return $txt;
}

//优惠券状态
function CouponState($state)
{
    $txt = '未知';
    switch ($state) {
        case 1:
            $txt = '可用';
            break;
        case 2:
            $txt = '已使用';
            break;
        case 3:
            $txt = '冻结状态';
            break;
        case 0:
            $txt = '不可用';
            break;
    }
    return $txt;
}


//字符串拆分为标签
function getImploadBadge($str)
{
    if ($str == '') {
        return '暂无';
    } else {
        $arr = json_decode($str, true);
        $html = '';
        foreach ($arr as $item) {
            $html = $html . '<span class="layui-badge" style="margin-right: 10px;margin-top:2px;">' . $item . '</span>';
        }
        return $html;
    }
}

//判断字符是否在内容里面
function in_side($needle, $haystack, $run = "checked", $bool = false)
{
    // 如果不是数组就转换为数组
    if (!is_array($haystack)) {
        $haystack = explode(',', $haystack);
    }
    //判断内容是否在数组内
    if (in_array($needle, $haystack)) {
        $bool = $run;
    }
    return $bool;
}

//UTF-8切割字符串
function cn_substr($string, $length, $etc = '...')
{
    $result = '';
    $string = html_entity_decode(trim(strip_tags($string)), ENT_QUOTES, 'UTF-8');
    $strlen = strlen($string);
    for ($i = 0; (($i < $strlen) && ($length > 0)); $i++) {
        if ($number = strpos(str_pad(decbin(ord(substr($string, $i, 1))), 8, '0', STR_PAD_LEFT), '0')) {
            if ($length < 1.0) {
                break;
            }

            $result .= substr($string, $i, $number);
            $length -= 1.0;
            $i += $number - 1;

        } else {

            $result .= substr($string, $i, 1);
            $length -= 0.5;
        }
    }

    $result = htmlspecialchars($result, ENT_QUOTES, 'UTF-8');
    if ($i < $strlen) {
        $result .= $etc;
    }
    return $result;
}

/*parameter &$arr 数组
* parameter $num 随机生成的数量
* return 生成的随机数组(数组的键和值对应)
* */
function rand_arr_value($arr, $num = 1)
{
    $r = array_rand($arr, $num);
    $newarr = array();
    if (is_array($r)) {
        foreach ($r as $row) {
            $newarr[$row] = $arr[$row];
        }

    } else {
        $newarr[0] = $arr[$r];
    }
    return $newarr;
}

//时间戳格式化
function toDate($time, $format = 'Y-m-d H:i:s')
{
    if (empty($time)) {
        return '';
    }
    $format = str_replace('#', ':', $format);
    return date($format, $time);
}

/*关联信息
    $datable  数据模型
    $info 关联字段信息
    $sql查询条件
*/
function getName($datable, $info, $sql)
{
    $table = D($datable);
    $list = $table->where($sql)->order("id desc")->find();
    return $list[$info];
}


//去除HTML标签
function re_html($html = '')
{
    $html = trim(strip_tags($html));
    $html = str_replace("'", "", $html);
    $html = str_replace(" ", "", $html);
    $html = str_replace("　", "", $html);
    $html = preg_replace('/[\n\r\t]/', '', $html);
    $html = str_replace("&nbsp;", "", $html);
    return $html;
}

//时间转换
function toStringDate($time)
{
    return date("Y-m-d H:i:s", strtotime($time));
}

//添加和修改记录状态
function getState($name = 'status', $stutas = 1)
{
    $checked[$stutas] = 'checked="checked" ';
    $html["status"] = '<div class="layui-input-block">
					<input type="radio" name="' . $name . '"  value="1"' . $checked[1] . ' title="正常">
					<input type="radio" name="' . $name . '"  value="2"' . $checked[2] . ' title="暂停">
			</div>';

    return $html[$name];
}

//获得状态值
function getRoomDayTypeText($value)
{
    switch ($value) {
        case 1:
            $value = "<font style='color: #FF5722;'>保留房</font>";
            break;
        case 2:
            $value = "<font style='color: #2F4056;'>非保留房</font>";
            break;
        default:
            $value = "<font style='color: #c2c2c2;'>临时保留房</font>";
            break;
    }
    return $value;
}

//获得状态值
function getStatusText($value)
{
    switch ($value) {
        case 1:
            $value = "<font style='color: #009688;'>正常</font>";
            break;
        case 2:
            $value = "<font style='color: #FF0000;'>暂停</font>";
            break;
        default:
            $value = "<font style='color: #888888;'>未知</font>";
            break;
    }
    return $value;
}


function getBreaf($value)
{
    switch ($value) {
        case 1:
            $value = "<font style='color: #009688;'>有早餐</font>";
            break;
        case 2:
            $value = "<font style='color: #FF0000;'>无早餐</font>";
            break;
    }
    return $value;
}

/**
 * 判断字符串是否是日期格式
 * @param $date
 * @param $format
 * @return bool
 */
function is_date($date, $format = 'Y-m-d')
{
    if (!$date || $date == '0000-00-00') return false;
    $unix_time_1 = strtotime($date);
    if (!is_numeric($unix_time_1)) return false; //非数字格式
    $format_date = date($format, $unix_time_1);
    $unix_time_2 = strtotime($format_date);
    return ($unix_time_1 == $unix_time_2);
}

/**
 * excel数据导入  日期格式化
 * @param $date
 * @return false|string
 */
function get_date_by_excel($date)
{
    if (!$date || $date == '0000-00-00') return null;

    $unix_time = \PHPExcel_Shared_Date::ExcelToPHP($date);

    return ($unix_time < 0) ? date('Y-m-d', $unix_time) : date('Y-m-d', strtotime(gmdate('Y-m-d', $unix_time)));
}

/**
 * 获取excel日期格式化结果
 * @param $date string excel日期单元格字符串
 * @param $default string  $date未非日期时返回默认日期
 * @return string
 */
function excel_date_format($date, $default = '')
{
    if ($default == '') $default = date('Y-m-d');

    if (is_date($date)) return $date;

    return get_date_by_excel($date) ?: $default;
}

//支付方式
function PayType($value)
{
    switch ($value) {
        case 1:
            $value = "<span class='layui-badge' style='color: white;margin: 0 3px;height: 20px;margin-top: 8px;line-height: 20px;'>指数</span>";
            break;
        case 2:
            $value = "<span class='layui-badge' style='color: white;margin: 0 3px;height: 20px;margin-top: 8px;line-height: 20px;'>余额</span>";
            break;
        case 3:
            $value = "<span class='layui-badge' style='color: white;margin: 0 3px;height: 20px;margin-top: 8px;line-height: 20px;'>未来币</span>";
            break;
        case 4:
            $value = "<span class='layui-badge' style='color: white;margin: 0 3px;height: 20px;margin-top: 8px;line-height: 20px;'>指数+余额</span>";
            break;
        default:
            $value = "<span class='layui-badge' style='color:white;margin: 0 3px;height: 20px;margin-top: 8px;line-height: 20px;'>指数+未来币</span>";
            break;
    }
    return $value;
}

/**
 * 判断字符串是否base64编码
 */
function func_is_base64($str)
{
    return $str == base64_encode(base64_decode($str)) ? true : false;
}

//统计一段时间内所有的天数，并返回天数的数组
function dateNum($begintime, $endtime)
{
    $bentimestap = strtotime($begintime);
    $endtimestap = strtotime($endtime);
    for ($i = $bentimestap; $i <= $endtimestap; $i += 86400) {
        $date[] = date("Y-m-d", $i);
    }
    return $date;
}

//获取退订状态
function getRefundText($value)
{
    switch ($value) {
        case 1:
            $value = "<font style='color: #ff5749;'>不可退订</font>";
            break;
        case 2:
            $value = "<font style='color: ##893083;'>有条件退订</font>";
            break;
        case 3:
            $value = "<font style='color: #18fd2a;'>免费退订</font>";
            break;
        default:
            $value = "<font style='color: #888888;'>未知</font>";
            break;
    }
    return $value;
}

//获取置换方式说明
function getReplaceType($value)
{
    switch ($value) {
        case 1:
            $value = "<font style='color:red;'>指数支付</font>";
            break;
        case 2:
            $value = "<font style='color:deepskyblue;'>元宝支付</font>";
            break;
        case 3:
            $value = "<font style='color: #f0ad4e;'>未来币支付</font>";
            break;
        default:
            $value = "<font style='color: #888888;'>未知</font>";
            break;
    }
    return $value;
}

//房费支付方式说明
function RoomPayType($value)
{
    switch ($value) {
        case 1:
            $value = "<font style='color:#145cff;'>指数支付</font>";
            break;
        case 2:
            $value = "<font style='color:deepskyblue;'>元宝支付</font>";
            break;
        case 3:
            $value = "<font style='color: #f0432b;'>未来币支付</font>";
            break;
        case 4:
            $value = "<font style='color: #f0ad4e;'>混合支付</font>";
            break;
        default:
            $value = "<font style='color: #888888;'>未知</font>";
            break;
    }
    return $value;
}

//获取支付状态
function getRefundStateText($value)
{
    switch ($value) {
        case 1:
            $value = "<font style='color: #65dff0;'>未申请退款</font>";
            break;
        case 2:
            $value = "<font style='color: ##faff82;'>申请退款中</font>";
            break;
        case 3:
            $value = "<font style='color: #ff5749;'>商家拒绝退款</font>";
            break;
        case 4:
            $value = "<font style='color: #08ff52;'>已全额退款</font>";
            break;
        default:
            $value = "<font style='color: #888888;'>未知</font>";
            break;
    }
    return $value;
}

//获取支付状态
function getPayStateText($value)
{
    switch ($value) {
        case 1:
            $value = "<font style='color: #FF0000;'>待支付</font>";
            break;
        case 2:
            $value = "<font style='color: #A63E0F;'>待确认</font>";
            break;
        case 3:
            $value = "<font style='color: #666666;'>支付超时</font>";
            break;
        case 4:
            $value = "<font style='color: #2043DB;'>待入住</font>";
            break;
        case 5:
            $value = "<font style='color: #21AE2A;'>已完成</font>";
            break;
        case 6:
            $value = "<font style='color: #8c8c8c;'>已取消</font>";
            break;
        case 7:
            $value = "<font style='color: #8c4d07;'>确认失败</font>";
            break;
        default:
            $value = "<font style='color: #888888;'>未知</font>";
            break;
    }
    return $value;
}


//优惠券类型
function couponTypeText($value)
{
    $txt = '';
    switch ($value) {
        case 1:
            $txt = '<span style=\'color: #92B8B1;\'>N元购</span>';
            break;
        case 3:
            $txt = '<span style=\'color: #2D83D5;\'>抵扣券</span>';
            break;
        case 4:
            $txt = '<span style=\'color: #D4241A;\'>折扣券</span>';
            break;
        case 5:
            $txt = '<span style=\'color: #00B4F4;\'>实物券</span>';
            break;
        case 6:
            $txt = '<span style=\'color: #19F048;\'>体验券</span>';
            break;
        case 7:
            $txt = '<span style=\'color: #c0a16b;\'>兑换券</span>';
            break;
        case 8:
            $txt = '<span style=\'color: #c2c2c2;\'>代金券</span>';
            break;
        default:
            $txt = '未知';
            break;
    }
    return $txt;
}

//字符编码强制转为UTF-8
function characet($data)
{
    if (!empty($data)) {
        $fileType = mb_detect_encoding($data, array('UTF-8', 'GBK', 'LATIN1', 'BIG5'));
        if ($fileType != 'UTF-8') {
            $data = mb_convert_encoding($data, 'utf-8', $fileType);
        }
    }
    return $data;
}


// 取得图片路径
// path			图片路径
// imgKey		图片路径关键词，默认服务器路径
function imgPath($path = "", $imgKey = "server")
{
    $imgPath = "";

    // 服务器路径必须 “/” 结尾，例如：http://www.yizhuoit.com/
    // 服务器绝对路径
    $img['server'] = str_replace('index.php', '', $_SERVER["SCRIPT_NAME"]);
    $img['e7yo'] = "http://www.e7yo.net/";

    if (strlen($path) > 5) {

        // 图片路径里面包含有 http:// 判断为网络图片，不增加服务器路径
        if (strchr($path, "http://")) {
            $img[$imgKey] = "";
        }

        $imgPath = $img[$imgKey] . $path;
    }
    return $imgPath;
}

//显示图片
function showImg($path)
{
    $replace = str_replace('index.php', '', $_SERVER["SCRIPT_NAME"]);
    $path = $replace . $path;
    return "<a href='{$path}' target=\"_blank\"><span style='color:#3385FF'>点击查看</span></a>";
}

//让分页自动实现AJAX加载
function ajaxPage($js = "")
{
    strlen($_REQUEST["ajaxId"]) < 3 ? $id = "content" : $id = $_REQUEST["ajaxId"];

    $htm = "<script type=\"text/javascript\">";
    $htm .= "var " . $id . "Url = function(url){\n";
    $htm .= "$('#" . $id . "').load(url);return false;}\n";
    $htm .= "$(\"#" . $id . "page a\").bind('click',
		function(){
			" . $id . "Url(this.href);
			return false;
		});";
    $htm .= $js . "</script>";
    $htm .= "<input type='hidden' value='" . $_SERVER['REQUEST_URI'] . "' id='" . $id . "PageUrl' />";
    return $htm;
}

/**
 * 把返回的数据集转换成Tree
 * @param array $list 要转换的数据集
 * @param string $pid parent标记字段
 * @param string $level level标记字段
 * @return array
 * @author 麦当苗儿 <zuojiazi@vip.qq.com>
 */
function list_to_tree($list, $pk = 'id', $pid = 'parent', $child = '_child', $root = 0)
{
    // 创建Tree
    $tree = array();
    if (is_array($list)) {
        // 创建基于主键的数组引用
        $refer = array();
        foreach ($list as $key => $data) {
            $refer[$data[$pk]] =& $list[$key];
        }
        foreach ($list as $key => $data) {
            // 判断是否存在parent
            $parentId = $data[$pid];
            if ($root == $parentId) {
                $tree[] =& $list[$key];
            } else {
                if (isset($refer[$parentId])) {
                    $parent =& $refer[$parentId];
                    $parent[$child][] =& $list[$key];
                }
            }
        }
    }
    return $tree;
}


/**
 * 添加系统日志，不返回数据
 * +--------------------------------------------
 * $title        说明标题
 * $remark        日志详细说明
 * $source        日志来源
 * $username    添加用户名
 * +--------------------------------------------
 */
function add_log($title = "", $remark = "", $source = "后台", $username = "")
{

    // 创建数据日志实例
    $Log = D("Log");

    // 默认用户名
    if (strlen($username) < 1) {
        $username = $_SESSION['username'];
    }
    // 组合添加数组
    $Log->title = $title;
    $Log->remark = $remark;
    $Log->admin = $username;
    $Log->addip = get_client_ip();
    $Log->read_time = time();
    $Log->source = $source;                // 来源说明

    $Log->add();
}
