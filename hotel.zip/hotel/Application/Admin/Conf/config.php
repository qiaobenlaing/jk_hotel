<?php
return array(
	//'配置项'=>'配置值'
    // 默认模块名称
    'DEFAULT_MODULE'		=>	'Login',
    // 默认操作名称
    'DEFAULT_ACTION'		=>	'index',

    /**
    上传权限配置
     */
    // 上传文件后缀格式
    'allowExts' 			=>	"jpg,gif,png",
    //上传文件MINI
    'allowTypes'			=>	"image/pjpeg,image/jpeg,image/png,image/x-png,image/gif",
    //上传路径
    "savePath"             =>"Public/Uploads/",
    // 最大上传文件
    'maxSize'				=>	32922000,

//    超级管理员
    "super_user"        => "netfarm",

);