<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/7/24
 * Time: 13:27
 */

namespace Admin\Controller;

use Org\Util\Page;

class CouponController extends AdminBaseController
{

    public $Model = 'Coupon';
    public $order = 'update_time desc';

    public function add()
    {
        //房型列表 begin
        $roomlist = D('Hotel')->alias('H')->where(array('H.status' => 1, 'H.hotel_category' => '3', 'R.state' => 1))
            ->join('join tns_room as R ON R.hotel_id=H.id')
            ->field('R.id,R.hotel_id,H.title as hotel_title,R.title as room_title')->select();
        $newArray = array();
        foreach ($roomlist as $v) {
            $newArray[$v['hotel_id']][] = $v;
        }
        foreach ($newArray as $item => $value) {
            $sublist = array();
            foreach ($value as $ite => $val) {
                $arr['name'] = $val['room_title'];
                $arr['value'] = $val['id'];
                $sublist['children'][] = $arr;
            }
            $sublist['name'] = $value[0]['hotel_title'];
            $sublist['value'] = $value[0]['hotel_id'];
            $list[] = $sublist;
        }
        //房型列表 end
        $this->assign('roomlist', json_encode($list, true, JSON_UNESCAPED_UNICODE));
        $this->display();
    }

    public function edit()
    {
        $id = I('get.id');
        $arr = D($this->Model)->where(array('id' => $id))->find();
        $roomlist = D('Hotel')->alias('H')->where(array('H.status' => 1, 'H.hotel_category' => '3', 'R.state' => 1))
            ->join('join tns_room as R ON R.hotel_id=H.id')
            ->field('R.id as room_id,R.hotel_id,H.title as hotel_title,R.title as room_title')->select();
        $hotel_id_arr = explode(',', $arr['hotel_ids']);
        foreach ($roomlist as $iii => &$vvvv) {
            if (in_array($vvvv['room_id'], $hotel_id_arr)) {
                $vvvv['selected'] = true;
            }
        }
        $newArray = array();
        foreach ($roomlist as $v) {
            $newArray[$v['hotel_id']][] = $v;
        }
        foreach ($newArray as $item => $value) {
            $sublist = array();
            foreach ($value as $ite => $val) {
                $one['name'] = $val['room_title'];
                $one['value'] = $val['room_id'];
                $one['selected'] = $val['selected'];
                $sublist['children'][] = $one;
            }
            $sublist['name'] = $value[0]['hotel_title'];
            $sublist['value'] = $value[0]['hotel_id'];
            $list[] = $sublist;
        }

        //时间格式转换
        $arr['expire_time'] = toDate($arr['expire_time']);
        $arr['start_taking_time'] = toDate($arr['start_taking_time']);
        $arr['end_taking_time'] = toDate($arr['end_taking_time']);
        $arr['start_using_time'] = toDate($arr['start_using_time']);

        $date = explode(',', $arr['dis_used_date']);
        foreach ($date as $ii => $vvv) {
            $data['name'] = $vvv;
            $data['value'] = $vvv;
            $data['selected'] = true;
            $listDate[] = $data;
        }

        $this->assign('date', json_encode($listDate, true, JSON_UNESCAPED_UNICODE));
        $this->assign('roomlist', json_encode($list, true, JSON_UNESCAPED_UNICODE));
        $this->assign('arr', $arr);
        $this->display();
    }

    //数据添加
    public function insert()
    {
        $datatb = $this->Model;
        $User = D($datatb); // 实例化User对象
        $vo = $User->create();
        if (!$vo) {
            $error = $User->getError();
            $this->error($error);
        } else {

            //字段转换处理
            $data = $this->dataTranceData($User, $vo);

            //添加数据
            $id = $User->add($data);
            if ($id) {
                // 添加日志
                add_log("添加信息成功", cn_substr($User->getLastSql(), 100));
                $this->success("添加成功");
            } else {
                $this->error("添加失败，请重新添加");
            }
        }
    }

    public function del()
    {
        $datatb = $this->Model;
        $id = intval($_REQUEST["delId"]);
        $Form = D($datatb);
        $delState = $Form->where("id = '" . $id . "'")->delete();
        if ($delState) {
            D('usercoupon')->where(array('coupon_id' => $id))->delete();
            $this->success("删除成功！");
        } else {
            $this->error($Form->getError());
        }
    }

    //统计优惠券
    public function totalCoupon()
    {
        $userCouponModel = D('usercoupon');
        $couponList = $userCouponModel->where(array('coupon_id' => I('get.id')))->select();
        //已发放量
        $sendCount = count($couponList);
        //已使用数量
        $usedCount = 0;
        //未使用数量
        $canUse = 0;
        //已过期数量
        $expire = 0;
        foreach ($couponList as $item => $value) {
            if ($value['status'] == 2) {
                $usedCount++;
            }
            if (time() > $value['expire_time']) {
                $expire++;
            }
            if ($value['status'] == 1 && (time() < $value['expire_time'])) {
                $canUse++;
            }
        }
        //数据封装
        $data = array(
            'sendCount' => $sendCount,
            'canUse' => $canUse,
            'expire' => $expire,
            'usedCount' => $usedCount
        );
        $this->success($data);
    }

    //数据修改
    public function update()
    {
        $datatb = $this->Model;
        $User = D($datatb); // 实例化User对象
        $data = $User->create();
        if (!$data) {
            $error = $User->getError();
            $this->error($error);
        } else {
            //添加数据
            $data = $this->dataTranceData($User, $data);
            $id = $User->save($data);
            if ($id) {
                D('usercoupon')->where(array('coupon_id'=>$data['id']))->save(array('start_using_time'=>$data['start_using_time'],'expire_time'=>$data['expire_time']));
                add_log("修改信息成功", cn_substr($User->getLastSql(), 100));
                $this->success("修改信息成功");
            } else {
                $this->error($User->getError());
            }
        }
    }

    private function dataTranceData($Model, $vo)
    {

        //时间格式转换
        $vo['start_taking_time'] = strtotime($vo['start_taking_time']);
        $vo['end_taking_time'] = strtotime($vo['end_taking_time']);
        $vo['start_using_time'] = strtotime($vo['start_using_time']);

        //id>0说明是修改
        if ($vo['id'] > 0) {
            //过期时间及有效期
            $vo['expire_time'] = strtotime($vo['expire_time']);
            $datenum = dateNum(toDate($vo['start_using_time']), toDate($vo['expire_time']));
            $validate = count($datenum) - 1;
            $vo['validity_period'] = $validate;
            //判断不为网络图片，而是base64编码图片
            if (substr($vo['coupon_img'], 0, 5) == 'data:') {
                if ($_SERVER['HTTP_HOST'] == C('formal_host')) {
                    $result = $this->fastDfsUploadImg($vo['coupon_img']);
                    $vo['coupon_img'] = $result;
                } else {
                    $ossInfo = $this->base64ToImages($vo['coupon_img']);
                    $vo['coupon_img'] = $ossInfo['url'];
                }
            }

        } else {
            $vo['coupon_code'] = $Model->create_uuid();
            //如果有效期设置为0，永久有效;计算过期时间计算为10年
            if ($vo['validity_period'] == 0) {
                $this->error('有效期必须设置');
            } else {
                $vo['expire_time'] = $vo['start_using_time']+86399+ 60 * 60 * 24 * $vo['validity_period'];
            }
            //剩余量等于总量，如总量为-1，剩余量也一样
            if($vo['total_volume']<1){
                $this->error('发行量不能小于1');
            }
            $vo['remaining'] = $vo['total_volume'];

            //图片OSS
            if ($_SERVER['HTTP_HOST'] == C('formal_host')) {
                $result = $this->fastDfsUploadImg($vo['coupon_img']);
                $vo['coupon_img'] = $result;
            } else {
                $ossInfo = $this->base64ToImages($vo['coupon_img']);
                $vo['coupon_img'] = $ossInfo['url'];
            }
        }

        //平台或者酒店商户判断
        if ($vo['coupon_belonging'] == 1) {
            if ($vo['hotel_ids'] == '' || empty($vo['hotel_ids'])) {
                $this->error('酒店房型必须选择');
            }
        }
        if ($vo['coupon_belonging'] == 2) {
            if ($vo['is_universal'] == 2) {
                if ($vo['hotel_ids'] == '' || empty($vo['hotel_ids'])) {
                    $this->error('酒店房型必须选择');
                }
            }
        }

        //去掉空格
        $vo['coupon_name'] = trim($vo['coupon_name']);
        //备注字段
        $title_content = trim($vo['title_content']);
        $role_arr = $vo['rule'];
        unset($vo['title_content'], $vo['rule']);
        $vo['remark'] = json_encode(array(
            'title' => $title_content,
            'rule' => $role_arr,
        ), JSON_UNESCAPED_UNICODE);
        return $vo;
    }

    public function ajaxlist()
    {
        // 预加载变量
        $datatb = $this->Model;                // 主数据库
        $order = $this->order;                // 排序
        $page = $this->pageNum;                // 分页条数
        $pkid = $this->PkId;                // 主键ID字段名称
        $fields = $this->Fields;            // 打开字段

        // 加载数据库
        $Admin = D($datatb);

        if (strlen($fields) < 1) {
            $fields = "*";
        }

        // pkid 设置
        if (strlen($pkid) < 1) {
            $pkid = $Admin->getPk();
        }

        if (strlen($pkid) < 1) {
            $pkid = "id";
        }

        // 分页条数设置
        if ($page < 1) {
            $page = 20;
        }

        //排序
        if (count($order) < 1) {
            $order = "id desc";
        }

        $search = array();
        $search = $this->_search($datatb);
        $count = $Admin->where($search)->field($pkid)->count();
        import("@.ORG.Util.Page"); //导入分页类
        $p = new Page($count, $page);

        $list = $Admin->where($search)->field("*")->order($order)->limit($p->firstRow . ',' . $p->listRows)->select();
        $page = $p->show();

        foreach ($list as $item => &$value) {
            $value['validity_period'] == 0 ? $value['validity_period'] = '永久' : $value['validity_period'] = $value['validity_period'];
        }

        $this->assign("total", $count);
        $this->assign("list", $list);
        $this->assign("page", $page);
        $this->display();
    }

}
