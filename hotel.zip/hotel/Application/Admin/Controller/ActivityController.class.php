<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/5/15
 * Time: 17:23
 */

namespace Admin\Controller;

class ActivityController extends AdminBaseController
{
    public $Model = "Activity";
    public $order = 'sort desc,id desc';
    public static $FACILITY = '67'; //专属优惠分类

    public function add()
    {
        $hotellist = D('Hotel')->field(array('id,title'))->select();
        $this->assign('hotellist', $hotellist);
        $sortlist = D('Sort')->where(array('parent_id' => self::$FACILITY))->field(array('id,title'))->select();
        $this->assign('sortlist', $sortlist);
        $this->display();
    }

    public function edit()
    {
        $id = I('get.id');
        $arr = D($this->Model)->where(array('id' => $id))->find();
        $hotellist = D('Hotel')->field('id,title')->select();
        $this->assign('arr', $arr);
        $this->assign('hotellist', $hotellist);
        $sortlist = D('Sort')->where(array('parent_id' => self::$FACILITY))->field(array('id,title'))->select();
        $this->assign('sortlist', $sortlist);
        $this->display();
    }

    //插入
    public function insert()
    {

        $ActivityModel = D($this->Model);
        $data = $ActivityModel->create();

        if (!$data) {
            $this->error($ActivityModel->getError());
        } else {

            $data['start_time'] = strtotime($data['start_time']);
            $data['end_time'] = strtotime($data['end_time']);
            $data['duration'] = $data['end_time'] - $data['start_time'];

            if ($_SERVER['HTTP_HOST'] == C('formal_host')) {
                $result = $this->fastDfsUploadImg($data['activity_img']);
                $data['activity_img'] = $result;
            } else {
                $ossInfo = $this->base64ToImages($data['activity_img']);
                $data['activity_img'] = $ossInfo['url'];
            }
            $id = $ActivityModel->add($data);
            if ($id) {
                add_log("添加活动成功", cn_substr($ActivityModel->getLastSql(), 100));
                $this->success("添加活动成功");
            } else {
                $this->error('添加活动失败，请重试');
            }
        }
    }

    //修改
    public function update()
    {

        $ActivityModel = D($this->Model);
        $data = $ActivityModel->create();
        if (!$data) {
            $this->error($ActivityModel->getError());
        } else {
            $data['start_time'] = strtotime($data['start_time']);
            $data['end_time'] = strtotime($data['end_time']);
            $data['duration'] = $data['end_time'] - $data['start_time'];
            if (substr($data['activity_img'],0,5)=='data:') { //判断不为网络图片，而是base64编码图片
                if ($_SERVER['HTTP_HOST'] == C('formal_host')) {
                    $result = $this->fastDfsUploadImg($data['activity_img']);
                    $data['activity_img'] = $result;
                } else {
                    $ossInfo = $this->base64ToImages($data['activity_img']);
                    $data['activity_img'] = $ossInfo['url'];
                }
            }
            $id = $ActivityModel->save($data);
            if ($id) {
                add_log("修改信息成功", cn_substr($ActivityModel->getLastSql(), 100));
                $this->success("修改改成功");
            } else {
                $this->error('修改改失败，请重试');
            }
        }
    }

}
