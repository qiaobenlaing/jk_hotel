<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/5/26
 * Time: 15:18
 */

namespace Admin\Controller;


use Common\Model\HotelModel;
use Common\Model\RoomStateModel;
use Common\Model\SoldRuleModel;
use Common\Model\UserModel;
use Org\Util\Page;
use Org\Util\Tree;
use Think\Upload;

class RoomStateController extends AdminBaseController
{
    public $Model = 'DayPrice';
    public $order = 'state asc,id desc';


    public function showSoldRuleInfo()
    {
        $sold_rule_id = I('get.id');
        $day_price_list = D($this->Model)->where(array('sold_rule_id' => $sold_rule_id, 'state' => 1))->field('date')->order('date asc')->select();
        $start_date = $day_price_list[0]['date'];//开始日期
        $end_date = $day_price_list[count($day_price_list) - 1]['date'];// 结束日期
        $not_lianxu_date = '<span class="layui-badge layui-bg-gray">无</span>'; //不连续开始日期
        $lianxu = '<span class="layui-badge layui-bg-green">连续</span>';
        foreach ($day_price_list as $item => $value) {
            if ($item > 0 && $item) {
                if (strtotime($day_price_list[$item - 1]['date']) + 86400 != strtotime($value['date'])) {
                    $lianxu = '<span class="layui-badge layui-bg-gray">不连续</span>';
                    $not_lianxu_date = '<span>' . $value['date'] . '</span>';
                }
            }
        }
        $data = array('start_date' => $start_date, 'end_date' => $end_date, 'lianxu' => $lianxu, 'not_lianxu_date' => $not_lianxu_date);

        $sold_rule_info = D('sold_rule')->where(array('id' => $sold_rule_id))->find();
        $sold_rule_info['is_even_live'] == 1 ? $sold_rule_info['is_even_live'] = "<span class='layui-badge layui-bg-red'>是</span>" : $sold_rule_info['is_even_live'] = "<span class='layui-badge layui-bg-gray'>否</span>";
        $sold_rule_info['week_set'] == 1 ? $sold_rule_info['week_set'] = "<span class='layui-badge layui-bg-red'>是</span>" : $sold_rule_info['week_set'] = "<span class='layui-badge layui-bg-gray'>否</span>";
        $sold_rule_info['even_week_start'] == null ? $sold_rule_info['even_week_start'] = '不限制' : $sold_rule_info['even_week_start'] = getWeekTxt($sold_rule_info['even_week_start']);
        $sold_rule_info['even_week_end'] == null ? $sold_rule_info['even_week_end'] = '不限制' : $sold_rule_info['even_week_end'] = getWeekTxt($sold_rule_info['even_week_end']);
        $sold_rule_info['room_money'] = $sold_rule_info['room_money'] == null ? '无' : $sold_rule_info['room_money'];
        $sold_rule_info['room_money_rmb'] = $sold_rule_info['room_money_rmb'] == null ? '无' : $sold_rule_info['room_money_rmb'];
        $sold_rule_info['sold_title'] = $sold_rule_info['sold_title'];
        $this->success(array('date' => $data, 'sold_info' => $sold_rule_info));
    }

    //批量修改页面
    public function editall()
    {
        $hotellist = D('Hotel')->field(array('id,title'))->select();
        $this->assign('hotellist', $hotellist);
        //属性条件
        $property = array(
            array('value' => 'is_breakfast', 'name' => '早餐'),
            array('value' => 'inventory', 'name' => '库存量'),
            array('value' => 'is_out_sold', 'name' => '是否超卖'),
            array('value' => 'refund_state', 'name' => '退订状态'),
            array('value' => 'live', 'name' => '可住人数'),
        );
        $this->assign('property', json_encode($property, true, JSON_UNESCAPED_UNICODE));
        $this->display();
    }

    //批量修改操作
    public function updatelist()
    {
        $vo = I('post.');

        //先整理出态的常规属性属性
        $room_attr = array(
            'sold_rule_id' => $vo['sold_rule_id'],
            'day_room_type' => $vo['day_room_type'],
            'is_breakfast' => $vo['is_breakfast'],
            'is_out_sold' => $vo['is_out_sold'],
            'out_sold_count' => $vo['out_sold_count'],
            'live' => $vo['live'],
            'refund_state' => $vo['refund_state'],
            'refund_remark' => trim($vo['refund_remark']),
            'bed_type' => $vo['bed_type'],
        );

        //剔除掉不需要的选项
        unset($vo['date_range']);
        unset($vo['room_id']);
        unset($vo['bed_type']);
        //主键string转为数组Arr
        $idArr = explode(',', $vo['ids']);
        //判断传递过来的属性条件是否为空
        if (isset($vo['inventory']) && $vo['inventory'] < 1) {
            $this->error('库存量必须设置');
        }

        if (isset($vo['live']) && $vo['live'] == '') {
            $this->error('可住人数不能为空');
        }
        if ($vo['refund_remark'] == '' && $vo['refund_state'] > 0) {
            $this->error('退订政策必须说明');
        }

        unset($vo['hotel_id']);

        $prelist = D($this->Model)->where(array('id' => array('IN', $idArr)))->select(); //得到原来数组
        foreach ($prelist as $item => &$value) {

            //将日期装进单独数组
            $dataList[] = $value['date'];

            if (isset($vo['live'])) {
                $value['live'] = $vo['live'];
            }

            if (isset($vo['inventory'])) {
                $value['inventory'] = $vo['inventory'];
            }
            if (isset($vo['is_breakfast'])) {
                $value['is_breakfast'] = $vo['is_breakfast'];
            }
            if (isset($vo['refund_state'])) {
                $value['refund_state'] = $vo['refund_state'];
                $value['refund_remark'] = $vo['refund_remark'];
            }

            if (isset($vo['is_out_sold'])) {
                $value['is_out_sold'] = $vo['is_out_sold'];
                $value['out_sold_count'] = $vo['out_sold_count'];
            }
        }

        if ($vo['ids'] == '') {
            $this->error('未修改任何数据');
        }

        //判断要修改的数据是否有重复项
        if (count($dataList) != count(array_unique($dataList))) {
            $this->error('不允许修改有重复日期的数据');
        }

        //判断修改时间是否在售卖规则内
        $this->checkSoldRule($vo, $dataList);

        //根据条件查询得到的数据列表批量修改房态列表是否有重复项
        $check_day_price = $this->checkRoomDate($prelist);
        if ($check_day_price) {
            $this->error('房态数据有重复，请先查询确认');
        }

        //房型属性不存在则创建
        $room_attr_id = M('room_attr')->where($room_attr)->field('id')->find();
        if (!$room_attr_id) {
            $hotel_id_and_room_id_arr = M('sold_rule')->alias('sr')->join('tns_room as r on r.id =sr.room_id')
                ->where(array('sr.id' => $room_attr['sold_rule_id']))->field('r.hotel_id,sr.room_id')->find();
            $room_attr['hotel_id'] = $hotel_id_and_room_id_arr['hotel_id'];
            $room_attr['room_id'] = $hotel_id_and_room_id_arr['room_id'];
            $room_attr_id = M('room_attr')->add($room_attr);
        }

        $vo['attr_room_id'] = $room_attr_id;
        $result = D($this->Model)->where(array('id' => array('IN', $idArr)))->save($vo);
        if ($result) {
            $this->success('批量修该房态信息成功');
        } else {
            $this->error('修改失败,请确认输入条件是否修改');
        }
    }

    //批量删除
    public function delall()
    {
        $datatb = $this->Model;
        $id = implode(",", $_REQUEST["delId"]);
        $Form = D($datatb);
        $delState = $Form->where("id in(" . $id . ") ")->delete();
        if ($delState) {
            $this->success("删除成功！");
        } else {
            $this->error($Form->getError());
        }
    }


    //展示修改页的弹窗
    public function updateall()
    {
        $User = new RoomStateModel();
        $vo = $User->create();
        if (!$vo) {
            $error = $User->getError();
            $this->error($error);
        } else {

            $hotelName = getName("Hotel", "title", "id='" . $vo['hotel_id'] . "'");
            $roomName = getName("Room", "title", "id='" . $vo['room_id'] . "'");
            $bedType = $vo['bed_type'];
            $dateRange = $vo['date'];
            $rangeArr = explode('|', $dateRange);

            $search['hotel_id'] = $vo['hotel_id'];
            $search['room_id'] = $vo['room_id'];
            $search['bed_type'] = $bedType;
            $search['day_room_type'] = $vo['day_room_type'];
            $search['sold_rule_id'] = $vo['sold_rule_id'];
            $search['date'] = array(array('EGT', trim($rangeArr[0])), array('ELT', trim($rangeArr[1])));
            $result['filter'] = explode(',', $vo['multiconditional']);
            $result['info'] = D($this->Model)->where($search)->field('id')->select();

            $idlist = array();
            foreach ($result['info'] as $item => &$val) {
                $idlist[] = $val['id'];
            }

            $day_room_type_txt = '';
            if ($vo['day_room_type'] == 1) {
                $day_room_type_txt = '保留房';
            } elseif ($vo['day_room_type'] == 2) {
                $day_room_type_txt = '非保留房';
            } elseif ($vo['day_room_type'] == 3) {
                $day_room_type_txt = '临时保留房';
            }

            $result['inputData'] = array(
                'hotelName' => $hotelName,
                'hotel_type' => getName("Hotel", "hotel_type", "id='" . $vo['hotel_id'] . "'"),
                'sold_rule_title' => getName('sold_rule', 'sold_title', "id='" . $vo['sold_rule_id'] . "'"),
                'sold_rule_id' => $vo['sold_rule_id'],
                'roomName' => $roomName,
                'bedType' => $bedType,
                'dateRange' => $dateRange,
                'day_room_type' => $vo['day_room_type'],
                'day_room_type_txt' => $day_room_type_txt,
                'idlist' => $idlist,
            );

            $sold_rule_title = $result['inputData']['sold_rule_title'];

            if (count($result['info']) < 1) {
                $result['info'] = '没找到相关数据';
            } else {
                $day_room_type_txt = getRoomDayTypeText($vo['day_room_type']);
                $result['info'] = "</br>查到酒店名称为:<font style='font-weight: bold;color: red;'>$hotelName,</font>
                    房间名称为:<font style='font-weight: bold;color: red;'>$roomName</font>,
                    床型名称为：<font style='font-weight: bold;color: red;'>$bedType</font>,
                    售卖规则为：<font style='font-weight: bold;color: red;'>$sold_rule_title</font>,
                    房态类型为：<font style='font-weight: bold;color: red;'>$day_room_type_txt</font>,
                   时间范围为：<font style='font-weight: bold;color: red;'>$dateRange</font>,
                的酒店房态数据共<font style='font-weight: bold;color: red;'>" . count($result['info']) . "</font>条";
            }
            $this->success($result);
        }
    }

    /*上传房态数据*/
    public function uploadRoomData()
    {
        $upload = new Upload();
        $upload->maxSize = 1024 * 1024;
        $upload->exts = array('xls', 'xlsx');
        $upload->rootPath = PRIVATE_FILE_PATH;
        $upload->savePath = '/Uploads/RoomState/';
        $info = $upload->uploadOne($_FILES['file']);
        if (!$info) {
            $this->error($upload->getError());
        } else {
            $filePath = $upload->rootPath . $info['savepath'] . $info['savename'];
            $result = $this->saveExcelFileData($filePath);
            if ($result['code'] === 50000) {
                $this->success('数据上传成功');
            } else {
                $this->error($result['msg']);
            }
        }
    }

    /*保存数据到数据库*/
    private function saveExcelFileData($fileName)
    {
        if (!file_exists($fileName)) return array('code' => 20000, 'msg' => '文件不存在');
        $fieldName = M($this->Model)->getDbFields();
        unset($fieldName['id'], $fieldName['create_time'], $fieldName['create_admin'], $fieldName['update_name'], $fieldName['old_price']);
        $extension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        vendor("PHPExcel.PHPExcel.IOFactory");
        if ($extension == 'xlsx') {
            $objReader = \IOFactory::createReader('Excel2007');
            $objPHPExcel = $objReader->load($fileName, $encode = 'utf-8');
        } else if ($extension == 'xls') {
            $objReader = \IOFactory::createReader('Excel5');
            $objPHPExcel = $objReader->load($fileName, $encode = 'utf-8');
        } else {
            return array('code' => 20000, 'msg' => '文件格式不正确');
        }
        $sheet = $objPHPExcel->getSheet(0);
        $highestRow = $sheet->getHighestRow();//取得总行数
        $highestColumn = $sheet->getHighestColumn(); //取得总列数

        for ($i = 2; $i <= $highestRow; $i++) {
            $rowArr = array();
            for ($j = 'A'; $j <= $highestColumn; $j++) {
                $rowArr[] = $objPHPExcel->getActiveSheet()->getCell($j . $i)->getValue();
            }
            $arrData[] = $rowArr;
        }
        $fieldData = array_shift($arrData);
        if (array_diff($fieldData, $fieldName)) {
            return array('code' => 20000, 'msg' => '字段名错误');
        } else {
            $saveData = array_map(function ($v) use ($fieldData) {
                $v = array_map(function ($v1) {
                    return strip_tags(htmlspecialchars($v1, ENT_QUOTES));//对excel表数据安全处理
                }, $v);
                return array_combine($fieldData, $v);
            }, $arrData);

            $dataArr = array();
            foreach ($saveData as $item => $value) {
                $saveData[$item]['create_time'] = time();
                $saveData[$item]['create_admin'] = session('username');
                $saveData[$item]['date'] = excel_date_format($saveData[$item]['date']);
                $dataArr[] = excel_date_format($saveData[$item]['date']);
            }
            $this->checkSoldRule($saveData[0], $dataArr);
            $res = $this->checkRoomDate($saveData);
            if ($res) {
                return array('code' => 20000, 'msg' => '房态数据有重复，请先查询确认');
            }

            $result = D($this->Model)->addAll($saveData);
            if ($result) {
                return array('code' => 50000);
            } else {
                return array('code' => 20000, 'msg' => $result);
            }
        }
    }


    public function volist()
    {
        $breads = $this->bread();

        //酒店列表
        $hotellist = D('Hotel')->field('id,title')->select();
        $data = array();
        foreach ($hotellist as $item => &$val) {
            $val['name'] = $val['title'];
            $val['value'] = $val['id'];
            unset($val['title'], $val['id']);
            $data[] = $val;
        }

        //房型列表 begin
        $roomlist = D('Hotel')->alias('H')->where(array('H.status' => 1, 'R.state' => 1))->join('left join tns_room as R ON R.hotel_id=H.id')->field('R.id,R.hotel_id,H.title as hotel_title,R.title as room_title')->select();
        $newArray = array();
        foreach ($roomlist as $v) {
            $newArray[$v['hotel_id']][] = $v;
        }
        foreach ($newArray as $item => $value) {
            $sublist = array();
            foreach ($value as $ite => $val) {
                $arr['name'] = $val['room_title'];
                $arr['value'] = $val['id'];
                $sublist['children'][] = $arr;
            }
            $sublist['name'] = $value[0]['hotel_title'];
            $sublist['value'] = $value[0]['hotel_id'];
            $list[] = $sublist;
        }
        //房型列表 end

        //酒店城市列表
        $cityList = D('Hotel')->field('city_code,city')->group('city_code')->select();
        foreach ($cityList as $item => $val) {
            $val['name'] = $val['city'];
            $val['value'] = $val['city_code'];
            unset($val['city_code'], $val['city']);
            $datacity[] = $val;
        }

        $this->assign('bread', $breads);
        $this->assign('citylist', json_encode($datacity, true, JSON_UNESCAPED_UNICODE));
        $this->assign('roomlist', json_encode($list, true, JSON_UNESCAPED_UNICODE));
        $this->assign('hotellist', json_encode($data, true, JSON_UNESCAPED_UNICODE));
        $this->display();
    }

    //ajaxlist数据加载
    public function ajaxlist()
    {
        // 预加载变量
        $datatb = $this->Model;                // 主数据库
        $order = $this->order;                // 排序
        $page = $this->pageNum;                // 分页条数
        $pkid = $this->PkId;                // 主键ID字段名称
        $fields = $this->Fields;            // 打开字段

        // 加载数据库
        $Admin = D($datatb);

        if (strlen($fields) < 1) {
            $fields = "*";
        }

        // pkid 设置
        if (strlen($pkid) < 1) {
            $pkid = $Admin->getPk();
        }

        if (strlen($pkid) < 1) {
            $pkid = "RM.id";
        }

        // 分页条数设置
        if ($page < 1) {
            $page = 20;
        }

        //排序
        if (count($order) < 1) {
            $order = "RM.id desc";
        }

        $search = array();
        $search = $this->_search($datatb);

        if (isset($search['hotel_id'])) {
            $search['RM.hotel_id'] = $search['hotel_id'];
            unset($search['hotel_id']);
        }
        if (isset($search['room_id'])) {
            $search['RM.room_id'] = $search['room_id'];
            unset($search['room_id']);
        }

        if (isset($search['state'])) {
            $search['RM.state'] = $search['state'];
            unset($search['state']);
        }

        if (isset($search['refund_state'])) {
            $search['RM.refund_state'] = $search['refund_state'];
            unset($search['refund_state']);
        }

        if (isset($search['is_breakfast'])) {
            $search['RM.is_breakfast'] = $search['is_breakfast'];
            unset($search['is_breakfast']);
        }

        $date_range = I('get.date_range');
        if (!empty($date_range) && $date_range != '') {
            $range = explode('|', $date_range);

            if ($_GET['p'] >= 1) {
                $range[0] = str_replace('+', '', $range[0]);
                $range[1] = str_replace('+', '', $range[1]);
            }
            $search['RM.date'] = array(array('EGT', trim($range[0])), array('ELT', trim($range[1])));
        }

        $city_codes = I('get.city_code');
        if ($city_codes != '') {
            $search['H.city_code'] = array('IN', $city_codes);
            unset($search['city_code']);
        }

        $count = $Admin->alias('RM')->where($search)
            ->join('inner join tns_room as R ON R.id=RM.room_id')
            ->join('inner join tns_sold_rule as S ON S.id = RM.sold_rule_id')
            ->join('inner join tns_hotel as H ON H.id=RM.hotel_id')->field($pkid)->count();
        import("@.ORG.Util.Page"); //导入分页类
        $p = new Page($count, $page);

        $list = $Admin->alias('RM')->where($search)
            ->join('inner join tns_room as R ON R.id=RM.room_id')
            ->join('inner join tns_sold_rule as S ON S.id = RM.sold_rule_id')
            ->join('inner join tns_hotel as H ON H.id=RM.hotel_id')
            ->field("RM.*,H.city_code,H.city,H.title as hotel_title,R.title as room_title,S.sold_title")
            ->order($order)->limit($p->firstRow . ',' . $p->listRows)->select();
        $page = $p->show();

        $this->assign("total", $count);
        $this->assign("list", $list);
        $this->assign("page", $page);
        $this->display();
    }

    //数据添加
    public function insert()
    {
        $User = new RoomStateModel();
        $vo = $User->create();
        if (!$vo) {
            $error = $User->getError();
            $this->error($error);
        } else {

            //判断指数间夜单价不能为0
            if ($vo['index_day_price'] <= 0.00) {
                $this->error('酒店指数间夜单价不能为零');
            }

            //导入房态时将售卖规则的单价导入
            $sold_rule = D('sold_rule')->where(array('id' => $vo['sold_rule_id']))->find();
            $vo['time_range'] = explode(' - ', $vo['time_range']);
            $dateArr = dateNum($vo['time_range'][0], $vo['time_range'][1]);
            //判断录入的房态数据是否包含在售卖规则的日期内
            $this->checkSoldRule($vo, $dateArr);

            unset($vo['time_range']);
            //数据转换
            $arrList = array();
            foreach ($dateArr as $item => &$value) {
                $arrList[$item] = $vo;
                $arrList[$item]['date'] = $value;
                $arrList[$item]['now_price'] = ceil(($sold_rule['room_money'] * 10000 / 100) / $sold_rule['even_live_num']) / 100;
                $arrList[$item]['now_price_rmb'] = ceil(($sold_rule['room_money_rmb'] * 10000 / 100) / $sold_rule['even_live_num']) / 100;
                //判断设置的日期是否小于当前的日期，小于则自动将状态设置为暂停
                if ($arrList[$item]['date'] < date('Y-m-d', time() - 60 * 60 * 24)) {
                    $arrList[$item]['state'] = 2;
                } else {
                    $arrList[$item]['state'] = $vo['state'];
                }
            }

            $result = $this->checkRoomDate($arrList);
            if ($result) $this->error('房态数据有重复，请先查询确认');

            //添加房态的属性表数据
            $data = array(
                'hotel_id' => $vo['hotel_id'],
                'room_id' => $vo['room_id'],
                'bed_type' => $vo['bed_type'],
                'sold_rule_id' => $vo['sold_rule_id'],
                'is_out_sold' => $vo['is_out_sold'],
                'out_sold_count' => $vo['out_sold_count'],
                'day_room_type' => $vo['day_room_type'],
                'live' => $vo['live'],
                'is_breakfast' => $vo['is_breakfast'],
                'refund_state' => $vo['refund_state'],
                'refund_remark' => $vo['refund_remark'],
            );
            $room_attr_id = M('room_attr')->add($data);
            if (!$room_attr_id) {
                $this->error('添加房态数据失败');
                exit();
            }

            foreach ($arrList as $item2 => &$value2) {
                $value2['attr_room_id'] = $room_attr_id;
            }

            $result = $User->addAll($arrList); //添加房态
            if ($result) {
                // 添加日志
                add_log("添加房态信息成功", cn_substr($User->getLastSql(), 100));
                $this->success("添加成功");
            } else {
                $error = $User->getError();
                $this->error($error);
            }
        }
    }

    /** 判断录入的房态数据是否包含在售卖规则的日期内
     * @param $vo 房态属性
     * @param $dateArr 日期数组
     */
    public function checkSoldRule($vo, $dateArr)
    {

        $soldRuleModel = new SoldRuleModel();
        $soldRuleArr = $soldRuleModel->where(array('id' => $vo['sold_rule_id']))->find();
        if ($soldRuleArr['is_even_live'] == 1) {
            if ($soldRuleArr['even_live_num'] > count($dateArr)) {
                $this->error('房态时间与售卖规则的连住天数不符');
            }
            if ($soldRuleArr['week_set'] == 1) {
                //判断星期及天数
                $weekarray = array(7, 1, 2, 3, 4, 5, 6);
                $even_start_week = $weekarray[date('w', strtotime($dateArr[0]))];
                $even_end_week = $weekarray[date('w', strtotime($dateArr[count($dateArr) - 1]))];
                if ($soldRuleArr['even_week_start'] != $even_start_week || $soldRuleArr['even_week_end'] != $even_end_week) {
                    $this->error('房态时间的星期与售卖规则不符');
                }
            }
        }
    }

    //检查房态数据是否重复
    private function checkRoomDate($arrList)
    {
        foreach ($arrList as $ite => $val) {
            $dateList[] = $val['date'];
        }
        $dbFields = D('day_price')->getDbFields();
        foreach ($dbFields as $it => $val) {
            $arr_key = array_keys($arrList[0]);
            $arr_value = array_values($arrList[0]);
            foreach ($arr_value as $ii => $vv) {
                if ($arr_key[$ii] == $dbFields[$it]) $where[$arr_key[$ii]] = $vv;
            }
        }

        //剔除掉不需要查询的条件
        unset($where['create_time'], $where['now_price_rmb'], $where['now_price'],
            $where['index_day_price'], $where['old_price'], $where['update_time'],
            $where['create_admin'], $where['day_sold_count']);

        $where['date'] = array('IN', $dateList);
        $roomStateModel = new RoomStateModel();
        $result = $roomStateModel->where($where)->find();
        return $result;
    }


    //数据修改
    public function update()
    {
        $datatb = $this->Model;
        $User = D($datatb); // 实例化User对象
        $data = $User->create();
        if (!$data) {
            $error = $User->getError();
            $this->error($error);
        } else {

            $info = $data;
            unset($info['id']);
            $list[] = $info;
            $result = $this->checkRoomDate($list);
            if ($result) {
                $this->error('房态数据有重复，请先查询确认');
            }

            if ($data['now_price_rmb'] == '') {
                $data['now_price_rmb'] = null;
            }
            if ($data['now_price'] == '') {
                $data['now_price'] = null;
            }

            //添加数据
            $id = $User->save($data);
            if ($id) {
                add_log("修改信息成功", cn_substr($User->getLastSql(), 100));
                $this->success("修改信息成功");
            } else {
                $this->error($User->getError());
            }
        }
    }


    public function add()
    {
        $hotellist = D('Hotel')->field(array('id,title'))->select();
        $this->assign('hotellist', $hotellist);
        $this->display();
    }

    //编辑页面
    public function edit()
    {
        $datatb = $this->Model;
        $Admin = D($datatb);
        $id = intval($_REQUEST["id"]);
        $query = $Admin->getPk() . "=" . $id;
        $arr = $Admin->where($query)->find();
        if ($arr) {

            //根据酒店类型判断支付金额
            $hotelModel = new HotelModel();
            $hotelType = $hotelModel->where(array('id' => $arr['hotel_id']))->getField('hotel_type');
            $hotellist = D('Hotel')->field(array('id,title'))->select();
            $this->assign('hotelType', $hotelType);
            $this->assign('hotellist', $hotellist);
            $this->assign("arr", $arr);
            $this->display();
        } else {
            $this->error("没有找到您要的内容！");
        }
    }


    //得到酒店的房型
    public function getRoomType()
    {
        $id = I('get.id');
        $list = D('Room')->where(array('hotel_id' => $id))->field('id,title,hotel_id')->select();

        //得到酒店的定价方式(2020-08-17新增)
        $hotelModel = new HotelModel();
        $hotelType = $hotelModel->where(array('id' => $id))->getField('hotel_type');
        echo json_encode(array(
            'data' => $list,
            'hotel_type' => $hotelType,
            'msg' => 'success',
            'code' => '200',
        ), JSON_UNESCAPED_UNICODE);
    }

    //获取床型数组
    public function getBedTypeArr()
    {
        $id = I('get.id');
        $list = D('Room')->where(array('id' => $id))->find();

        echo json_encode(array(
            'data' => $list,
            'msg' => 'success',
            'code' => '200',
        ), JSON_UNESCAPED_UNICODE);
    }

    //通过选择房型从而确定床型
    public function getBedType()
    {
        $id = I('get.id');
        $arr = D('Room')->where(array('id' => $id))->find();
        //2020-08-18 新增获取房态的售卖规则
        $ruleModel = new SoldRuleModel();
        $rule_list = $ruleModel->where(array('room_id' => $id))->select();
        echo json_encode(array(
            'data' => $arr,
            'rules' => $rule_list,
            'msg' => 'success',
            'code' => '200',
        ), JSON_UNESCAPED_UNICODE);
    }


}
