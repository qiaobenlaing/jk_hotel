<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/5/18
 * Time: 15:03
 */

namespace Admin\Controller;


use Org\Util\Tree;

class SortController extends AdminBaseController
{
    public $Model = "Sort";

    //添加下一级分类
    public function add_next_menu()
    {
        $id = I('get.id');
        $datatb = $this->Model;
        $Sort = D($datatb); // 实例化User对象
        $arr = $Sort->where(array('id' => $id))->find();
        $this->assign('arr', $arr);
        $this->display('Sort/add');
    }

    //数据添加
    public function insert()
    {

        $datatb = $this->Model;
        $User = D($datatb); // 实例化User对象
        $vo = $User->create();
        if (!$vo) {
            $error = $User->getError();
            $this->error($error);
        } else {

            //字段替换
            if ($_SERVER['HTTP_HOST'] == C('formal_host')) {
                $result = $this->fastDfsUploadImg(I('post.icon'));
                $vo['icon'] = $result;
            }else{
                $ossInfo = $this->base64ToImages(I('post.icon'));
                $vo['icon'] = $ossInfo['url'];
            }

            //添加数据
            $id = $User->add($vo);
            if ($id) {
                // 添加日志
                add_log("添加信息成功", cn_substr($User->getLastSql(), 100));
                $this->success("添加成功");
            } else {
                $this->error("添加失败，请重新添加");
            }
        }
    }

    //数据修改
    public function update()
    {
        $datatb = $this->Model;
        $User = D($datatb); // 实例化User对象
        $data = $User->create();
        if (!$data) {
            $error = $User->getError();
            $this->error($error);
        } else {
            if (substr($data['icon'],0,5)=='data:') { //判断不为网络图片，而是base64编码图片
                if ($_SERVER['HTTP_HOST'] == C('formal_host')) {
                    $result = $this->fastDfsUploadImg($data['icon']);
                    $data['icon'] = $result;
                } else {
                    $ossInfo = $this->base64ToImages($data['icon']);
                    $data['icon'] = $ossInfo['url'];
                }
            }
            //添加数据
            $id = $User->save($data);
            if ($id) {
                add_log("修改信息成功", cn_substr($User->getLastSql(), 100));
                $this->success("修改信息成功");
            } else {
                $this->error($User->getError());
            }
        }
    }

    public function ajaxlist()
    {
        // 预加载变量
        $datatb = $this->Model;                // 主数据库
        $order = $this->order;                // 排序
        $page = $this->pageNum;              // 分页条数
        $pkid = $this->PkId;                // 主键ID字段名称
        $fields = $this->Fields;            // 打开字段

        // 加载数据库
        $Admin = D($datatb);

        if (strlen($fields) < 1) {
            $fields = "*";
        }

        // pkid 设置
        if (strlen($pkid) < 1) {
            $pkid = $Admin->getPk();
        }

        if (strlen($pkid) < 1) {
            $pkid = "id";
        }

        // 分页条数设置
        if ($page < 1) {
            $page = 20;
        }

        //排序
        if (count($order) < 1) {
            $order = "id desc";
        }

        $search = $this->_search($datatb);
        $list = $Admin->where($search)->field("*")->order($order)->select();

        //生成树形菜单节点
        import("Org.Util.Tree");
        $Tree = new Tree();
        // 新的输出素组
        $arr = array();
        // 组合数组
        foreach ($list as $key => $row) {
            $Tree->setNode($row["id"], $row["parent_id"], $row["title"], $row);
        }
        $cat = $Tree->getChilds();
        foreach ($cat as $key => $row) {
            $id = $cat[$key];
            $arr[$key]["id"] = $id;
            $arr[$key]["name"] = $Tree->getValue($id);
            $arr[$key]["pr"] = $Tree->getLayer($id);
            $arr[$key]["arr"] = $Tree->getArr($id);
            //统计当前级别
            $pagePv = strlen($arr[$key]["pr"]);
            //统计下一级别
            $nextPv = strlen($Tree->getLayer($cat[$key + 1]));
            if ($pagePv >= $nextPv) {
                //如果有下一级才允许删除
                $isDel = 1;
            } else {
                $isDel = 0;
            }
            $arr[$key]["del"] = $isDel;
            $arr[$key]["lever"] = count($Tree->getNodeLever($id));
        }
        $this->assign("list", $arr);
        $this->display();
    }
}
