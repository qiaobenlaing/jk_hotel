<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2018/8/3
 * Time: 11:34
 */

namespace Admin\Controller;
use Admin\Model\GroupModel;
use Org\Util\Page;
use Org\Util\Tree;

class ManagerController extends AdminBaseController
{
    public $Model = "Admin";

    //管理员添加
    public function add()
    {
        //获取所有用户角色
        $GroupModel = new GroupModel();
        $allrole = $GroupModel->getAllUserRole();
        //设置面包屑
        $breads = $this->bread();
        $this->assign("roles", $allrole);
        $this->assign("bread", $breads);
        $this->display();
    }

    //修改管理员信息
    public function edit(){
        $id = I("get.id");
        $arr = D($this->Model)->where(array("id"=>$id))->field("*")->find();
        $this->assign("arr",$arr);
        $this->display();
    }

    //管理员列表
    public function volist(){
        //设置面包屑
        $breads = $this->bread();
        $this->assign("menu_id",I("get.menu_id"));
        $this->assign("bread", $breads);
        $this->display();
    }

    //管理员修改密码(页面)
    public function editpass(){
        //设置面包屑
        $breads = $this->bread();
        $this->assign("menu_id",I("get.menu_id"));
        $this->assign("bread", $breads);
        $this->display();
    }

    //修改管理员实际操纵
    public function updateManagerPwd(){
        $adminModel = D("Admin");
        $data = I("post.");
        //判断新密码跟确认密码是否相等
        if($data['newPassword']!=$data['confirmPassword']){
            $this->error("新密码跟确认密码不相等");
        }
        //新密码判断
        if(strlen($data['newPassword'])<6 || strlen($data['newPassword'])>16){
            $this->error("新密码位数必须在6到16个字符之间");
        }

        //查询原密码正确性
        $oldPassword =  md5($data['oldPassword']);
        //取得我自己的id(注意修改管理员密码只能修改个人的)
        $user_id = $_SESSION['id'];

        $arr = $adminModel->where(array("password"=>$oldPassword,"id"=>$user_id))->field("id,username,password")->find();
        if(!$arr){
            $this->error("原密码错误");
            exit;
        }
        //修改密码
        $res =  $adminModel->where(array("id"=>$user_id))->setField("password",md5($data['newPassword']));//setField(array("password"=>md5($data['newPassword'])))不能以单个数组形式设置。

        if($res){
            add_log("修改个人密码成功",cn_substr($adminModel->getLastSql(),100));
            $this->success("修改密码成功");

        }else{
            $this->error("修改密码失败，请重新试试");
        }
    }
}
