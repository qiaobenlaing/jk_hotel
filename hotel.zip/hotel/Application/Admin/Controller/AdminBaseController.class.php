<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2018/7/29
 * Time: 21:09
 */

namespace Admin\Controller;

use Org\Util\Page;
use PHPExcel;
use Think\Controller;
use OSS\Core\OssException;
use OSS\OssClient;

class  AdminBaseController extends Controller
{

    public function __construct()
    {
        parent::__construct();
        if (!isset($_SESSION['id']) || $_SESSION['id'] < 1) {
            redirect(U("Admin/Login/login"));
        }
    }

    function curlRequest($url, $params = array(), $is_post = false, $time_out = 10, $header = array())
    {
        $str_cookie = isset($ext_params['str_cookie']) ? $ext_params['str_cookie'] : '';
        $ch = curl_init();//初始化curl
        curl_setopt($ch, CURLOPT_URL, $url);//抓取指定网页
        curl_setopt($ch, CURLOPT_HEADER, 0);//设置是否返回response header
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);//要求结果为字符串且输出到屏幕上
        //当需要通过curl_getinfo来获取发出请求的header信息时，该选项需要设置为true
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, $time_out);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $time_out);
        curl_setopt($ch, CURLOPT_POST, $is_post);
        if ($is_post) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
        }
        if ($str_cookie) {
            curl_setopt($ch, CURLOPT_COOKIE, $str_cookie);
        }
        if ($header) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        }
        $response = curl_exec($ch);
        //打印请求的header信息
        $request_header = curl_getinfo($ch, CURLINFO_HEADER_OUT);
        curl_close($ch);
        return $response;
    }


    //文件下载
    public function downloadModule()
    {
        $arrFields = M($this->Model)->getDbFields();
        vendor("PHPExcel.PHPExcel");
        vendor("PHPExcel.PHPExcel.IOFactory");
        $excelObj = new PHPExcel();
        $sheetIndex = $excelObj->setActiveSheetIndex(0);
        $startExcelCol = 'A';

        $arrFieldsName = array('酒店编号', '房型编号', '房类型（1.保留2.非保留3.临时保留）', '日期', '状态','单价（指数）','单价（人民币）', '库存量', '售出数量', '是否有早（1.有2.无）', '床型',
            '退订政策(1.不可取消2.有条件取消3.免费取消)', '退订政策说明', '可住人数','售卖规则','是否超售','超售数量','指数间夜单价');
        foreach ($arrFieldsName as $k => $v) {
            $sheetIndex->setCellValue($startExcelCol . 1, $v);
            $startExcelCol++;
        }

        $i = 2;
        $startExcelCol2 = 'A';
        $unsetArr = array('id','old_price', 'create_admin', 'create_time', 'update_time');
        foreach ($arrFields as $k => $v) {
            if (!in_array($v, $unsetArr)) {
                $sheetIndex->setCellValue($startExcelCol2 . $i, $v);
                $startExcelCol2++;
            }
        }
        $sheetIndex->setTitle('导入房态数据模板');
        $objWriter = \IOFactory::createWriter($excelObj, 'Excel2007');
        header('Content-Type:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition:attachment;filename="template.xlsx"');
        header('Cache-Control:max-age=0');
        $objWriter = \IOFactory::createWriter($excelObj, 'Excel2007');
        $objWriter->save('php://output');
        exit;

    }


    public function volist()
    {
        $breads = $this->bread();
        $this->assign('bread', $breads);
        $this->display();
    }

    /**
     * + base64 to images
     * /**图片 base64位上传OSS*/
    public function base64ToImages($base64 = "")
    {
        vendor("aliyun.autoload");
        //阿里云配置
        $accessKeyId = C("accessKeyId");
        $accessKeySecret = C("accessKeySecret");
        // Endpoint以杭州为例，其它Region请按实际情况填写。
        $endpoint = C("endpoint");
        // 存储空间名称
        $bucket = C("bucketName");
        // 允许上传得mini类型
        $mini['data:image/png'] = ".png";
        $mini['data:image/jpeg'] = ".jpg";
        //返回路径
        $path = "";
        $base64Arr = explode(";base64,", $base64);
        if (strlen($mini[$base64Arr[0]]) > 0) {
            //创建文件保存路径
            $catalog = toDate(time(), "Ym");
            $sServerDir = "Public/Uploads/";
            if (!file_exists($sServerDir)) {
                mkdir($sServerDir);
            }
            $sServerDir = "Public/Uploads/" . $catalog . "/";
            if (!file_exists($sServerDir)) {
                mkdir($sServerDir);
            }
            // 生成上传文件名
            $path = $sServerDir . "_" . rand(100, 999) . "_" . microtime(true) . $mini[$base64Arr[0]];
            // 保存图片句柄
            $s = base64_decode($base64Arr[1]);
            // 临时文件
            $tmpfname = tempnam("/tmp/", "qiao");
            $handle = fopen($tmpfname, "w");
            if (fwrite($handle, $s)) {
                try {
                    $ossClient = new OssClient($accessKeyId, $accessKeySecret, $endpoint);
                    $imgpath = $ossClient->uploadFile($bucket, $path, $tmpfname);
                    // 函数关闭该$handle指针指向的文件。
                    fclose($handle);
                    //删除临时文件
                    unlink($tmpfname);
                } catch (OssException $e) {
                    $e->getMessage();
                    return false;
                }
            }
        }
        return $imgpath['info']; //返回图片OSS上完整路径
    }

    //fastDFS文件上传
    public function fastDfsUploadImg($base64 = "")
    {
        // 允许上传得mini类型
        $mini['data:image/png'] = ".png";
        $mini['data:image/jpeg'] = ".jpg";
        $base64Arr = explode(";base64,", $base64);
        if (strlen($mini[$base64Arr[0]]) > 0) {
            //创建文件保存路径
            $catalog = toDate(time(), "Ym");
            $sServerDir = "Public/Uploads/";
            if (!file_exists($sServerDir)) {
                mkdir($sServerDir);
            }
            $sServerDir = "Public/Uploads/" . $catalog . "/";
            if (!file_exists($sServerDir)) {
                mkdir($sServerDir);
            }
            // 生成上传文件名
            $path = $sServerDir . "_" . rand(100, 999) . "_" . microtime(true) . $mini[$base64Arr[0]];
            // 保存图片句柄
            $s = base64_decode($base64Arr[1]);
//            $res = file_put_contents($path, $s);
            // 临时文件
            $tmpfname = tempnam("/tmp/", "qiao");
            $handle = fopen($tmpfname, "w");
            if (fwrite($handle, $s)) {
                $tracker = fastdfs_tracker_get_connection();
                $storage = fastdfs_tracker_query_storage_store();
                if (!empty($storage)) {
                    $storage['store_path_index'] = C('store_path_index');
                }
                $result = fastdfs_storage_upload_by_filename($tmpfname, $mini[$base64Arr[0]], [], null, $tracker, $storage);
                fclose($handle);
                //删除临时文件
                unlink($tmpfname);
            }
        }
        return C('fast_dfs_url'). $result['group_name'] . '/' . $result['filename'];
    }




    //文件上传
    public function upload()
    {
        vendor("aliyun.autoload");
        $accessKeyId = C("accessKeyId");
        $accessKeySecret = C("accessKeySecret");
        // Endpoint以杭州为例，其它Region请按实际情况填写。
        $endpoint = C("endpoint");
        // 存储空间名称
        $bucket = C("bucketName");
        //錯誤信息
        $errinfo = array();
        //判断文件是否上传有误
        if ($_FILES['file']['error'] > 0) {
            $errinfo = array("status" => 2, "info" => $_FILES["file"]["error"]);
        }
        //1.判断文件上传类型
        $allowType = array("image/jpeg", "image/png", "image/gif", "image/bmp", "image/jpg");
        $type = $_FILES['file']['type'];
        if (!in_array($type, $allowType)) {
            $errinfo = array("status" => 1, "info" => "文件类型不支持");
        }
        //2.判断图片大小
        $fileSize = $_FILES['file']['size'];
        if ($fileSize > 45240000) {
            $errinfo = array("status" => 1, "info" => "图片太大");
        }
        //保存文件
        //1.判断文件路径是否存在(在阿里服务器同样创建一个跟本地服务器的名称相同目录放图片路径)
        $dir = "Public/Uploads/" . date("Y-m", time()) . "/";
        if (!is_dir($dir)) {
            mkdir($dir);
        }
        //防止文件重名
        $filename = md5(rand(10000, 99999) . microtime()) . "_" . $_FILES['file']['name'];
        $path = $dir . $filename;

        //判断文件是否存在
        if (file_exists($path)) {
            $errinfo = array("status" => 2, "info" => "文件已存在");

        }
        //判断以上异常情况的输出
        if (!empty($errinfo)) {
            echo json_encode(array("info" => $errinfo, "status" => 3));
            exit;
        }
        try {
            $ossClient = new OssClient($accessKeyId, $accessKeySecret, $endpoint);
            $imgpath = $ossClient->uploadFile($bucket, $path, $_FILES["file"]["tmp_name"]);

            echo json_encode(array("info" => "上传成功", "status" => 1, "path" => $imgpath));
            exit;

        } catch (OssException $e) {
            $mess = $e->getMessage();
            echo json_encode(array("info" => $mess, "status" => 2));
            exit;
        }
    }

    //ajaxlist数据加载
    public function ajaxlist()
    {
        // 预加载变量
        $datatb = $this->Model;                // 主数据库
        $order = $this->order;                // 排序
        $page = $this->pageNum;                // 分页条数
        $pkid = $this->PkId;                // 主键ID字段名称
        $fields = $this->Fields;            // 打开字段

        // 加载数据库
        $Admin = D($datatb);

        if (strlen($fields) < 1) {
            $fields = "*";
        }

        // pkid 设置
        if (strlen($pkid) < 1) {
            $pkid = $Admin->getPk();
        }

        if (strlen($pkid) < 1) {
            $pkid = "id";
        }

        // 分页条数设置
        if ($page < 1) {
            $page = 20;
        }

        //排序
        if (count($order) < 1) {
            $order = "id desc";
        }

        $search = array();
        $search = $this->_search($datatb);
        $count = $Admin->where($search)->field($pkid)->count();
        import("@.ORG.Util.Page"); //导入分页类
        $p = new Page($count, $page);

        $list = $Admin->where($search)->field("*")->order($order)->limit($p->firstRow . ',' . $p->listRows)->select();
        $page = $p->show();

        $this->assign("total", $count);
        $this->assign("list", $list);
        $this->assign("page", $page);
        $this->display();
    }

    //编辑页面
    public function edit()
    {
        $datatb = $this->Model;
        $Admin = D($datatb);
        $id = intval($_REQUEST["id"]);
        $query = $Admin->getPk() . "=" . $id;

        $arr = $Admin->where($query)->find();
        if ($arr) {
            $this->assign("arr", $arr);
            $this->display();
        } else {
            $this->error("没有找到您要的内容！");
        }
    }

    //面包屑
    public function bread()
    {
        $model = M();
        $menuid = I("get.menu_id");
        //取得symbol
        $insymbol = "select symbol from tns_menu where id='" . $menuid . "'";
        //取得所有菜单
        $sql = "select id,name,parent from tns_menu where symbol in(" . $insymbol . ")";
        $arr = $model->query($sql);
        //将二维数组以数据库主键方式输出
        $_menu_arr = array();
        foreach ($arr as $key => $row) {
            $_menu_arr[$row['id']] = $row;
        }
        if (count($_menu_arr) > 0) {
            $menu_id_2 = $_menu_arr[$menuid]['parent'];
            $menu_id_3 = $_menu_arr[$menu_id_2]['parent'];
        }
        $data = array("menu_1" => $_menu_arr[$menuid]['name'], "menu_2" => $_menu_arr[$menu_id_2]['name'], "menu_3" => $_menu_arr[$menu_id_3]['name']);

        return $data;
    }


    //数据添加
    public function insert()
    {
        $datatb = $this->Model;
        $User = D($datatb); // 实例化User对象
        $vo = $User->create();
        if (!$vo) {
            $error = $User->getError();
            $this->error($error);
        } else {
            //添加数据
            $id = $User->add($vo);
            if ($id) {
                // 添加日志
                add_log("添加信息成功", cn_substr($User->getLastSql(), 100));
                $this->success("添加成功");
            } else {
                $this->error("添加失败，请重新添加");
            }
        }
    }

    //数据删除(删除单个)
    public function del()
    {
        $datatb = $this->Model;
        $id = intval($_REQUEST["delId"]);
        $Form = D($datatb);
        $delState = $Form->where("id = '" . $id . "'")->delete();
        if ($delState) {
            $this->success("删除成功！");
        } else {
            $this->error($Form->getError());
        }
    }

    //批量删除
    public function delall()
    {
        $datatb = $this->Model;
        $id = implode(",", $_REQUEST["delId"]);
        $Form = D($datatb);
        $delState = $Form->where("id in(" . $id . ") ")->delete();
        if ($delState) {
            $this->success("删除成功！");
        } else {
            $this->error($Form->getError());
        }
    }

    //生成查询条件
    public function _search($name = '')
    {
        //生成查询条件
        if (empty($name)) {
            $name = $this->name;
        }
        $model = M($name);
        $map = array();
        foreach ($model->getDbFields() as $key => $val) {
            $value = $_GET[$val];
            if (is_numeric($value)) {
                if (intval($value) >= 0) {
                    $map[$val] = $value;
                }
            } else {
                if (!empty($value)) {
                    if (!strpos($value, ',')) {  //如果不包含逗号，代表数据单个字符串查询，有逗号则则证明是多选的传参（2020-05-24 乔本亮优化）
                        $map[$val] = array('like', '%' . $value . '%');
                    } else {
                        $map[$val] = array('in', $value);
                    }
                }
            }
        }
        return $map;
    }

    //数据修改
    public function update()
    {
        $datatb = $this->Model;
        $User = D($datatb); // 实例化User对象
        $data = $User->create();
        if (!$data) {
            $error = $User->getError();
            $this->error($error);
        } else {
            //添加数据
            $id = $User->save($data);
            if ($id) {
                add_log("修改信息成功", cn_substr($User->getLastSql(), 100));
                $this->success("修改信息成功");
            } else {
                $this->error($User->getError());
            }
        }
    }
    /**
     * 更新排序
     * +------------------------------------------
     * id            id 必须是数组
     * +------------------------------------------
     * Model        表示默认主数据模型
     * +------------------------------------------
     */
    public function updatesort()
    {
        $id = $_REQUEST["id"];
        $num = count($id);
        // 取得主表模型
        $Sort = D($this->Model);
        //判断传入排序ID是否数组，并且数字大于0
        if (is_array($id) && $num > 0) {
            for ($i = 0; $i < $num; $i++) {
                $id = intval($_REQUEST["id"][$i]);
                $sort = intval($_REQUEST["sort"][$i]);
                if ($sort < 1) {
                    $sort = 0;
                }
                // 执行更新
                $data['sort'] = $sort;
                $Sort->where("id='" . $id . "'")->save($data);
            }
            $this->success('排序更新成功');
        } else {
            $this->error('参数错误');
        }
    }
}
