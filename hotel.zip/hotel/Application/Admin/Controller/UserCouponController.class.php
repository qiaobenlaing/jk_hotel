<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2020/9/17 0017
 * Time: 13:52
 */

namespace Admin\Controller;


use http\Exception;
use Org\Util\Page;

class UserCouponController extends AdminBaseController
{

    public $Model = 'usercoupon';
    public $order = 'apply_time desc';

    /**
     * 导出的 excel
     */
    public function dowmData()
    {
        $search = I('post.');
        if ($search['coupon_name'] != '') {
            $search['C.coupon_name'] = array('LIKE', "%" . $search['coupon_name'] . "%");
        }

        if ($search['telphone'] != '') {
            $search['UC.telphone'] = array('LIKE', "%" . $search['telphone'] . "%");
        }

        if ($search['status'] != '') {
            $search['UC.status'] = $search['status'];
        }

        if ($search['date_range'] != '') {
            $range = explode('|', $search['date_range']);
            if ($_GET['p'] >= 1) {
                $range[0] = str_replace('+', '', $range[0]);
                $range[1] = str_replace('+', '', $range[1]);
            }
            $search['UC.apply_time'] = array(array('EGT', strtotime(trim($range[0]))), array('ELT', strtotime(trim($range[1]))));
        }

        if ($search['used_range'] != '') {
            $range = explode('|', $search['used_range']);
            if ($_GET['p'] >= 1) {
                $range[0] = str_replace('+', '', $range[0]);
                $range[1] = str_replace('+', '', $range[1]);
            }
            $search['UC.used_time'] = array(array('EGT', strtotime(trim($range[0]))), array('ELT', strtotime(trim($range[1]))));
        }
        unset($search['used_range']);
        unset($search['date_range']);
        unset($search['status']);
        unset($search['telphone']);
        unset($search['coupon_name']);

        $list = D($this->Model)->where($search)->alias('UC')->join('tns_coupon as C ON C.id=UC.coupon_id')
            ->field('UC.start_using_time,UC.used_time,UC.expire_time,UC.apply_time,UC.status,UC.order_no,UC.telphone,UC.coupon_id,C.coupon_name')
            ->order('apply_time desc')->select();

        foreach ($list as $item => &$value) {
            $value['start_using_time'] = toDate($value['start_using_time']);
            $value['used_time'] = toDate($value['used_time']);
            $value['apply_time'] = toDate($value['apply_time']);
            $value['expire_time'] = toDate($value['expire_time']);
            $value['status'] = CouponState($value['status']);
        }

        if ($list) {
            $this->success($list);
        } else {
            $this->error('数据为空');
        }
    }

    public function ajaxlist()
    {
        // 预加载变量
        $datatb = $this->Model;                // 主数据库
        $order = $this->order;                // 排序
        $page = $this->pageNum;                // 分页条数
        $pkid = $this->PkId;                // 主键ID字段名称
        $fields = $this->Fields;            // 打开字段

        // 加载数据库
        $Admin = D($datatb);

        if (strlen($fields) < 1) {
            $fields = "*";
        }

        // pkid 设置
        if (strlen($pkid) < 1) {
            $pkid = $Admin->getPk();
        }

        if (strlen($pkid) < 1) {
            $pkid = "id";
        }

        // 分页条数设置
        if ($page < 1) {
            $page = 20;
        }

        //排序
        if (count($order) < 1) {
            $order = "id desc";
        }

        $search = array();
        $search = $this->_search($datatb);
        $coupon_type = I('get.coupon_type');
        $coupon_name = I('get.coupon_name');
        $send_type = I('get.send_type');
        $status = I('get.status');

        if ($status == 3) {
            $search['UC.expire_time'] = array('LT', time());
            unset($search['status']);
        }
        if (!empty($send_type)) {
            $search['UC.send_type'] = $send_type;
            unset($search['send_type']);
        }
        if (!empty($coupon_type)) {
            $search['C.coupon_type'] = $coupon_type;
        }
        if (!empty($coupon_name)) {
            $search['C.coupon_name'] = array('like', '%' . $coupon_name . '%');
        }

        //领取时间查询
        $date_range = I('get.date_range');
        if (!empty($date_range) && $date_range != '') {
            $range = explode('|', $date_range);

            if ($_GET['p'] >= 1) {
                $range[0] = str_replace('+', '', $range[0]);
                $range[1] = str_replace('+', '', $range[1]);
            }
            $search['UC.apply_time'] = array(array('EGT', strtotime(trim($range[0]))), array('ELT', strtotime(trim($range[1]))));
        }

        //使用时间范围
        $date_range = I('get.used_range');
        if (!empty($date_range) && $date_range != '') {
            $range = explode('|', $date_range);

            if ($_GET['p'] >= 1) {
                $range[0] = str_replace('+', '', $range[0]);
                $range[1] = str_replace('+', '', $range[1]);
            }
            $search['UC.used_time'] = array(array('EGT', strtotime(trim($range[0]))), array('ELT', strtotime(trim($range[1]))));
        }

        $count = $Admin->where($search)->alias('UC')->join('tns_coupon as C ON C.id =UC.coupon_id')
            ->field("C.coupon_name,C.validity_period,C.coupon_type,
        C.expire_time,UC.*")->count();
        import("@.ORG.Util.Page"); //导入分页类
        $p = new Page($count, $page);
        $list = $Admin->where($search)->alias('UC')->join('tns_coupon as C ON C.id =UC.coupon_id')
            ->field("C.coupon_name,C.validity_period,C.coupon_type,
        C.expire_time,UC.*")
            ->order($order)->limit($p->firstRow . ',' . $p->listRows)->select();

        foreach ($list as $item => &$value) {

            $status = $value['status'];

            if ($status== 1) {
                $value['status'] = '<span class="layui-badge layui-bg-green">可使用</span>';
            } else if ($status == 2) {
                $value['status'] = '<span class="layui-badge" style="color: #f0ad4e;">已使用</span>';
            } else if ($status== 3) {
                $value['status'] = '<span class="layui-badge warning">冻结</span>';
            } else {
                $value['status'] = '<span class="layui-badge layui-bg-gray">不可用</span>';
            }

            //判断是否过期
            if ($value['expire_time'] < time()) {
                $value['status'] = '<span class="layui-badge layui-bg-red">已过期</span>';
            }

            if ($value['order_no'] == '') {
                $value['order_no'] = '暂未使用';
            }

            $value['apply_time'] = toDate($value['apply_time']);
            $value['used_time'] = toDate($value['used_time']);
            $value['expire_time'] = toDate($value['expire_time']);

            if ($value['send_type'] == 1) {
                $value['send_type'] = '<span class="layui-badge layui-bg-red">平台发放</span>';
            } elseif ($value['send_type'] == 2) {
                $value['send_type'] = '<span class="layui-badge layui-bg-green">用户领取</span>';
            }

            $value['coupon_type'] = couponTypeText($value['coupon_type']);
            if ($value['used_time'] == '') {
                $value['used_time'] = '暂未使用';
            }
        }

        $page = $p->show();

        $this->assign("total", $count);
        $this->assign("list", $list);
        $this->assign("page", $page);
        $this->display();
    }

}