<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2018/7/29
 * Time: 21:22
 */

namespace Admin\Controller;

class IndexController extends  AdminBaseController
{

    //顶部菜单
    public function top(){
        //获取上面顶部大菜单栏
        $menu  =  $this->getBigMenu();
        $this->assign("list",$menu);
        $this->display();
    }

    //左侧菜单
    public function left(){
        $Menu = D("Menu");
        // 取得主类ID
        $pid = intval($_REQUEST["pid"]);
        if($pid < 1){
            $list = $this->getBigMenu();
            $pid = $list[0]["id"];
        }
        //取得授权菜单ID
        $level = $this->getGroup($_SESSION["group_id"]);
        //取得大类id
        $big_menu = $Menu->field("id")->where("parent='".$pid."' and symbol='admin' and id in (".$level.")")->select();

        //数组转为字符串
        $big_menu = array_to_string($big_menu);

        //查询所有菜单
         $list =  $Menu->where("(parent in(".$big_menu.") and id in(".$level.")) or id in(".$big_menu.")")->field("id,name,parent,url,icon")->order("sort,id")->select();
        // 组合菜单数据
        $list = array_tree($list,'id','parent','_child',$pid);

        $this->assign("list",$list);

        $this->display();
    }


    //取得大菜单
    private function getBigMenu(){
            $level = $this->getGroup($_SESSION['group_id']);
            $Model = D("Menu");
            $list = $Model->where("parent='0' and id in (".$level.") and symbol='admin'")->field("id,name,icon")->order("sort,id")->select();
            return $list;
    }

    //取得权限列表
    private function getGroup($groupid = 0){
        //用户菜单ID
        $level = "";
        //超级管理员
        $super = trim(C("super_user"));
        //判断是否为超级管理员
        if(trim($_SESSION['username'])!=$super){
            //根据分组取得菜单ID
            $groupModel = D("Group");
            $arr = $groupModel->getById($groupid);

            $level = $arr['menu_id'];

            $_SESSION['rank']  = $level['rank'];
            $_SESSION['auth']  = $arr['auth_id'];

        }else{
            //超级管理员
                $Menu   = D("Menu");
                $level  = $Menu->where("symbol='admin'")->field("id")->select();
                foreach ($level as $key =>$value){
                    $id[$key] = $value['id'];
                }
                //取得所有的大菜单
                $level = implode(",",$id);
                //超级管理员不受限制
                $_SESSION['rank'] = 1;
        }
        return $level;
    }
}
