<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2018/8/7
 * Time: 8:44
 */

namespace Admin\Controller;


class AdminLogController extends AdminBaseController
{
        //日志页面
        public function loglist(){
            $breads =  $this->bread();
            $this->assign("bread",$breads);
            $this->display();
        }

        //删除10天的系统日志
        public function dellog(){
            $Log = D("Log");
            //删除一个月前的操作日志
            $time = time()- 60*24*60*30;//30天前
            //删除条件
            $vo =  $Log->where("read_time < ".$time)->delete();
            if($vo){
                $this->success("删除成功");
            }else{
                $this->error("删除失败");
            }
        }

        //分页日志ajax加载
        public function ajaxlist(){
            $AdminLog = D("Log");

            $data =  I("get.");
            //当前页数
            $pageOffSet = $data['page'];
            if($pageOffSet<1){
                $pageOffSet = 1;
            }
            //每页限制条数
            $pageSize =  $data['limit'];
            //起步数
            $pageFirst = $pageSize*($pageOffSet-1);
            //总数据条数
            $count =$AdminLog->field("id")->count();
            //数据分页
            $list = $AdminLog->field("*")->limit($pageFirst.",".$pageSize)->order("read_time desc")->select();

            foreach ($list as $key => &$row){
                $row['read_time'] = toDate($row['read_time']);
            }

            echo  json_encode(array("data"=>$list,"code"=>0,"msg"=>"222","count"=>$count));
        }
}