<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/5/29
 * Time: 13:44
 */

namespace Admin\Controller;


class CalendarController extends AdminBaseController
{


    public function getData(){

        $date_start = date('Y-m-d',strtotime(I('get.start'))); //开始日期
        $date_end = date('Y-m-d',strtotime(I('get.end'))); //结束日期
        $list =    D('day_price')->where(array('D.hotel_id'=>'49','date'=>array(array('gt',$date_start),array('lt',$date_end))))->alias('D')->
        join('tns_hotel as H ON H.id=D.hotel_id')->join('tns_room as R ON R.id=D.room_id')
            ->field('H.title as h_title,R.title as r_title,D.id as id,H.id as h_id,R.id as r_id,D.`is_breakfast`,
       D.date,D.now_price,D.day_room_type')->select();

        $data_list =array();
        foreach ($list as $item => &$value){
            $data['id'] = $value['id'];
            $data['title'] = $value['r_title'].' '. $this->RoomDayTypeText($value['day_room_type']).' '.$value['now_price'].' '.$this->breakFast($value['is_breakfast']);
            $data['start'] = $value['date'];
            $data['allDay'] = true;
            $data['color'] = 'green';
            $data_list[] =$data;
        }

        echo json_encode($data_list,true,JSON_UNESCAPED_UNICODE);
    }

    //早餐
    function breakFast($value){
        switch ($value) {
            case 1:
                $value = "有早";
                break;
            case 2:
                $value = "无早";
                break;
            default:
                $value = "";
                break;
        }
        return $value;
    }

    //房型
    function RoomDayTypeText($value)
    {
        switch ($value) {
            case 1:
                $value = "保留房";
                break;
            case 2:
                $value = "非保留房";
                break;
            default:
                $value = "临时保留房";
                break;
        }
        return $value;
    }


}
