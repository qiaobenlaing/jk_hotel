<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2018/8/7
 * Time: 11:04
 */
namespace Admin\Controller;

use Org\Util\Tree;

class MenuController extends AdminBaseController
{
    public $Model = "Menu";

    //菜单页面
    public function volist(){
        $MenuModel = D("Menu");
        $list = $MenuModel->field("id,name,parent,symbol,url,admin,sort")->select();

        //生成树形菜单节点
        import("Org.Util.Tree");
        $Tree = new Tree();
        // 新的输出素组
        $arr = array();

        // 组合数组
        foreach($list as $key=>$row){
            $Tree->setNode($row["id"],$row["parent"],$row["name"],$row);
        }
        $cat = $Tree->getChilds();
        foreach($cat as $key=>$row){
            $id = $cat[$key];
            $arr[$key]["id"] = $id;
            $arr[$key]["name"] = $Tree->getValue($id);
            $arr[$key]["pr"] = $Tree->getLayer($id);
            $arr[$key]["arr"] = $Tree->getArr($id);
            //统计当前级别
            $pagePv = strlen($arr[$key]["pr"]);
            //统计下一级别
            $nextPv = strlen($Tree->getLayer($cat[$key+1]));
            if($pagePv>=$nextPv){
                //如果有下一级才允许删除
                $isDel = 1;
            }else{
                $isDel = 0;
            }
            $arr[$key]["del"] = $isDel;
            $arr[$key]["lever"] = count($Tree->getNodeLever($id));
        }

        $this->assign("list",$arr);
        $breads = $this->bread();
        // 取得菜单标识
        $symbol = re_html($_REQUEST["symbol"]);
        $this->assign("symbol",$symbol);
        $this->assign("bread",$breads);
        $this->display();
    }

    //添加大菜单
    public function add(){
        $arr["symbol"] = re_html($_REQUEST["symbol"]);
        $this->assign("arr",$arr);
        $this->display();
    }

    //修改菜单
    public function edit_menu(){
        $id = I("get.id");
        $arr = D("menu")->where("id='".$id."'")->field("name,symbol,id,parent,url")->find();
        $arr["symbol"] = re_html($_REQUEST["symbol"]);
        $this->assign("arr",$arr);
        $this->display();
    }

    //添加下级菜单
    public function add_next_menu(){
        $id = I("get.id");
        $arr = D("menu")->where("id='".$id."'")->field("name,symbol,id,parent,url")->find();
        $arr["symbol"] = re_html($_REQUEST["symbol"]);
        $this->assign("arr",$arr);
        $this->display();
    }

    //删除所选菜单
    public function delmenu(){
        $data = I("post.data");
        $data =strip_tags($data);
        $data = str_replace("[","",$data);
        $data = str_replace("]","",$data);
        $Model = $this->Model;
        $result =  D($Model)->where("id in (".$data.")")->delete();
        if($result){
            // 添加日志
            add_log("批量删除菜单成功",cn_substr(D($Model)->getLastSql(),100));
            $this->success("删除成功");
        }else{
            $this->error("删除失败");
        }
    }

    //删除单个菜单
    public function del(){
        $id  = I("get.id");
        $result =  D("Menu")->where(array("id"=>$id))->delete();
        if($result){
            // 添加日志
            add_log("删除单个菜单成功",cn_substr(D("Menu")->getLastSql(),100));
            $this->success("删除成功");
        }else{
            $this->error("删除失败");
        }
    }

    //修改操作
    public function update(){
        $MenuModel =    D("Menu");
        $data =    $MenuModel->create($_REQUEST,2);
        if(!$data){
            $this->error($MenuModel->getError());
        }
        $result = $MenuModel->save($data);

        if($result){
            // 添加日志
            add_log("修改菜单成功",cn_substr($MenuModel->getLastSql(),100));
            $this->success("修改成功");
        }else{
            $this->error("修改失败");
        }
    }


    //添加操作
    public function insert(){
            $MenuModel =    D("Menu");
            $vo =    $MenuModel->create($_REQUEST,1);
            if($vo){
                $res =  $MenuModel->add($vo);
                if($res){
                    // 添加日志
                    add_log("添加菜单成功",cn_substr($MenuModel->getLastSql(),100));
                    $this->success("添加成功");
                }else{
                    $this->error("添加失败");
                }
            }else{
                $this->error($MenuModel->getError());
            }
    }
}
