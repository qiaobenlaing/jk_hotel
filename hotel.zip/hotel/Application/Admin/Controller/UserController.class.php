<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/7/30
 * Time: 10:28
 */

namespace Admin\Controller;


use Org\Util\Page;

class UserController extends AdminBaseController
{

    public $Model = 'User';
    public $order = 'id desc';

    //批量暂停留言
    public function del()
    {
        $datatb = $this->Model;
        $id = implode(",", $_REQUEST["delId"]);
        $Form = D($datatb);
        $delState = $Form->where("id in(" . $id . ") ")->save(array('status'=>'2'));
        if ($delState) {
            $this->success("删除成功！");
        } else {
            $this->error($Form->getError());
        }
    }

    public function getCoupon()
    {
        $Admin = D('Usercoupon');
        $id = intval($_REQUEST["id"]);
        $list = $Admin->alias('UC')->join('tns_user as U ON UC.user_id=U.id')
            ->join('tns_coupon as C ON UC.coupon_id=C.id')->field('U.nickname,C.coupon_name,C.validity_period,UC.apply_time,UC.expire_time,UC.send_type,UC.used_time,UC.order_no,UC.status')
            ->where(array('UC.user_id' => $id))->select();
        foreach ($list as $item => &$value) {

            if ($value['status'] == 1) {
                $value['status'] = '<span class="layui-badge layui-bg-green">可使用</span>';
            } else if ($value['status'] == 2) {
                $value['status'] = '<span class="layui-badge" style="color: #f0ad4e;">已使用</span>';
            } else if ($value['status'] == 3) {
                $value['status'] = '<span class="layui-badge warning">冻结</span>';
            } else {
                $value['status'] = '<span class="layui-badge layui-bg-gray">不可用</span>';
            }

            //判断是否过期
            if ($value['expire_time'] < time()) {
                $value['status'] = '<span class="layui-badge layui-bg-red">已过期</span>';
            }

            if ($value['send_type'] == 1) {
                $value['send_type'] = '<span class="layui-badge layui-bg-red">平台发放</span>';
            } elseif ($value['send_type'] == 2) {
                $value['send_type'] = '<span class="layui-badge layui-bg-green">用户领取</span>';
            }

            if($value['order_no']=='') {
                $value['order_no'] = '暂未使用';
            }

            $value['apply_time'] = toDate($value['apply_time']);
            $value['used_time'] = toDate($value['used_time']);
            $value['expire_time'] = toDate($value['expire_time']);


            if($value['used_time']=='') {
                $value['used_time'] = '暂未使用';
            }
        }
        echo json_encode($list, JSON_UNESCAPED_UNICODE);
    }
}
