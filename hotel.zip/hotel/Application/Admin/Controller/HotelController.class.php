<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/5/20
 * Time: 15:48
 */

namespace Admin\Controller;


use Org\Util\Pinyin;
use Think\Upload;

class HotelController extends AdminBaseController
{


    public static $FACILITY = '19'; //设施父类编号
    public static $SERVICE = '28'; //服务父类编号
    public static $HOTELTYPE = '21'; //酒店类型
    public static $STARLEVEL = '20';//酒店星级

    public $order = 'update_time desc';
    public $Model = 'Hotel';

    /*上传房态数据*/
    public function uploadHotlData()
    {
        $upload = new Upload();
        $upload->maxSize = 1024 * 1024;
        $upload->exts = array('xls', 'xlsx');
        $upload->rootPath = PRIVATE_FILE_PATH;
        $upload->savePath = '/Uploads/HotelInfo/';
        $info = $upload->uploadOne($_FILES['file']);

        if (!$info) {
            $this->error($upload->getError());
        } else {
            $filePath = $upload->rootPath . $info['savepath'] . $info['savename'];
            $result = $this->saveExcelFileData($filePath);
            if ($result['code'] === 50000) {
                $this->success('数据上传成功');
            } else {
                $this->error($result['msg']);
            }
        }
    }

    /*保存数据到数据库*/
    private function saveExcelFileData($fileName)
    {
        if (!file_exists($fileName)) return array('code' => 20000, 'msg' => '文件不存在');
        $fieldName = M($this->Model)->getDbFields();
        unset($fieldName['id'], $fieldName['create_time'], $fieldName['create_admin'], $fieldName['update_name']);
        $extension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        vendor("PHPExcel.PHPExcel.IOFactory");
        if ($extension == 'xlsx') {
            $objReader = \IOFactory::createReader('Excel2007');
            $objPHPExcel = $objReader->load($fileName, $encode = 'utf-8');
        } else if ($extension == 'xls') {
            $objReader = \IOFactory::createReader('Excel5');
            $objPHPExcel = $objReader->load($fileName, $encode = 'utf-8');
        } else {
            return array('code' => 20000, 'msg' => '文件格式不正确');
        }
        $sheet = $objPHPExcel->getSheet(0);
        $highestRow = $sheet->getHighestRow();//取得总行数
        $highestColumn = $sheet->getHighestColumn(); //取得总列数
        for ($i = 2; $i <= $highestRow; $i++) {
            $rowArr = array();
            for ($j = 'A'; $j <= $highestColumn; $j++) {
                $rowArr[] = $objPHPExcel->getActiveSheet()->getCell($j . $i)->getValue();
            }
            $arrData[] = $rowArr;
        }

        $fieldData = array_shift($arrData);
        if (array_diff($fieldData, $fieldName)) {
            return array('code' => 20000, 'msg' => '字段名错误');
        } else {
            $saveData = array_map(function ($v) use ($fieldData) {
                $v = array_map(function ($v1) {
                    return strip_tags(htmlspecialchars($v1, ENT_QUOTES));//对excel表数据安全处理
                }, $v);
                return array_combine($fieldData, $v);
            }, $arrData);
            foreach ($saveData as $item => $value) {
                $saveData[$item]['create_time'] = time();
                $saveData[$item]['create_admin'] = session('username');
                $pinyin = new Pinyin();
                $saveData[$item]['english_title'] = $pinyin->p($saveData[$item]['title'], 1); // 英文名
                $input = array('中心商圈', '城市中心', '度假乐园', '亲近自然');
                $rand = array_rand($input, 1);
                $saveData[$item]['address_introduce'] = $input[$rand];
                $saveData[$item]['lng'] = abs($saveData[$item]['lng']);
//                $saveData[$item]['badges'] = ["性价比","交通便利","干净整洁","房间设施齐全","离景点近"];
//                $saveData[$item]['facilities'] = '3,4,5,7,8,53,57';
//                $saveData[$item]['service'] = '30,31,45,46,47,48,49,50,51,52,58,66';
//                $saveData[$item]['pre_explation'] = ["1.如需预订酒店，需缴纳交换服务费；","2.已支付订单，我们将为您保留整晚房间至次日下午14:00；","3.未支付订单最晚保留时间为入住当天18:00，过时将不再为您保留房间；","4.请确保入住登记人与预订人身份信息符合；","5.本酒店不可取消，如您取消预订，我们将不退还您的置换点数；"];
//                $saveData[$item]['replace_money'] = 100;
//                $saveData[$item]['room_money_type'] =["1","4"];
//                $saveData[$item]['index_day_price'] =1.5;
//                多图上传替换
                $imgarr = array();
                $imss = json_decode(html_entity_decode($saveData[$item]['imgarr']), true);
                foreach ($imss as $it => $value) {
                    $imgarr[$it]['title'] = '测试';
                    $imgarr[$it]['img'] = $value;
                }
                $saveData[$item]['imgarr'] = json_encode($imgarr, JSON_UNESCAPED_UNICODE);
            }
            $result = D($this->Model)->addAll($saveData);
            if ($result) {
                return array('code' => 50000);
            } else {
                return array('code' => 20000, 'msg' => $result);
            }
        }
    }


    public function volist()
    {
//        $data['badges'] = json_encode(["性价比","交通便利","干净整洁","房间设施齐全","离景点近"],JSON_UNESCAPED_UNICODE);
//        $data['facilities'] = '3,4,5,7,8,53,57';
//        $data['pre_explation'] = json_encode(["1.如需预订酒店，需缴纳交换服务费；","2.已支付订单，我们将为您保留整晚房间至次日下午14:00；","3.未支付订单最晚保留时间为入住当天18:00，过时将不再为您保留房间；","4.请确保入住登记人与预订人身份信息符合；","5.本酒店不可取消，如您取消预订，我们将不退还您的置换点数；"],JSON_UNESCAPED_UNICODE);
//        $data['replace_money'] = 100;
//        $data['room_money_type'] =json_encode(["1","4"],JSON_UNESCAPED_UNICODE);
//        $data['index_day_price'] =1.5;
//        $data['service'] = '30,31,45,46,47,48,49,50,51,52,58,66';
//        $data['id'] = array('gt',598);
//        D($this->Model)->save($data);


        $breads = $this->bread();
        $cityList = D('City')->where(array('status' => 1, 'level' => 3))->field('city_code,city_name')->select();

        $data = array();
        foreach ($cityList as $item => &$val) {
            $val['name'] = $val['city_name'];
            $val['value'] = $val['city_code'];
            unset($val['city_code'], $val['city_name']);
            $data[] = $val;
        }

        $this->assign('bread', $breads);
        $this->assign('cityList', json_encode($data, true, JSON_UNESCAPED_UNICODE));
        $this->display();
    }

    public function add()
    {
        $cityModel = D('City');
        $citylist = $cityModel->field('city_name,city_code')->select();
        $sort = [self::$SERVICE, self::$FACILITY, self::$HOTELTYPE, self::$STARLEVEL]; //4大分类
        $sortModel = D('Sort');
        $sortlist = $sortModel->where(array('parent_id' => array('IN', $sort)))->select();
        foreach ($sortlist as $item => &$value) {
            switch ($value['parent_id']) {
                case self::$FACILITY:
                    $facilities[] = $value;
                    break;
                case self::$SERVICE:
                    $service[] = $value;
                    break;
                case self::$HOTELTYPE:
                    $hotelTypes[] = $value;
                    break;
                case self::$STARLEVEL:
                    $starLevel[] = $value;
                    break;
                default:
                    break;
            }
        }
        $this->assign('citylist', $citylist);
        $this->assign('hoteltype', $hotelTypes);
        $this->assign('starlevel', $starLevel);
        $this->assign('facilities', $facilities);
        $this->assign('service', $service);
        $this->display();
    }

    public function edit()
    {
        $id = I('get.id');
        $arr = D($this->Model)->where(array('id' => $id))->find();
        $cityModel = D('City');
        $citylist = $cityModel->field('city_name,city_code')->select();
        $sort = [self::$SERVICE, self::$FACILITY, self::$HOTELTYPE, self::$STARLEVEL]; //4大分类
        $sortModel = D('Sort');
        $sortlist = $sortModel->where(array('parent_id' => array('IN', $sort)))->select();
        foreach ($sortlist as $item => &$value) {
            switch ($value['parent_id']) {
                case self::$FACILITY:
                    $facilities[] = $value;
                    break;
                case self::$SERVICE:
                    $service[] = $value;
                    break;
                case self::$HOTELTYPE:
                    $hotelTypes[] = $value;
                    break;
                case self::$STARLEVEL:
                    $starLevel[] = $value;
                    break;
                default:
                    break;
            }
        }

        $room_money_type = array(
            array('id' => 1, 'title' => '指数支付'),
            array('id' => 2, 'title' => '余额支付'),
            array('id' => 3, 'title' => '未来币支付'),
            array('id' => 4, 'title' => '指数+余额支付'),
            array('id' => 5, 'title' => '指数+未来币支付'),
        );

        $arr['room_money_type'] = implode(',', json_decode($arr['room_money_type'], true));

        $this->assign('arr', $arr);
        $this->assign('room_money_type', $room_money_type);
        $this->assign('citylist', $citylist);
        $this->assign('hoteltype', $hotelTypes);
        $this->assign('starlevel', $starLevel);
        $this->assign('facilities', $facilities);
        $this->assign('service', $service);
        $this->display();
    }

    public function insert()
    {
        $datatb = $this->Model;
        $User = D($datatb); // 实例化User对象
        $vo = $User->create();
        if (!$vo) {
            $error = $User->getError();
            $this->error($error);
        } else {

            // 英文名称
            if (empty($vo['english_title'])) {
                $pinyin = new Pinyin();
                $vo['english_title'] = $pinyin->p($vo['title'], 1);
            }
            //剔除两个checkbox 默认input 的值
            unset($vo['faci'], $vo['serv']);
            //图片上传OSS地址
            if ($_SERVER['HTTP_HOST'] == C('formal_host')) {
                $result = $this->fastDfsUploadImg($vo['img']);
            } else {
                $ossInfo = $this->base64ToImages($vo['img']);
                $result = $ossInfo['url'];
            }
            $vo['img'] = $result;
            //多图上传OSS地址替换和标题内容替换
            if (!empty($vo['pics'])) {
                $imgarr = array();

                foreach ($vo['content'] as $item => $v) {
                    $imgarr[$item]['title'] = $v;
                }
                foreach ($vo['pics'] as $item => $v) {
                    if ($_SERVER['HTTP_HOST'] == C('formal_host')) {
                        $result = $this->fastDfsUploadImg($v);
                        $imgarr[$item]['img'] = $result;
                    } else {
                        $ossUrl = $this->base64ToImages($v);
                        $imgarr[$item]['img'] = $ossUrl['url'];
                    }
                }
                $vo['imgarr'] = json_encode($imgarr, JSON_UNESCAPED_UNICODE);
                unset($vo['content'], $vo['pics']);
            } else {
                $this->error("酒店图片数组必须上传");
            }

            //如果置换费大于零，支付方式不能包含未来币，即3，5
            if ($vo['replace_money'] > 0) {
                foreach ($vo['room_money_type'] as $item => $val) {
                    if ($val == 3 || $val == 5) {
                        $this->error('置换费大于0，不允许使用包含未来币的支付方式');
                    }
                }
            }

            //判断支付方式和定价方式的关系
            if ($vo['hotel_type'] == 1 && (in_array(2, $vo['room_money_type']) || in_array(3, $vo['room_money_type']))) {
                $this->error('定价方式为指数，支付方式不能选择余额，未来币');
            }

            if ($vo['hotel_type'] == 2 && (in_array(1, $vo['room_money_type']) || in_array(4, $vo['room_money_type']) || in_array(5, $vo['room_money_type']))) {
                $this->error('定价方式为人民币，支付方式不能包含指数');
            }

            //支付类型转换为json数组
            if (is_array($vo['room_money_type']) && !empty($vo['room_money_type'])) {
                $vo['room_money_type'] = json_encode($vo['room_money_type'], JSON_UNESCAPED_UNICODE);
            } else {
                $this->error('支付方式必须选择');
            }

            //标签转换为json数组
            if (is_array($vo['badges']) && !empty($vo['badges'])) {
                $vo['badges'] = json_encode($vo['badges'], JSON_UNESCAPED_UNICODE);
            }

            //订房须知
            if (is_array($vo['pre_explation']) && !empty($vo['pre_explation'])) {
                $vo['pre_explation'] = json_encode($vo['pre_explation'], JSON_UNESCAPED_UNICODE);
            }

            //添加数据
            $id = $User->add($vo);
            if ($id) {
                // 添加日志
                add_log("添加信息成功", cn_substr($User->getLastSql(), 100));
                $this->success("添加成功");
            } else {
                $this->error("添加失败，请重新添加");
            }
        }
    }

    //数据删除(删除单个)
    public function del()
    {
        $datatb = $this->Model;
        $id = intval($_REQUEST["delId"]);
        $Form = D($datatb);
        $delState = $Form->where("id = '" . $id . "'")->delete();
        if ($delState) {
            //删除掉活动
            D('activity')->where(array('hotel_id' => $id))->delete();
            //删除房间
            D('room')->where(array('hotel_id' => $id))->delete();
            //删除房态
            D('day_price')->where(array('hotel_id' => $id))->delete();
            //删除评论
            D('comment')->where(array('hotel_id' => $id))->delete();

            $this->success("删除成功！");
        } else {
            $this->error($Form->getError());
        }
    }


    public function update()
    {
        $datatb = $this->Model;
        $User = D($datatb); // 实例化User对象
        $vo = $User->create();
        if (!$vo) {
            $error = $User->getError();
            $this->error($error);
        } else {

            // 英文名称
            if (empty($vo['english_title'])) {
                $pinyin = new Pinyin();
                $vo['english_title'] = $pinyin->p($vo['title'], 1);
            }
            //剔除两个checkbox 默认input 的值
            unset($vo['faci'], $vo['serv']);
            //酒店背景图片上传OSS地址
            if (substr($vo['img'], 0, 5) == 'data:') { //判断不为网络图片，而是base64编码图片
                if ($_SERVER['HTTP_HOST'] == C('formal_host')) {
                    $result = $this->fastDfsUploadImg($vo['img']);
                    $vo['img'] = $result;
                } else {
                    $ossUrl = $this->base64ToImages($vo['img']);
                    $vo['img'] = $ossUrl['url'];
                }
            }

            //酒店活动图片上传
            if ($vo['is_recommend'] == 1 && empty($vo['activity_img'])) {
                $this->error('酒店活动图必须上传');
            } else {
                if (substr($vo['activity_img'], 0, 5) == 'data:') { //判断不为网络图片，而是base64编码图片
                    if ($_SERVER['HTTP_HOST'] == C('formal_host')) {
                        $result = $this->fastDfsUploadImg($vo['activity_img']);
                        $vo['activity_img'] = $result;
                    } else {
                        $ossUrl = $this->base64ToImages($vo['activity_img']);
                        $vo['activity_img'] = $ossUrl['url'];
                    }
                }
            }

            //多图上传OSS地址替换和标题内容替换
            if (!empty($vo['pics'])) {
                $imgarr = array();
                foreach ($vo['content'] as $item => $v) {
                    $imgarr[$item]['title'] = $v;
                }
                foreach ($vo['pics'] as $item => $v) {
                    if (substr($v, 0, 5) == 'data:') { //判断不为网络图片，而是base64编码图片
                        if ($_SERVER['HTTP_HOST'] == C('formal_host')) {
                            $result = $this->fastDfsUploadImg($v);
                            $imgarr[$item]['img'] = $result;
                        } else {
                            $ossUrl = $this->base64ToImages($v);
                            $imgarr[$item]['img'] = $ossUrl['url'];
                        }
                    } else {
                        $imgarr[$item]['img'] = $v;
                    }
                }

                $vo['imgarr'] = json_encode($imgarr, JSON_UNESCAPED_UNICODE);
                unset($vo['content'], $vo['pics']);
            } else {
                $this->error("酒店图片数组必须上传");
            }

            //如果置换费大于零，支付方式不能包含未来币，即3，5
            if ($vo['replace_money'] > 0) {
                foreach ($vo['room_money_type'] as $item => $val) {
                    if ($val == 3 || $val == 5) {
                        $this->error('置换费大于0，不允许使用包含未来币的支付方式');
                    }
                }
            }

            //判断支付方式和定价方式的关系
            if ($vo['hotel_type'] == 1 && (in_array(2, $vo['room_money_type']) || in_array(3, $vo['room_money_type']))) {
                $this->error('定价方式为指数，支付方式不能选择余额，未来币');
            }

            if ($vo['hotel_type'] == 2 && (in_array(1, $vo['room_money_type']) || in_array(4, $vo['room_money_type']) || in_array(5, $vo['room_money_type']))) {
                $this->error('定价方式为人民币，支付方式不能包含指数');
            }

            //支付类型转换为json数组
            if (is_array($vo['room_money_type']) && !empty($vo['room_money_type'])) {
                $vo['room_money_type'] = json_encode($vo['room_money_type'], JSON_UNESCAPED_UNICODE);
            } else {
                $this->error('支付方式必须选择');
            }

            //标签转换为json数组
            if (is_array($vo['badges']) && !empty($vo['badges'])) {
                $vo['badges'] = json_encode($vo['badges'], JSON_UNESCAPED_UNICODE);
            }

            //订房须知
            if (is_array($vo['pre_explation']) && !empty($vo['pre_explation'])) {
                $vo['pre_explation'] = json_encode($vo['pre_explation'], JSON_UNESCAPED_UNICODE);
            }

            //酒店状态为暂停时，将酒店的活动状态也改为暂停
            if ($vo['status'] == 2) {
                D('Activity')->where(array('hotel_id' => $vo['id']))->save(array('status' => 2));
            }
            //添加数据
            $id = $User->save($vo);
            if ($id) {
                add_log("修改信息成功", cn_substr($User->getLastSql(), 100));
                $this->success("修改信息成功");
            } else {
                $this->error($User->getError());
            }
        }
    }

}
