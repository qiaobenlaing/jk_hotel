<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2018/8/9
 * Time: 9:00
 */

namespace Admin\Controller;
use Think\Controller;

class GroupController extends AdminBaseController
{
    public  $Model ="Group";

    //用户组主页
    public function volist(){
        $bread = $this->bread();
        $this->assign("bread",$bread);
        $this->display();
    }

    //添加用户组
    public function add(){
        $symbol = I("get.symbol");
        $menuModel =   D("Menu");
        // 类型设置
        $query = "symbol='".$symbol."'";
        if(strlen($symbol) < 1){
            $query = "symbol='admin'";
        }
        $list = $menuModel->where($query)->field("id,name,parent")->order("sort,id")->select();
        $menu_arr =      array_tree($list,"id","parent","_child");
        $this->assign("menu_arr",$menu_arr);
        $this->display();
    }

    //修改角色权限页面
    public function edit(){

        $id = I("get.id");
        $GroupModel =  D("Group");

        //菜单
        $symbol = I("get.symbol");
        $menuModel =   D("Menu");
        // 类型设置
        $query = "symbol='".$symbol."'";
        if(strlen($symbol) < 1){
            $query = "symbol='admin'";
        }
        $list = $menuModel->where($query)->field("id,name,parent")->order("sort,id")->select();
        $menu_arr =      array_tree($list,"id","parent","_child");
        $arr =   $GroupModel->where(array("id"=>$id))->find();

        $this->assign("menu_arr",$menu_arr);
        $this->assign("arr",$arr);
        $this->display();
    }

    //修改角色权限操作
    public function update(){
        $data = I("post.");
        $data['menu_id'] = implode(",",$data['menu_id']);
        $result =      D("Group")->where(array("id"=>$data['id']))->save($data);
        if($result){
            $this->success("修改成功");
        }else{
            $this->error("修改失败,请重新提交试试");
        }
    }

    public function insert(){
        $GroupModel =  D("Group");
        $vo =  $GroupModel->create();
        if(!$vo){
                $this->error($this->getError());
        }else{
            //添加数据
            $id = $GroupModel->add($vo);
            if($id){
                $this->success("添加成功");
            }else{
                $this->error("添加失败，请重新添加");
            }
        }
    }

}
