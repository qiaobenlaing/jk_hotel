<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/5/24
 * Time: 14:59
 */

namespace Admin\Controller;


use Common\Model\HotelModel;
use Common\Model\RoomModel;
use Common\Model\SoldRuleModel;

class RoomController extends AdminBaseController
{
    public $Model = 'Room';
    public $order = 'update_time desc';


    public function add()
    {
        $hotellist = D('Hotel')->field(array('id,title'))->select();
        $this->assign('hotellist', $hotellist);
        $this->display();
    }

    //查看所有售卖规则
    public function showSoldRule()
    {
        $soldRuleModel = new  SoldRuleModel();
        $list = $soldRuleModel->alias('S')->join('left join tns_room as R ON R.id=S.room_id')->join('left join tns_hotel as H ON H.id=R.hotel_id')->field('R.title,H.title as hotel_name,S.*')->select();
        foreach ($list as $item => &$value) {
            $value['even_week'] = implode(',', json_decode($value['even_week'], true));
            if ($value['week_set'] == 1) {
                $value['week_set'] = ' <span class="layui-badge red">是</span>';
            } else {
                $value['week_set'] = '<span class="layui-badge layui-bg-gray">否</span>';
            }
            if ($value['is_even_live'] == 1) {
                $value['is_even_live'] = ' <span class="layui-badge red">是</span>';
            } else {
                $value['is_even_live'] = '<span class="layui-badge layui-bg-gray">否</span>';
            }
        }
        echo json_encode($list, JSON_UNESCAPED_UNICODE);
    }

    public function edit()
    {
        $id = I('get.id');
        $arr = D($this->Model)->where(array('id' => $id))->find();
        $hotellist = D('Hotel')->field('id,title')->select();

        //查看售卖规则
        $rule_arr = M('sold_rule')->where(array('room_id' => $id))->find();
        if (!$rule_arr) $rule_arr['is_even_live'] = 2; //未找到就设置为不连住
        $this->assign('rule_arr', $rule_arr);
        $this->assign('arr', $arr);
        $this->assign('hotellist', $hotellist);
        $this->display();
    }

    public function editsold()
    {
        $id = I('get.id');
        $soldRuleModel = new SoldRuleModel();
        $arr = $soldRuleModel->where(array('id' => $id))->find();
        //判断房型酒店的定价类型
        $hotelModel = new HotelModel();
        $roomModel = new RoomModel();
        $hotel_id = $roomModel->where(array('id' => $arr['room_id']))->getField('hotel_id');
        $hotel_type = $hotelModel->where(array('id' => $hotel_id))->getField('hotel_type');
        $this->assign('hotel_type', $hotel_type);
        $this->assign('arr', $arr);
        $this->display();
    }

    public function addsold()
    {
        $id = I('get.id');
        $arr = D($this->Model)->where(array('id' => $id))->find();
        //判断房型酒店的定价类型
        $hotelModel = new HotelModel();
        $hotel_type = $hotelModel->where(array('id' => $arr['hotel_id']))->getField('hotel_type');
        $this->assign('hotel_type', $hotel_type);
        $this->assign('arr', $arr);
        $this->display();
    }

    //售卖规则页面
    public function sold()
    {
        $id = I('get.id');
        $arr = D($this->Model)->where(array('id' => $id))->find();
        $soldlist = D('sold_rule')->where(array('room_id' => $id))->select();
        //判断房型酒店的定价类型
        $hotelModel = new HotelModel();
        $hotel_type = $hotelModel->where(array('id' => $arr['hotel_id']))->getField('hotel_type');
        foreach ($soldlist as $item => &$value) {
            //连住
            $value['is_even_live'] == '1' ? $value['is_even_live'] = '<span class="layui-badge">是</span>' : $value['is_even_live'] = '<span class="layui-badge" style="background: #888;">否</span>';
            //星期
            $value['week_set'] == '1' ? $value['week_set'] = '<span class="layui-badge">是</span>' : $value['week_set'] = '<span class="layui-badge" style="background: #888;">否</span>';
            $value['even_week_start'] = getWeekTxt($value['even_week_start']);
            $value['even_week_end'] = getWeekTxt($value['even_week_end']);
        }
        $this->assign('soldlist', $soldlist);
        $this->assign('hotel_type', $hotel_type);
        $this->assign('arr', $arr);
        $this->display();
    }

    //新增/修改售卖规则
    public function soldRuleInsert()
    {

        $User = D('SoldRule');
        $vo = $User->create();
        if (!$vo) {
            $error = $User->getError();
            $this->error($error);
        } else {
            //结束星期(结束当天的前一天晚上)
            $even_week_end = ((($vo['even_live_num'] - 1) % 7) + $vo['even_week_start']) % 7;
            if ($even_week_end == 0) $even_week_end = 7;
            $vo['even_week_end'] = $even_week_end;

            //判断价格是否输入
            $roomModel = new RoomModel();
            $hotel_id = $roomModel->where(array('id' => $vo['room_id']))->getField('hotel_id');
            $hotelModel = new HotelModel();
            $hotel_type = $hotelModel->where(array('id' => $hotel_id))->getField('hotel_type');
            if ($hotel_type == 1) {
                $vo['room_money_rmb'] = null;
                if ($vo['room_money'] < 0.01) {
                    $this->error('总房费（指数）必须设置');
                }
            } elseif ($hotel_type == 2) {
                $vo['room_money'] = null;
                if ($vo['room_money_rmb'] < 0.01) {
                    $this->error('总房费（人民币）必须设置');
                }
            } else {
                if ($vo['room_money'] < 0.01 || $vo['room_money_rmb'] < 0.01) {
                    $this->error('总房费人民币和指数必须设置');
                }
            }

            //如果售卖规则不设置连住
            if ($vo['is_even_live'] == 2) {
                $vo['week_set'] = null;
                $vo['even_week_start'] = null;
                $vo['even_week_end'] = null;
                $vo['even_live_num'] = 1;
            }
            //如果连住星期不设置，即为2
            if ($vo['week_set'] == 2) {
                $vo['even_week_start'] = null;
                $vo['even_week_end'] = null;
            }

            if ($vo['extend_price'] < 0.01) {
                $this->error('酒店对外价格不能为0');
            }
            //判断是新增还是修改
            if ($vo['id']) {

//                unset($vo['even_week_end']);  //不要修改结束星期，因为开始星期设置disable之后获取不到了
                $result = $User->save($vo);
                if ($result) {
                    D($this->Model)->where(array('id' => $vo['room_id']))->save(array('update_time' => time()));
                    $this->success('修改规则信息成功');
                } else {
                    $this->error('修改规则信息失败');
                }
            } else {
                $result = $User->add($vo);
                if ($result) {
                    D($this->Model)->where(array('id' => $vo['room_id']))->save(array('update_time' => time()));
                    $this->success('添加规则成功');
                } else {
                    $this->error('添加规则失败');
                }
            }
        }
    }

    //删除售卖规则
    public function soldDel()
    {
        $datatb = 'sold_rule';
        $id = intval($_REQUEST["delId"]);
        $Form = D($datatb);
        $delState = $Form->where("id = '" . $id . "'")->delete();
        if ($delState) {
            //删除房态
            D('day_price')->where(array('sold_rule_id' => $id))->delete();
            $this->success("删除成功！");
        } else {
            $this->error($Form->getError());
        }
    }


    public function update()
    {
        $datatb = $this->Model;
        $User = D($datatb); // 实例化User对象
        $vo = $User->create();
        if (!$vo) {
            $error = $User->getError();
            $this->error($error);
        } else {

            //自定义属性
            if (!empty($vo['auto_property'])) {
                $auto_attr = array();
                foreach ($vo['auto_property'] as $item => $value) {
                    $auto_attr[$item]['name'] = $value;
                }
                foreach ($vo['auto_content'] as $item => $value) {
                    $auto_attr[$item]['value'] = $value;
                }
                $vo['auto_attr'] = json_encode($auto_attr, JSON_UNESCAPED_UNICODE);
                unset($vo['auto_content'], $vo['auto_property']);
            }

            //酒店背景图片上传OSS地址
            if (substr($vo['img'], 0, 5) == 'data:') { //判断不为网络图片，而是base64编码图片
                if ($_SERVER['HTTP_HOST'] == C('formal_host')) {
                    $result = $this->fastDfsUploadImg($vo['img']);
                    $vo['img'] = $result;
                } else {
                    $ossUrl = $this->base64ToImages($vo['img']);
                    $vo['img'] = $ossUrl['url'];
                }
            }

            //多图上传OSS地址替换和标题内容替换
            if (!empty($vo['pics'])) {
                $imgarr = array();
                foreach ($vo['content'] as $item => $v) {
                    $imgarr[$item]['title'] = $v;
                }
                foreach ($vo['pics'] as $item => $v) {
                    if (substr($v, 0, 5) == 'data:') { //判断不为网络图片，而是base64编码图片
                        if ($_SERVER['HTTP_HOST'] == C('formal_host')) {
                            $result = $this->fastDfsUploadImg($v);
                            $imgarr[$item]['img'] = $result;
                        } else {
                            $ossUrl = $this->base64ToImages($v);
                            $imgarr[$item]['img'] = $ossUrl['url'];
                        }
                    } else {
                        $imgarr[$item]['img'] = $v;
                    }
                }

                $vo['imgarr'] = json_encode($imgarr, JSON_UNESCAPED_UNICODE);
                unset($vo['content'], $vo['pics']);
            } else {
                $this->error("酒店图片数组必须上传");
            }

            //编辑数据
            $id = $User->save($vo);
            if ($id) {
                add_log("修改信息成功", cn_substr($User->getLastSql(), 100));
                $this->success("修改信息成功");
            } else {
                $this->error($User->getError());
            }
        }
    }


    //测试酒店是否有房型
    public function ceshi()
    {
        $list = D('Hotel')->field('id,title')->select();
        $roomList = D('Room')->field('hotel_id,id')->select();

        $hotelArr = array();
        foreach ($list as $k => $v) {
            $hotelArr[] = $v['id'];
        }
        $roomArr = array();
        foreach ($roomList as $item => $value) {
            $roomArr[] = $value['hotel_id'];
        }

        $num = 0;
        foreach ($hotelArr as $it => $va) {
            if (!in_array($va, $roomArr)) {
                echo '酒店编号' . $va . '不存在房型<br/>';
                $num++;
                $this->addRoomTest($va);
            }
        }
//        var_dump($num);
    }

    //测试访台的售卖规则是否存在
    public function test4()
    {
        $list = D('Sold_rule')->alias('S')->join('tns_room as R ON R.id=S.room_id')->where(array('H.id' => array('GT', 0)))->join('tns_hotel as H ON H.id = R.hotel_id')->field('H.id as H_id,R.id as R_id,S.id as S_id')->select();

        foreach ($list as $item => $value) {
            $data['hotel_id'] = $value['h_id'];
            $data['room_id'] = $value['r_id'];
            $data['sold_rule_id'] = $value['s_id'];
            $data['live'] = 1;
            $data['refund_remark'] = '不可取消';
            $data['bed_type'] = '超级温馨大床';
            $data['inventory'] = 0;
            $data['now_price'] = rand(1.0, 3.0);
            $data['day_room_type'] = 1;
            $data['date'] = '2020-10-30';
            $listaa[] = $data;
        }

//        $dataNum = dateNum('2020-08-30', '2020-10-30');

//        var_dump($listaa);

        $res = D('day_price')->addAll($listaa);
        var_dump($res);

    }

    //测试房型是否有售卖规则
    public function test2()
    {
        $list = D('Room')->field('title,id')->select();
        $roomList = D('Sold_rule')->field('room_id,id')->select();
        $hotelArr = array();
        foreach ($list as $k => $v) {
            $hotelArr[] = $v['id'];
        }

        $roomArr = array();
        foreach ($roomList as $item => $value) {
            $roomArr[] = $value['room_id'];
        }

        $num = 0;
        foreach ($hotelArr as $it => $va) {
            if (!in_array($va, $roomArr)) {
                echo '房型编号' . $va . '不存在售卖规则<br/>';
                $this->addSoldRule($va);
                $num++;
            }
        }
        var_dump($num);
    }


    private function addSoldRule($room_id)
    {
        $data['sold_title'] = '测试';
        $data['room_id'] = $room_id;
        $data['is_even_live'] = 1;
        $data['week_set'] = 1;
        $data['even_week_start'] = 1;
        $data['even_week_end'] = 3;
        $data['even_live_num'] = 2;
        $data['room_money'] = 2;
        $data['extend_price'] = 200;
        D('Sold_rule')->add($data);
    }

    private function addRoomTest($hotel_id)
    {
        $data['hotel_id'] = $hotel_id;
        $data['inventory'] = 0;
        $data['title'] = '大床房';
        $data['bed_type'] = '大床';
        $data['area'] = 20;
        $data['floor'] = '20楼';
        $data['network'] = '无线网络';
        $data['is_breakfast'] = 2;
        $data['refund_state'] = 1;
        $data['refund_remark'] = '不可取消';
        $data['img'] = 'http://hft-hotels.oss-cn-qingdao.aliyuncs.com/Public/Uploads/202006/_645_1592379432.5053.jpg';
        D($this->Model)->add($data);
    }


    public function volist()
    {
        $breads = $this->bread();
        $hotellist = D('Hotel')->field('id,title')->select();

        $data = array();
        foreach ($hotellist as $item => &$val) {
            $val['name'] = $val['title'];
            $val['value'] = $val['id'];
            unset($val['title'], $val['id']);
            $data[] = $val;
        }
        $this->assign('bread', $breads);
        $this->assign('hotellist', json_encode($data, true, JSON_UNESCAPED_UNICODE));
        $this->display();
    }


    //数据添加
    public function insert()
    {
        $datatb = $this->Model;
        $User = D($datatb); // 实例化User对象
        $vo = $User->create();
        if (!$vo) {
            $error = $User->getError();
            $this->error($error);
        } else {


            $result_room = D($datatb)->where(array('hotel_id' => $vo['hotel_id'], 'title' => $vo['title']))->field('id')->find();
            if ($result_room) {
                $this->error('该酒店下已有相同名字的房型');
            }

            //自定义属性
            if (!empty($vo['auto_property'])) {
                $auto_attr = array();
                foreach ($vo['auto_property'] as $item => $value) {
                    $auto_attr[$item]['name'] = $value;
                }
                foreach ($vo['auto_content'] as $item => $value) {
                    $auto_attr[$item]['value'] = $value;
                }
                $vo['auto_attr'] = json_encode($auto_attr, JSON_UNESCAPED_UNICODE);
                unset($vo['auto_content'], $vo['auto_property']);
            }

            //房间图片OSS上传
            if ($_SERVER['HTTP_HOST'] == C('formal_host')) {
                $fastUrl = $this->fastDfsUploadImg($vo['img']);
                $vo['img'] = $fastUrl;
            } else {
                $ossUrl = $this->base64ToImages($vo['img']);
                $vo['img'] = $ossUrl['url'];
            }

            //多图上传OSS地址替换和标题内容替换
            if (!empty($vo['pics'])) {
                $imgarr = array();

                foreach ($vo['content'] as $item => $v) {
                    $imgarr[$item]['title'] = $v;
                }
                foreach ($vo['pics'] as $item => $v) {
                    if ($_SERVER['HTTP_HOST'] == C('formal_host')) {
                        $fastUrl = $this->fastDfsUploadImg($v);
                        $imgarr[$item]['img'] = $fastUrl;
                    } else {
                        $ossUrl = $this->base64ToImages($v);
                        $imgarr[$item]['img'] = $ossUrl['url'];
                    }
                }
                $vo['imgarr'] = json_encode($imgarr, JSON_UNESCAPED_UNICODE);
                unset($vo['content'], $vo['pics']);
            } else {
                $this->error("酒店图片数组必须上传");
            }

            //添加数据
            $id = $User->add($vo);
            if ($id) {
                // 添加日志
                add_log("添加信息成功", cn_substr($User->getLastSql(), 100));
                $this->success("添加成功");
            } else {
                $this->error("添加失败，请重新添加");
            }
        }
    }

    //数据删除(删除单个)
    public function del()
    {
        $datatb = $this->Model;
        $id = intval($_REQUEST["delId"]);
        $Form = D($datatb);
        $delState = $Form->where("id = '" . $id . "'")->delete();
        if ($delState) {
            //删除房态
            D('day_price')->where(array('room_id' => $id))->delete();
            //删除售卖规则
            D('Sold_rule')->where(array('room_id' => $id))->delete();
            $this->success("删除成功！");
        } else {
            $this->error($Form->getError());
        }
    }


    public function _search($name = '')
    {
        //生成查询条件
        if (empty($name)) {
            $name = $this->name;
        }
        $model = M($name);
        $map = array();
        foreach ($model->getDbFields() as $key => $val) {
            $value = $_REQUEST[$val];
            if (is_numeric($value)) {
                if (intval($value) >= 0) {
                    $map[$val] = $value;
                }
            } else {
                if (!empty($value)) {
                    if (!strpos($value, ',')) {  //如果不包含逗号，代表数据单个字符串查询，有逗号则则证明是多选的传参（2020-05-24 乔本亮优化）
                        $map[$val] = array('like', '%' . $value . '%');
                    } else {
                        $map[$val] = array('in', $value);
                    }
                }
            }
        }
        return $map;
    }


}
