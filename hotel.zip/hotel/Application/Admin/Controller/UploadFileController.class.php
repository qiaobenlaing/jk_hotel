<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2018/8/6
 * Time: 10:19
 */
namespace Admin\Controller;

use Org\Util\Dir;
use Org\Util\Page;

class UploadFileController extends AdminBaseController
{
        public function volist(){
            $breads =  $this->bread();
            $url = U('Admin/File/ajaxlist?ajaxid=content');
            $this->assign("url",$url);
            $this->assign("bread",$breads);
            $this->display();
        }

        public function ajaxlist(){
            // 引入文件管理类型
            @import("@.ORG.Io.Dir");

            // 取得服务器配置目录
            $ser_path = C("savePath");
            $ser_path_nav = substr($ser_path,0,1);

            if($ser_path_nav == "/"){
                $ser_path = ".".$ser_path;
            }else{
                $ser_path = "./".$ser_path;
            }

            // 取得客户端上传目录名称
            // -- 是目录
            // 替换掉特殊字符
            // 客户端只能上传 dddd--bbbbb--aaaaa-ccccc 这样的目录结构
            $dirlist = str_replace("../","",trim($_REQUEST["dirlist"]));//去除安全隐患字符串
            $dirlist = str_replace("--","/",$dirlist);


            // 如果有目录名称，还原成真实目录路径
            // 客户端只能上传相对服务器配置目录后的相对路径
            if(strlen($dirlist)>0){
                $dirmn = substr($dirlist,count($dirlist)-2,count($dirlist)-1);

                // 如果目录结尾没有 / 就给加上 /
                if($dirmn != '/'){
                    $dirlist .= "/";
                }
            }

            // 当前所在目录地址组合
            $pathfile = $ser_path.$dirlist;

            // 组合默认加载网页URL地址请求参数
            $pageurl = '&dirlist='.str_replace("/","--",$dirlist);
            if(strlen($pageurl) < 11){
                $pageurl = "";
            }
            // 组合新的请求地址
            $pageurl = U('Admin/UploadFile/ajaxlist?ajaxid=content'.$pageurl);


            // 取得当前目录的所有文件
            $dir = new Dir($pathfile);
            $bb = $dir->toArray();
            $count = count($bb);

            //导入分页类
            @import("ORG.Util.Page"); //导入分页类
            $p= new Page($count);
            $page = $p->show();

            $list = $this->get_file_array($bb,$p->firstRow,$p->listRows);
            $this->assign("total",$count);

            //取得返回上一级路径
            $backdir = "";
            $str = explode("/",$dirlist);
            $icount = count($str)-3;
            for($i=0;$i<$icount;$i++){
                $backdir .= $str[$i]."/";
            }

            // 切换为请求目录地址
            $page_dir_list = str_replace("/","--",$dirlist);

            // 向网页输出转换过的目录路径
            $this->assign("dirlist",$page_dir_list);

            // 返回上一页目录路径
            $this->assign("backdir",$backdir);//取得返回上一级路径
            $dirlist = str_replace('----','--',$dirlist);

            // 组合文件目录目录
            $pathfile = $ser_path.$dirlist;

            // 输出列表
            $this->assign("list",$list);
            // 文件父目录路径
            $this->assign("pathfile",$pathfile);

            // 分页请求URL
            $this->assign("pageurl",$pageurl);
            $this->assign("page",$page);
            $this->display();
        }

        //删除文件
    public function delfiles(){
            $num = 0;
            $file =  I("get.files");
            $fileArr = explode(",",$file);

          foreach ($fileArr as $key => $row){
              if(unlink($row)){
                  $num++;
              }
          }
          if($num){
              $this->success("删除成功");
          }else{
              $this->error("删除失败");
          }
    }

    //目录文件分页计算
    private function get_file_array($arr = array(),$firstRow = 0,$listRows = 0){
        $list = array();

        if($firstRow+$listRows<=count($arr)){
            $listRows = $firstRow+$listRows;
        }else{
            $listRows = $firstRow+(count($arr)-$firstRow);
        }

        $k = 0;
        for($i=$firstRow;$i<$listRows;$i++){
            $list[$k] = $arr[$i];
            $k++;
        }
        return $list;
    }
}