<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2018/7/29
 * Time: 13:37
 */

namespace Admin\Controller;

use Admin\Model\AdminModel;
use Think\Controller;
use Think\Verify;

class LoginController extends Controller
{
    //登陆程序
    public function index()
    {
        redirect(U("Login/login"));
    }

    //登陆程序
    public function login(){
        //先清除session数据
        $_SESSION =session_destroy();
        $_SESSION = array();
//        开启session
        session_start();
        //拼接一个hash作为盐变量
        $hash = md5("123456");
        $_SESSION[$hash] = md5("123456");
        $this->assign("hash",$_SESSION[$hash]);
        $this->display();
    }

    //获取验证码
    public function Verify(){
        $verity = new Verify();
        $verity->fontSize = 17;
        $verity->length =3;
        $verity->codeSet = '0123456789';
        $verity->useNoise = false;
        $verity->entry();
    }

    //登陆处理类
    public  function  landing(){

        $data = I("post.");
        if(strlen($data['username'])<4 || strlen($data['username'])>16){
            $this->error("请输入用户名");
        }

        if(strlen($data['password'])!=32){
            $this->error("很遗憾，密码错误");
        }

        if($data['verfity']=='' || empty($data['verfity'])){
            $this->error('验证码必须输入');
        }

        $verify = new Verify();
        $verifyResult=   $verify->check($data['verfity']);

        if(!$verifyResult){
            echo json_encode(array('code'=>400,'message'=>'验证码有误'),JSON_UNESCAPED_UNICODE);
            exit();
        }
        $adminModel = new AdminModel();
        $res = $adminModel->login($data);

        if($res['status']==0){
            $this->error($res['info']);
        }else{
            // 添加日志
            add_log("登录成功",cn_substr($adminModel->getLastSql(),100));
            $this->success($res['info']);
        }
    }
}
