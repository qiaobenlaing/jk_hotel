<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/7/8
 * Time: 8:28
 */

namespace Admin\Controller;


use Common\Model\OrderModel;
use Common\Model\RoomModel;
use Common\Model\RoomStateModel;

class OrderController extends AdminBaseController
{

    public $Model = 'Order';
    public $order = 'createtime desc';

    //详情
    public function edit()
    {
        $datatb = $this->Model;
        $Admin = D($datatb);
        $arr = $Admin->where(array('O.id' => I('get.id')))->alias('O')->find();
        $arr['pay_type'] = json_decode($arr['pay_type']);
        $liucheng = D('Orderdetail')->where(array('order_no' => $arr['order_no']))->group('state')->order('createtime desc')->select();
        if ($arr) {
            $this->assign('liucheng', $liucheng);
            $this->assign("arr", $arr);
            $this->display();
        } else {
            $this->error("没有找到您要的内容！");
        }
    }

    //订单弹窗
    public function editInfo()
    {
        $datatb = $this->Model;
        $Admin = D($datatb);
        $id = intval($_REQUEST["id"]);
        $query = $Admin->getPk() . "=" . $id;
        $arr = $Admin->where($query)->find();
        $usernameArr = json_decode($arr['username'], true);
        $arr['username'] = implode(',', $usernameArr);
        $arr['state'] = getPayStateText($arr['state']);
        $arr['back_type'] = getRefundStateText($arr['back_type']);
        $arr['remark'] = json_decode($arr['remark'], true);
        $liucheng = D('Orderdetail')->where(array('order_no' => $arr['order_no']))->order('createtime desc')->select();

        $sold_rule_id = $arr['remark']['sold_rule_id'];
        $sold_rule_info = D('sold_rule')->where(array('id' => $sold_rule_id))->find();
        $sold_rule_info['is_even_live'] == 1 ? $sold_rule_info['is_even_live'] = "<span class='layui-badge layui-bg-red'>是</span>" : $sold_rule_info['is_even_live'] = "<span class='layui-badge layui-bg-gray'>否</span>";
        $sold_rule_info['week_set'] == 1 ? $sold_rule_info['week_set'] = "<span class='layui-badge layui-bg-red'>是</span>" : $sold_rule_info['week_set'] = "<span class='layui-badge layui-bg-gray'>否</span>";
        $sold_rule_info['even_week_start'] = getWeekTxt($sold_rule_info['even_week_start']);
        $sold_rule_info['even_week_end'] = getWeekTxt($sold_rule_info['even_week_end']);
        $sold_rule_info['room_money'] = $sold_rule_info['room_money'] == null ? '无' : $sold_rule_info['room_money'];
        $sold_rule_info['room_money_rmb'] = $sold_rule_info['room_money_rmb'] == null ? '无' : $sold_rule_info['room_money_rmb'];


        foreach ($liucheng as $item => &$value) {
            $value['createtime'] = toDate($value['createtime']);
            $value['state'] = getPayStateText($value['state']);
            $value['back_type'] = getRefundStateText($value['back_type']);
        }
        echo json_encode(array('order' => $arr, 'sold_rule_info' => $sold_rule_info, 'detail' => $liucheng), JSON_UNESCAPED_UNICODE);
    }

    //确认入住
    public function enterRoom()
    {
        $id = I('get.id');
        $orderModel = new OrderModel();
        $orderInfo = $orderModel->where(array('id' => $id))->find();

        $state = \Consts::ORDER_COMPLETED;
        //订单
        $data = array(
            'id' => $id,
            'state' => $state,
            'updatetime' => time(),
        );
        //订单详情数据
        $dataDetail = array(
            'order_no' => $orderInfo['order_no'],
            'state' => $state,
            'createtime' => time(),
        );

        M()->startTrans();
        $result = $orderModel->where(array('id' => $id))->save($data);
        $resultOrderDetail = D('Orderdetail')->add($dataDetail);

        if ($result && $resultOrderDetail) {
            M()->commit();
            $this->success('操作成功');
        } else {
            M()->rollback();
            $this->error('操作失败');
        }
    }

    //审核订单
    public function checkPass()
    {
        $orderNo = I('post.order_no');
        $flag = I('post.flag');
        $orderModel = new OrderModel();
        $orderInfo = $orderModel->where(array('order_no' => $orderNo))->find();

        if ($orderInfo['state'] == \Consts::ORDER_CONFIRM) {
            $this->error('已审核通过');
        }
        if ($orderInfo['state'] == \Consts::ORDER_CANCEL) {
            $this->error('订单已取消，不能反复操作');
        }

        //审核判断
        if ($flag == 1) { //通过


            //库存减少
            $remark = json_decode($orderInfo['remark'], true);
            $sold_rule_id = $remark['sold_rule_id'];
            $roomIn = $remark['roomIn']; //入住日期
            $roomOut = $remark['roomOut']; //离开日期
            $last_room_out = date("Y-m-d", (strtotime($roomOut) - 3600 * 24)); //离店日期的前一天，为实际入住的最后日期
            $roomNum = $remark['roomNum']; //房间数量
            $date = array('between', array($roomIn, $last_room_out)); //实际的入住日期


            //判断是否能库存足够
            $roomstateModel = new RoomStateModel();
            $sold_list = $roomstateModel->where(array('sold_rule_id' => $sold_rule_id, 'date' => $date))->field(array('is_out_sold', 'day_sold_count', 'inventory', 'out_sold_count'))->select();
            foreach ($sold_list as $item => $sold_info) {
                if ($sold_info['is_out_sold'] == 1) {
                    $sold_total_count = $sold_info['inventory'] + $sold_info['out_sold_count'];
                    if ($sold_info['day_sold_count'] >= $sold_total_count) {
                        $this->error('该房已售完');
                        exit();
                    }
                } else {
                    if ($sold_info['day_sold_count'] >= $sold_info['inventory']) {
                        $this->error('该房已售完');
                        exit();
                    }
                }
            }


            $state = \Consts::ORDER_CONFIRM;
            $backState = \Consts::CANCEL_NOT;

            M()->startTrans();
            $dataOrder = array(
                'id' => $orderInfo['id'],
                'state' => $state,
                'back_type' => $backState,
                'updatetime' => time(),
            );
            //订单详情数据
            $dataDetail = array(
                'order_no' => $orderNo,
                'state' => $state,
                'back_type' => $backState,
                'createtime' => time(),
            );
            $resultPreOrder = $orderModel->save($dataOrder);
            $resultOrderDetail = D('Orderdetail')->add($dataDetail);

            $resultRoom = $roomstateModel->where(array('sold_rule_id' => $sold_rule_id, 'date' => $date))->setInc('day_sold_count', $roomNum);
            if ($resultPreOrder && $resultOrderDetail && $resultRoom) {
                M()->commit();
                $this->success('操作成功');
            } else {
                M()->rollback();
                $this->error('操作失败');
            }

        } else { //不通过
            //订单退款
            $public_key = C('public_key');

            $data_refund['outRefundNo'] = $orderNo;
            $data_refund['transId'] = $orderInfo['api_order_no'];
            $pub_key = openssl_pkey_get_public($public_key);
            // 公钥加密
            openssl_public_encrypt(json_encode($data_refund, JSON_UNESCAPED_UNICODE), $encrypted, $pub_key);
            // 转码，这里的$encrypted就是公钥加密的字符串
            $encrypted = base64_encode($encrypted);

            $query =  C('REFUND_URL').'?hotel='.$encrypted.'&flag=pro';
            $result = $this->curlRequest($query, array(), false, 10);

            $resultArr = json_decode($result, true);

            $msg = '申请退款中...';
            if ($resultArr['messagecode'] == 1046 || $resultArr['messagecode'] == 1048) { //订单已退款

                $orderModel = new OrderModel();
                $orderInfo = $orderModel->where(array('order_no' => $orderNo))->find();

                $usercouponModel = D('usercoupon');
                $list = $usercouponModel->where(array('order_no' => $orderNo))->field('id')->select();
                $arr = array();
                foreach ($list as $item => $value) {
                    $arr[] = $value['id'];
                }
                if ($arr) {
                    $usercouponModel->where(array('id' => array('IN', $arr)))->save(array('status' => 1, 'used_time' => 0));
                }
                $dataOrder = array(
                    'id' => $orderInfo['id'],
                    'state' => \Consts::ORDER_CONFIRM_FAIL,
                    'back_type' => \Consts::CANCEL_REFUND,
                    'updatetime' => time(),
                );
                //订单详情数据
                $dataDetail = array(
                    'order_no' => $orderInfo['order_no'],
                    'state' => \Consts::ORDER_CONFIRM_FAIL,
                    'back_type' => \Consts::CANCEL_REFUND,
                    'createtime' => time(),
                );
                $orderModel->save($dataOrder);
                D('Orderdetail')->add($dataDetail);

                if ($resultArr['messagecode'] == 1048) {
                    $msg = '订单已退款';
                } else {
                    $msg = $resultArr['message'];
                }

                $this->success($msg);
            } elseif ($resultArr['messagecode'] == 1027) { //退款失败
                $msg = '退款失败,请到会员系统查询问题';
                $this->error($msg);
            } else {
                $this->error($msg);
            }
        }
    }

    //数据删除(删除单个)
    public function del()
    {
        $datatb = $this->Model;
        $id = I('post.delId');
        $Form = D($datatb);
        $delState = $Form->where("order_no = '" . $id . "'")->delete();
        if ($delState) {
            D('Orderdetail')->where("order_no = '" . $id . "'")->delete();
            $this->success("删除成功！");
        } else {
            $this->error($Form->getError());
        }
    }


}
