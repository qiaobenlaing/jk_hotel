<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/7/20
 * Time: 13:07
 */

namespace Admin\Controller;


use Common\Model\HotelModel;

class CommentController extends AdminBaseController
{
    public $Model = 'Comment';
    public $order = 'sort desc,create_time desc';


    public function edit2()
    {
        $datatb = $this->Model;
        $Admin = D($datatb);
        $id = intval($_REQUEST["id"]);
        $query = $Admin->getPk() . "=" . $id;
        $arr = $Admin->where($query)->find();
        $arr['imgarr'] = json_decode($arr['imgarr'], true);
        $this->success($arr);
    }

    //数据添加
    public function insert()
    {

        $datatb = $this->Model;
        $User = D($datatb); // 实例化User对象
        $vo = $User->create();
        if (!$vo) {
            $error = $User->getError();
            $this->error($error);
        } else {
            $imgarr = array();
            foreach ($vo['pics'] as $item => $v) {
                if ($_SERVER['HTTP_HOST'] == C('formal_host')) {
                    $fastUrl = $this->fastDfsUploadImg($v);
                    $imgarr[] = $fastUrl;
                } else {
                    $ossUrl = $this->base64ToImages($v);
                    $imgarr[]= $ossUrl['url'];
                }
            }
            $vo['imgarr'] = json_encode($imgarr, JSON_UNESCAPED_UNICODE);
            unset($vo['pics']);

            $userlist = D('User')->field('id,nickname')->select();
            $randArr = array_rand($userlist,1);
            $vo['send_user_id'] = $userlist[$randArr]['id'];

            //添加数据
            $id = $User->add($vo);
            if ($id) {
                // 添加日志
                add_log("添加信息成功", cn_substr($User->getLastSql(), 100));
                $this->success("添加成功");
            } else {
                $this->error("添加失败，请重新添加");
            }
        }
    }

    public function update()
    {
        $datatb = $this->Model;
        $User = D($datatb); // 实例化User对象
        $data = $User->create();
        if (!$data) {
            $error = $User->getError();

            $this->error($error);
        } else {

            //多图上传
            if (!empty($data['pics'])) {
                $imgarr = array();
                foreach ($data['pics'] as $item => $v) {
                    if (substr($v,0,5)=='data:') { //判断不为网络图片，而是base64编码图片
                        if ($_SERVER['HTTP_HOST'] == C('formal_host')) {
                            $fastUrl = $this->fastDfsUploadImg($v);
                            $imgarr[] = $fastUrl;
                        } else {
                            $ossUrl = $this->base64ToImages($v);
                            $imgarr[] = $ossUrl['url'];
                        }
                    }else{
                        $imgarr[] =$v;
                    }
                }
                unset($data['pics']);
                $data['imgarr'] = json_encode($imgarr, JSON_UNESCAPED_UNICODE);
            }
            //添加数据
            $id = $User->save($data);
            if ($id) {
                add_log("修改信息成功", cn_substr($User->getLastSql(), 100));
                $this->success("修改信息成功");
            } else {
                $this->error($User->getError());
            }
        }
    }

    //批量暂停留言
    public function delall()
    {
        $datatb = $this->Model;
        $id = implode(",", $_REQUEST["delId"]);
        $Form = D($datatb);
        $delState = $Form->where("id in(" . $id . ") ")->save(array('status'=>'2'));
        if ($delState) {
            $this->success("删除成功！");
        } else {
            $this->error($Form->getError());
        }
    }

    public function add()
    {
        $hotellist = D('Hotel')->field(array('id,title'))->select();
        $this->assign('hotellist', $hotellist);
        $this->display();
    }

    public function getBadges()
    {
        $id = I('get.id');
        $hotelModel = new HotelModel();
        $badges = $hotelModel->where(array('id' => $id))->getField('badges');
        $this->success(json_decode($badges, true));
    }
}
