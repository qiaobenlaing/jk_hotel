<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/5/19
 * Time: 12:17
 */

namespace Admin\Controller;


use Org\Util\Pinyin;
use Think\Page;

class CityController extends AdminBaseController
{

    public $Model = 'City';
    public $order = 'id desc, is_hot asc';

    //数据添加
    public function insert()
    {

        $datatb = $this->Model;
        $User = D($datatb); // 实例化User对象
        $vo = $User->create();
        if (!$vo) {
            $error = $User->getError();
            $this->error($error);
        } else {
            //字段替换
            if ($_SERVER['HTTP_HOST'] == C('formal_host')) {
                $result = $this->fastDfsUploadImg(I('post.bg_img'));
                $vo['bg_img'] = $result;
            } else {
                $ossInfo = $this->base64ToImages(I('post.bg_img'));
                $vo['bg_img'] = $ossInfo['url'];
            }
            $pinyin = new Pinyin();
            $vo['first_letter'] = strtoupper(substr($pinyin->p($vo['city_name'], 1), 0, 1));

            //数据库查找对应的城市编码
            $arrCityCode = D('full_city_baseinfo')->where(array('name' => array('like', '%' . $vo['city_name'] . '%')))->find();
            $vo['city_code'] = $arrCityCode['zone_code'];
            //外国城市随机生成
            if ($vo['city_code'] == '') {
                $vo['city_code'] = $this->getCityCode();
            }

            //如果选择了国内，就固定死parent_id,level
            if($vo['is_inland']==1){
                $vo['parent_id'] = 380;
                $vo['level'] = 3;
            }

            //添加数据
            $id = $User->add($vo);
            if ($id) {
                // 添加日志
                add_log("添加信息成功", cn_substr($User->getLastSql(), 100));
                $this->success("添加成功");
            } else {
                $this->error("添加失败，请重新添加");
            }
        }
    }

    //选择不同等级
    public function getLevelInfo(){

        $level = I('get.level');
        if($level==2){
            $level =1;
        }else if ($level==3){
            $level =2;
        }

       $list =  D($this->Model)->where(array('level'=>$level))->field('city_name,id')->select();
       echo json_encode($list,JSON_UNESCAPED_UNICODE);
    }

    //生成不重复的city_code
  private   function getCityCode()
    {
        $city_code = rand(111111, 999999);
        $city = D($this->Model)->where(array('city_code' => $city_code))->getField('city_code');
        if ($city) {
            $this->getCityCode();
        }else{
            return $city_code;
        }
    }

    public function add(){
        $contrancity =  D($this->Model)->where(array('level'=>1))->field('city_name,id')->select();
        $this->assign('list',$contrancity);
        $this->display();
    }

    public function edit()
    {
        $datatb = $this->Model;
        $Admin = D($datatb);
        $id = intval($_REQUEST["id"]);
        $query = $Admin->getPk() . "=" . $id;
        $arr = $Admin->where($query)->find();
        $level =$arr['level'];
        if($level==2){
            $level =1;
        }else if ($level==3){
            $level =2;
        }
        $contrancity =  D($this->Model)->where(array('level'=>$level))->field('city_name,id')->select();
        $this->assign("arr", $arr);
        $this->assign('list',$contrancity);
        $this->display();
    }


    //修改
    public function update()
    {
        $CityModel = D($this->Model);
        $data = $CityModel->create();
        if (!$data) {
            $error = $CityModel->getError();
            $this->error($error);
        } else {
            if (substr($data['bg_img'],0,5)=='data:') { //判断不为网络图片，而是base64编码图片
                if ($_SERVER['HTTP_HOST'] == C('formal_host')) {
                    $result = $this->fastDfsUploadImg($data['bg_img']);
                    $data['bg_img'] = $result;
                } else{
                    $ossUrl = $this->base64ToImages($data['bg_img']);
                    $data['bg_img'] = $ossUrl['url'];
                }
            }
            $pinyin = new Pinyin();
            $data['first_letter'] = strtoupper(substr($pinyin->p($data['city_name'], 1), 0, 1));

            //如果选择了国内，就固定死parent_id,level
            if($data['is_inland']==1){
                $data['parent_id'] = 380;
                $data['level'] = 3;
            }
            $id = $CityModel->save($data);
            if ($id) {
                add_log("修改信息成功", cn_substr($CityModel->getLastSql(), 100));
                $this->success("修改改成功");
            } else {
                $this->error('修改改失败，请重试');
            }
        }
    }

}
