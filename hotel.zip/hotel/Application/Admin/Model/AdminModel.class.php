<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2018/7/29
 * Time: 15:29
 */

namespace Admin\Model;
use http\Cookie;
use Think\Model;

class AdminModel extends Model
{
    protected  $tableName = "admin";

    // 自动验证设置
    protected $_validate	 =	 array(
        array('username','require','用户名必须填写！'),
        array('username','CheckName','用户名必须大于5个字符并小于16个字符',1,'callback','1'),//检查字段
        array('username','','不能有相同的用户！',1,'unique','1'), // 在新增的时候验证name字段是否唯一
        array('password','require','用户密码必须填写！',1,'','1'),
        array('password','CheckPass','用户密码必须大于5个字符并且小于16个字符',0,'callback','1'),//检查密码
        array('passwordStr','password','确认密码不正确',3,'confirm'),//检查确认密码是否一致
    );

    //自动填充设置
    protected $_auto	 =	 array(
        array('read_time','time','1','function'),
        array('lastly_ip','getIp','1','callback'),
        array('update_time','time','3','function'),
        array('password','md5','1','function'),
        array('password','setPass','2','callback'),
        array('admin','CheckAdmin','3','callback'),
    );

    function getIp(){
        return  get_client_ip();
    }

    //检查用户名是否正确
    function CheckName(){
        $info   = I("post.");
        $icount = strlen($info['username']);
        if($icount<6||$icount>16){
            return false;
        }else{
            return true;
        }
    }
    //检查用户密码是否符合要求
    function CheckPass(){
        $pass = $_REQUEST["password"];
        if(strlen($pass)<6||strlen($pass)>16){
            return false;
        }else{
            return true;
        }
    }
    //修改用户资料时检查用户密码
    function setPass(){
        $pass = $_REQUEST["password"];
        if(strlen($pass)<6||strlen($pass)>16){
            return false;
        }else{
            return md5($pass);
        }
    }

    //检查管理员
    function CheckAdmin(){
        $admin = $_SESSION["username"];
        if(strlen($admin)>4){
            return $admin;
        }else{
            return "";
        }
    }

    /*
    * 获取用户登陆情况
    * @param  $data 调用前端传过来的信息
    * @return array() 以数组形式返回登陆结果
    * */
    public function login($data){
        $userinfo = $this->where(array("username"=>$data['username']))->find();
        //用户不存在
        if(count($userinfo)<1){
            return array("status"=>0,"info"=>"用户不存在");
        }
        //用户被暂停
        if($userinfo['state']!=1){
            return array("status"=>0,"info"=>"用户已被暂停");
        }
        //用户暂停时间判断
        if($userinfo['stop_time']>=time()){
            return array("status"=>0,"info"=>"暂停使用！！！".date("Y年m月d日 H:i:s",$userinfo['stop_time'])."恢复正常");
        }
        //比对用户名和密码
        $hash = md5("123456");
        //组合成客户端提交上来的密码
        $sys_pass = md5($_SESSION[$hash]."|".$userinfo['password']);

        //登陆密码错误
        if($data['password']!=$sys_pass){
            //增加一次该用户登陆错误的次数
            $this->record_error_count($userinfo['id'],$userinfo['error_count']);
            $errorcount = intval($userinfo['error_count'])+1;
            return array("status"=>0,"info"=>"登陆密码错误".$errorcount."次！");
        }
        //正常登陆（修改用户的最后登录时间以及ip）
        $userdata['lastly_ip']       = get_client_ip();
        $userdata['error_count']     = 0;
        $userdata['stop_time']       = 0;
        $userdata['lastly_time']     = time();
        $userdata['id']              = $userinfo['id'];
        $this->save($userdata);
        //设置客户端Cookie保存用户信息
        if($data['ck']==1){
            cookie("username",$userinfo['username']);
            cookie("password",$data['pwd']);
        }
        // 设置SESSION信息
        $_SESSION["id"] 		    = $userinfo['id'];
        $_SESSION["username"]	    = $userinfo['username'];
        $_SESSION['nickname']    = $userinfo['nickname'];
        $_SESSION['group_id']     = $userinfo['group_id'];
        //暂未设置用户权限
        return array("status"=>1,"info"=>"登陆成功");
    }

    /*@param $id 用户id
     *@param  $errorCount 错误次数
     * */
    public function record_error_count($id=0,$errorCount=0){
        //设置暂停时间
        $stoptime =0;
        if($errorCount>=4){
            $stoptime = time()+60*60*6;//限制6个小时不能登陆
        }
        $sql = "update tns_admin set error_count= error_count+1,stop_time ='".$stoptime."' where id='".$id."'";
        $this->execute($sql);
    }
}
