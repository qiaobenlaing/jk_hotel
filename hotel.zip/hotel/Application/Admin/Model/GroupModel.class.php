<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2018/8/3
 * Time: 14:22
 */

namespace Admin\Model;


use Think\Model;

class GroupModel extends Model{

        protected  $tableName ="group";

    //自动填充设置
    protected $_auto	 =	 array(
        array('read_time','time','1','function'),
        array('admin','CheckAdmin','3','callback'),
        array('auth_id','runauthid','3','callback'),
        array('menu_id','runMenu','3','callback'),
    );

    //检查管理员
    function CheckAdmin(){
        $admin = $_SESSION["username"];
        if(strlen($admin)>4){
            return $admin;
        }else{
            return "";
        }
    }

    //检查后台菜单大栏面
    function runauthid(){
        return implode(",",$_REQUEST["auth_id"]);

    }
    //检查后台菜单小栏目
    function runMenu(){
        return implode(",",$_REQUEST["menu_id"]);
    }


    //查询所有用户分组信息
    public function  getAllUserRole(){
        return  $this->field("id,name,menu_id,auth_id,admin,rank")->select();
    }

}
