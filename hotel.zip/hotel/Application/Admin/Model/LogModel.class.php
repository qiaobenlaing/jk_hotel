<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2018/8/3
 * Time: 17:33
 */

namespace Admin\Model;


use Think\Model;

class LogModel extends Model{

    protected  $tableName ="log";

}