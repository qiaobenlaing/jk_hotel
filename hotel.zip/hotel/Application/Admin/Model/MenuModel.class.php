<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2018/7/30
 * Time: 17:35
 */

namespace Admin\Model;
use Think\Model;

class MenuModel extends Model
{

    protected $tableName = "menu";

    // 自动验证设置
    protected $_validate	 =	 array(
        array('name','require','用户名必须填写！'),
        array('url','','不能有相同的url菜单地址！',2,'unique','2'), // 在新增的时候验证name字段是否唯一
    );

    //自动填充设置
    protected $_auto	 =	 array(
        array('read_time','time','1','function'),
        array('admin','CheckAdmin','3','callback'),
    );

    //检查管理员
    function CheckAdmin(){
        $admin = $_SESSION["username"];
        if(strlen($admin)>4){
            return $admin;
        }else{
            return "";
        }
    }

}
