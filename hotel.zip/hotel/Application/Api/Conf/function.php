<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/5/1
 * Time: 18:36
 */

/** 推荐入住等级说明
 * @param $score 酒店评分
 * @return string 推荐说明
 */
function getScoreTxt($score)
{
    $txt = '';
    if ($score >= '1' && $score < '2') {
        $txt = '一般';
    } elseif ($score >= '2' && $score < '3') {
        $txt= '不错,可以尝试';
    } elseif ($score >= '3' && $score < '4') {
        $txt = '很好，值得体验';
    } else if ($score >= '4') {
        $txt = '强力推荐';
    }
    return $txt;
}

//有无早餐
function getBreaf($value)
{
    switch ($value) {
        case 1:
            $value = "有早";
            break;
        case 2:
            $value = "无餐";
            break;
    }
    return $value;
}

//金额兑换
function moneyShowApp($orderInfo){
    if ($orderInfo['total_money'] == '0.00') {
        unset($orderInfo['total_money']);
    }else{
        $orderInfo['total_money'] .='点';
    }
    if($orderInfo['total_money_rmb']== '0.00'){
        unset($orderInfo['total_money_rmb']);
    }else{
        $orderInfo['total_money_rmb'] .='￥';
    }
    if($orderInfo['real_money']== '0.00'){
        unset($orderInfo['real_money']);
    }else{
        $orderInfo['real_money'] .= '点';
    }
    if($orderInfo['real_money_rmb']== '0.00'){
        unset($orderInfo['real_money_rmb']);
    }else{
        $orderInfo['real_money_rmb'] .='￥';
    }
    if($orderInfo['replace_money']== '0.00'){
        unset($orderInfo['replace_money']);
    }else{
        $orderInfo['replace_money'] .= '￥';
    }
    if($orderInfo['discount_money']== '0.00'){
        unset($orderInfo['discount_money']);
    }else{
        $orderInfo['discount_money'] .= '点';
    }
    if($orderInfo['discount_money_rmb']== '0.00'){
        unset($orderInfo['discount_money_rmb']);
    }else{
        $orderInfo['discount_money_rmb'] .= '￥';
    }

    return $orderInfo;
}

//获取退订状态
function getRefundText($value)
{
    switch ($value) {
        case 1:
            $value = "不可退订";
            break;
        case 2:
            $value = "有条件退订";
            break;
        case 3:
            $value = "免费退订";
            break;
        default:
            $value = "未知";
            break;
    }
    return $value;
}

//获得状态值
function getApiRoomDayTypeText($value)
{
    switch ($value) {
        case 1:
            $value = "保留房";
            break;
        case 2:
            $value = "非保留房";
            break;
        default:
            $value = "临时保留房";
            break;
    }
    return $value;
}

//评论酒店的等级
function commentLevel($value){
    switch ($value) {
        case 1:
            $value = "非常差";
            break;
        case 2:
            $value = "差";
            break;
        case 3:
            $value = "一般";
            break;
        case 4:
            $value = "很好";
            break;
        default:
            $value = "非常好";
            break;
    }
    return $value;
}


//订单状态说明
function orderStateText($state)
{
    $orderStaeTxt = '';
    switch ($state) {
        case 1:
            $orderStaeTxt = '待支付';
            break;
        case 2:
            $orderStaeTxt = '已支付';
            break;
        case 3:
            $orderStaeTxt = '订单超时';
            break;
        case 4:
            $orderStaeTxt = '已确认';
            break;
        case 5:
            $orderStaeTxt = '已完成';
            break;
        case 6:
            $orderStaeTxt = '已取消';
            break;
        default:
            $orderStaeTxt = '状态未知';
            break;
    }
    return $orderStaeTxt;
}

//退订状态
function backOrderState($state){
    switch ($state) {
        case 1:
            $backOrderTxt = '未申请退款';
            break;
        case 2:
            $backOrderTxt = '申请中';
            break;
        case 3:
            $backOrderTxt = '商家拒绝退款';
            break;
        default:
            $backOrderTxt = '状态未知';
            break;
    }
    return $backOrderTxt;
}

//统计一段时间内所有的天数，并返回天数的数组
function  dateNum($begintime,$endtime){
    $bentimestap = strtotime($begintime);
    $endtimestap = strtotime($endtime);
    for ($i=$bentimestap;$i<=$endtimestap;$i+=86400){
        $date[] = date("Y-m-d",$i);
    }
    return $date;
}


//时间戳格式化
function toDate($time, $format = 'Y-m-d H:i:s')
{
    if (empty($time)) {
        return '';
    }
    $format = str_replace('#', ':', $format);
    return date($format, $time);
}

/*关联信息
    $datable  数据模型
    $info 关联字段信息
    $sql查询条件
*/
function getName($datable, $info, $sql)
{
    $table = D($datable);
    $list = $table->where($sql)->order("id desc")->find();
    return $list[$info];
}

//支付方式
function payType($value){
    $txt = '';
    switch ($value){
        case 1:
            $txt = '指数支付';
            break;
        case 2:
            $txt = '元宝支付';
            break;
        case 3:
            $txt = '未来币支付';
            break;
        case 4:
            $txt = '混合支付（指数+元宝）';
            break;
        case 5:
            $txt = '混合支付（指数+未来币）';
            break;
    }
    return $txt;
}


//数据表唯一编号生成
function orderNo($table, $field)
{
    $pre = date('Ymd');
    $randNum = sprintf('%08d', rand(1, 99999));
    $no = $pre . $randNum;
    $result = D($table)->where(array($field => $no))->field('id')->find();
    if ($result) {
        orderNo($table, $field);
    }
    return $pre . $randNum;
}
