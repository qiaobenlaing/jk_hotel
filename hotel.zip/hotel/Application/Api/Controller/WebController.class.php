<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/7/6
 * Time: 13:16
 */

namespace Api\Controller;


use Common\Model\CommentModel;
use Common\Model\CouponModel;
use Common\Model\HotelModel;
use Common\Model\OrderModel;
use Common\Model\RoomModel;
use Common\Model\RoomStateModel;

class WebController extends ApiBaseController
{

    /** 提交预定(待支付)
     * @param $title 订单名称
     * @param $img 酒店图片
     * @param $is_use_coupon 是否用优惠券 1.使用 2.不使用
     * @param $coupon_code 优惠券编号
     * @param $roomId 房型编号
     * @param $roomIn 入住日期
     * @param $roomOut 离店日期
     * @param $userId 用户id
     * @param $roomNum 房间数量
     * @param $ids 房态编号
     * @param $live 可住人数
     * @param $username 用户姓名数组
     * @param $telphone 短信通知电话
     * @param $dayRoomType 房态类型(1.保留房2.非保留房3.临时保留房)
     * @param $sold_rule_id 售卖规则编号
     * @param $is_index 是否使用指数
     * @return array 预定结果
     */
    public function reservation($title, $img, $is_use_coupon, $coupon_code, $roomId, $roomIn, $roomOut, $roomNum, $ids, $live, $userId,
                                $username, $telphone, $dayRoomType, $sold_rule_id, $is_index, $token)
    {
        $roomstateModel = new RoomStateModel();
        $Properties = $roomstateModel->where(array('id' => array('IN', $ids)))->select();

        //1.判断房态是否可定
        $orderModel = new OrderModel();
        //如果用户想订昨天的房间
        $yudingResult = $orderModel->preRoomLastDay($roomIn, $roomId);
        if ($yudingResult['code'] != \Consts::REQUEST_SUCCESS) {
            return $yudingResult;
        }

        $isResult = $orderModel->isCanBuy($roomIn, $Properties[0]['is_breakfast'], $Properties[0]['bed_type'],
            $Properties[0]['refund_state'], $Properties[0]['refund_remark'], $roomOut, $roomId, $dayRoomType, $sold_rule_id);
        if ($isResult['code'] != \Consts::REQUEST_SUCCESS) {
            return $isResult;
        } else {
            $list = $isResult['list'];
        }
        //2.判断是否超卖了
        $outSoldResult = $orderModel->isOutSold($ids, $dayRoomType);
        if ($outSoldResult['code'] != \Consts::REQUEST_SUCCESS) {
            return $outSoldResult;
        } else {
            $out_sold = $outSoldResult['out_sold'];
        }
        //3.判断用户是否有未支付的订单
        $where = array('user_id' => $userId, 'state' => \Consts::ORDER_NOTPAY);
        $result = $orderModel->where($where)->find();
        if ($result) {
            return $this->returnJson(array('code' => \Consts::ORDER_NOT_CODE, 'message' => '用户有待支付的订单'));
        }

        //4.计算总金额
        $totalMoney = $orderModel->totalMoney($list, $userId, $is_use_coupon, $coupon_code, $roomNum, $roomId, $sold_rule_id, $is_index, $token);
        if($totalMoney['code']!=\Consts::REQUEST_SUCCESS){
            return $totalMoney;
        }

        $extend_price = $totalMoney['extend_price'];
        $hotel_type = $totalMoney['hotel_type'];
        $pay_type = $totalMoney['pay_type'];
        $totalmoneyZhi = $totalMoney['total_money'];
        $totalmoneyRMB = $totalMoney['total_money_rmb'];
        $replace_money = $totalMoney['replace_money'];
        $vipDiscountRMB = $totalMoney['vip_discount_money'];   //VIP优惠金额
        $discount_money = $totalMoney['discount_money'];
        $discount_money_rmb = $totalMoney['discount_money_rmb'];
        $discount_info = $totalMoney['discount_info'];
        $total_before_money = $totalMoney['total_before_money'];
        $total_before_money_rmb = $totalMoney['total_before_money_rmb'];
        $index_day_price = $Properties[0]['index_day_price']; //酒店指数间夜单价

        //6.封装请求数据
        $orderNo = orderNo('Order', 'order_no');
        $usernameJsonArr = json_encode($username, JSON_UNESCAPED_UNICODE);
        //是否超售
        if ($out_sold == 2) {
            $out_sold_message = '未超卖';
        } else {
            $out_sold_message = '超卖订单';
        }

        //夜数
        $dayNum = count($isResult['preDayNum']);
        //退订状态 即说明
        $refundState = $Properties[0]['refund_state'];
        $refundRemark = $Properties[0]['refund_remark'];
        $remark = json_encode(array('roomIn' => $roomIn, 'roomOut' => $roomOut,
            'day_room_type' => getApiRoomDayTypeText($dayRoomType),
            'roomName' => getName('Room', 'title', 'id=' . $roomId),
            'out_sold_message' => $out_sold_message, 'ids' => $ids, 'sold_rule_id' => $sold_rule_id,
            'refundState' => $refundState, 'refundRemark' => $refundRemark,
            'roomId' => $roomId, 'room_day_type' => $dayRoomType, 'dayNum' => $dayNum,
            'extend_price' => $extend_price, 'is_index' => $is_index, 'index_day_price' => $index_day_price,
            'roomNum' => $roomNum, 'live' => $live, 'hotelName' => $title), JSON_UNESCAPED_UNICODE);
        $data = array(
            'order_no' => $orderNo,
            'title' => $title,
            'img' => $img,
            'is_out_sold' => $out_sold,
            'state' => \Consts::ORDER_NOTPAY,
            'createtime' => time(),
            'replace_money' => $replace_money,
            'discount_info' => $discount_info,
            'discount_money' => $discount_money,
            'discount_money_rmb' => $discount_money_rmb,
            'vip_discount_rmb' => $vipDiscountRMB,
            'total_money' => $totalmoneyZhi,
            'total_money_rmb' => $totalmoneyRMB,
            'remark' => $remark,
            'user_id' => $userId,
            'telphone' => $telphone,
            'username' => $usernameJsonArr,
        );

        //判断是否使用了优惠券（使用了则将用户优惠券状态改为已使用）
        if ($is_use_coupon == 1) {
            $data['used_coupon'] = 1;// 是用了优惠券
            $data['coupon_code'] = json_encode($coupon_code, true);
        }
        $data['replace_money'] = $replace_money;
        $data['pay_type'] = json_encode($pay_type);

        //订单详情数据
        $dataDetail = array(
            'order_no' => $orderNo,
            'state' => \Consts::ORDER_NOTPAY,
            'back_type' => \Consts::CANCEL_NOT,
            'createtime' => time(),
        );

        M()->startTrans();
        $resultPreOrder = $orderModel->add($data);
        $resultOrderDetail = D('Orderdetail')->add($dataDetail);
        if ($resultPreOrder && $resultOrderDetail) {
            //冻结用户优惠券状态
            if ($is_use_coupon == 1) {
                $userCouponModel = D('usercoupon');
                    $data = array(
                        'order_no' => $orderNo,
                        'status' => 3, //未支付前冻结
                    );
                    $userCouponModel->where(array( 'id'=> array('IN', $coupon_code)))->save($data);
            }
            $code = \Consts::REQUEST_SUCCESS;
            M()->commit();
        } else {
            $code = \Consts::REQUEST_ERROR;
            M()->rollback();
        }
        $resultData = array(
            'code' => $code,
            'order_no' => $orderNo,
            'pay_type' => $pay_type,
            'hotel_type' => $hotel_type,
            'replace_money' => $replace_money,
            'total_before_money' => $total_before_money,
            'total_before_money_rmb' => $total_before_money_rmb,
            'total_money' => $totalmoneyZhi,
            'total_money_rmb' => $totalmoneyRMB,
            'discount_info' => json_decode($discount_info, true),
            'discount_money' => $discount_money,
            'discount_money_rmb' => $discount_money_rmb,
            'vip_discount_rmb' => $vipDiscountRMB
        );
        return $this->returnJson($resultData);
    }

    /** 计算金额
     * @param $roomIn 入住日期
     * @param $ids 房态编号
     * @param $roomOut 离店日期
     * @param $roomId 房型编号
     * @param $dayRoomType 房态类型
     * @param $userId 用户编号
     * @param $roomNum 房间数
     * @return array|mixed 返回结果
     */
    public function totalMoney($roomIn, $is_use_coupon, $coupon_code, $ids, $roomOut, $roomId, $dayRoomType, $userId, $roomNum, $sold_rule_id, $is_index, $token)
    {
        $roomstateModel = new RoomStateModel();
        $Properties = $roomstateModel->where(array('id' => array('IN', $ids)))->select();

        //判断房态是否可定
        $orderModel = new OrderModel();

        //如果用户想订昨天的房间
        $yudingResult = $orderModel->preRoomLastDay($roomIn, $roomId);
        if ($yudingResult['code'] != \Consts::REQUEST_SUCCESS) {
            return $yudingResult;
        }

        $isResult = $orderModel->isCanBuy($roomIn, $Properties[0]['is_breakfast'], $Properties[0]['bed_type'],
            $Properties[0]['refund_state'], $Properties[0]['refund_remark'], $roomOut, $roomId, $dayRoomType, $sold_rule_id);
        if ($isResult['code'] != \Consts::REQUEST_SUCCESS) {
            return $isResult;
        } else {
            $list = $isResult['list'];
        }
        //判断是否超卖
        $outSoldResult = $orderModel->isOutSold($ids, $dayRoomType);
        if ($outSoldResult['code'] != \Consts::REQUEST_SUCCESS) {
            return $outSoldResult;
        } else {
            $out_sold = $outSoldResult['out_sold'];
        }

        //计算总金额
        $totalMoney = $orderModel->totalMoney($list, $userId, $is_use_coupon, $coupon_code, $roomNum, $roomId, $sold_rule_id, $is_index, $token);
        if($totalMoney['code']!=\Consts::REQUEST_SUCCESS){
            return $totalMoney;
        }

        $totalmoneyZhi = $totalMoney['total_money'];
        $totalmoneyRMB = $totalMoney['total_money_rmb'];
        $replace_money = $totalMoney['replace_money'];
        $vipDiscountRMB = $totalMoney['vip_discount_money'];   //VIP优惠金额
        $discount_money = $totalMoney['discount_money'];
        $discount_money_rmb = $totalMoney['discount_money_rmb'];
        $discount_info = $totalMoney['discount_info'];
        $total_before_money = $totalMoney['total_before_money'];
        $total_before_money_rmb = $totalMoney['total_before_money_rmb'];
        $hotel_id = $totalMoney['hotel_id'];

        //判断剩余库存量决定是否可定的数量
        if ($Properties[0]['is_out_sold'] == 1) {
            $inventory = $Properties[0]['inventory'] + $Properties[0]['out_sold_count'] - $Properties[0]['day_sold_count'];
        } else {
            $inventory = $Properties[0]['inventory'] - $Properties[0]['day_sold_count'];
        }

        return $this->returnJson(
            array('code' => \Consts::REQUEST_SUCCESS,
                'total_before_money' => $total_before_money,
                'total_before_money_rmb' => $total_before_money_rmb,
                'total_money' => $totalmoneyZhi,
                'inventory' => $inventory,
                'hotel_id' => $hotel_id,
                'total_money_rmb' => $totalmoneyRMB,
                'replace_money' => $replace_money,
                'discount_info' => json_decode($discount_info, true),
                'vip_discount_rmb' => $vipDiscountRMB,
                'discount_money' => $discount_money,
                'discount_money_rmb' => $discount_money_rmb,
                'is_out_sold' => $out_sold));
    }

    //支付通知(测试)
    public function payNotice($orderNo, $totalMoney, $totalMoneyRmb)
    {
        $orderModel = new OrderModel();

        //判断订单存在与否
        $orderInfo = $orderModel->where(array('order_no' => $orderNo))->find();
        if (!$orderInfo) {
            return $this->returnJson(array('code' => \Consts::PARAMES_ERROR, 'message' => '订单编号不存在'));
        }

        //判断是否已支付
        if ($orderInfo['state'] == \Consts::ORDER_PAYED) {
            return $this->returnJson(array('code' => \Consts::PARAMES_ERROR, 'message' => '该订单已支付过了,不能重复支付'));
        }

        $data = array(
            'order_no' => $orderNo,
            'id' => $orderInfo['id'],
            'real_money' => $totalMoney,
            'real_money_rmb' => $totalMoneyRmb,
            'updatetime' => time(),
            'state' => \Consts::ORDER_PAYED,
            'back_type' => \Consts::CANCEL_NOT,
        );

        $dataDetail = array(
            'order_no' => $orderNo,
            'state' => \Consts::ORDER_PAYED,
            'back_type' => \Consts::CANCEL_NOT,
            'createtime' => time(),
        );

        //判断订单所属房态类型
        $remark = json_decode($orderInfo['remark'], true);
        if ($remark['room_day_type'] == 1) { //保留房不需要确认，直接转成已确认
            $data['state'] = \Consts::ORDER_CONFIRM;
            $dataDetail['state'] = \Consts::ORDER_CONFIRM;
        }

        M()->startTrans();
        $result = $orderModel->save($data);
        $orderDetailModel = D('Orderdetail');
        $resultOrderDetail = $orderDetailModel->add($dataDetail);
        if ($result && $resultOrderDetail) {
            $code = \Consts::REQUEST_SUCCESS;
            M()->commit();
        } else {
            $code = \Consts::REQUEST_ERROR;
            M()->rollback();
        }
        return $this->returnJson(array('code' => $code, 'order_no' => $orderNo));
    }


    /** 订单取消(待支付)
     * @param $orderNo 订单编号
     * @return array 取消结果
     */
    public function orderCancel($orderNo)
    {
        $orderModel = new OrderModel();
        $orderInfo = $orderModel->where(array('order_no' => $orderNo))->find();
        if (!$orderInfo) {
            return $this->returnJson(array('code' => \Consts::PARAMES_ERROR, 'message' => '订单编号不存在'));
        }
        if ($orderInfo['state'] == \Consts::ORDER_CANCEL) {
            return $this->returnJson(array('code' => \Consts::PARAMES_ERROR, 'message' => '该订单已经取消过了'));
        }

        $data = array(
            'order_no' => $orderNo,
            'id' => $orderInfo['id'],
            'updatetime' => time(),
            'state' => \Consts::ORDER_CANCEL,
            'back_type' => \Consts::CANCEL_NOT,
        );

        $dataDetail = array(
            'order_no' => $orderNo,
            'state' => \Consts::ORDER_CANCEL,
            'back_type' => \Consts::CANCEL_NOT,
            'createtime' => time(),
        );

        M()->startTrans();
        $result = $orderModel->save($data);
        $orderDetailModel = D('Orderdetail');
        $resultOrderDetail = $orderDetailModel->add($dataDetail);
        if ($result && $resultOrderDetail) {
            //订单优惠券状态由冻结恢复为正常
            D('usercoupon')->where(array('user_id' => $orderInfo['user_id'], 'order_no' => $orderNo))->save(array('status' => 1));
            $code = \Consts::REQUEST_SUCCESS;
            M()->commit();
        } else {
            $code = \Consts::REQUEST_ERROR;
            M()->rollback();
        }
        return $this->returnJson(array('code' => $code, 'order_no' => $orderNo));
    }

    /** 申请退款
     * @param $orderNo 订单编号
     * @param $refundMoney 申请退款金额
     * @return array 返回结果
     */
    public function refundApplying($orderNo, $refundMoney)
    {
        $orderModel = new OrderModel();
        $orderInfo = $orderModel->where(array('order_no' => $orderNo))->find();
        if (!$orderInfo) {
            return $this->returnJson(array('code' => \Consts::PARAMES_ERROR, 'message' => '订单编号不存在'));
        }

        $orderDetailModel = D('Orderdetail');
        $orderDetailInfo = $orderDetailModel->where(array('order_no' => $orderNo, 'back_type' => array('IN', array(\Consts::CANCEL_APPLYING, \Consts::CANCEL_REFUND, \Consts::CANCEL_REJECT))))->find();
        if ($orderDetailInfo) {
            return $this->returnJson(array('code' => \Consts::PARAMES_ERROR, 'message' => '该订单已经申请过退款'));
        }

        if ($refundMoney > $orderInfo['total_money']) {
            return $this->returnJson(array('code' => \Consts::PARAMES_ERROR, 'message' => '退款金额不能大于订单金额'));
        }

        //待确认状态，申请退款（直接资金原路返回，这里我需要调用第三方支付）
        if ($orderInfo['state'] == \Consts::ORDER_PAYED && $orderInfo['back_type'] == \Consts::CANCEL_APPLYING) {
            $data = array(
                'order_no' => $orderNo,
                'id' => $orderInfo['id'],
                'updatetime' => time(),
                'state' => \Consts::ORDER_CANCEL,
                'back_type' => \Consts::CANCEL_REFUND,
            );

            $dataDetail = array(
                'order_no' => $orderNo,
                'state' => \Consts::ORDER_CANCEL,
                'back_type' => \Consts::CANCEL_REFUND,
                'createtime' => time(),
            );

            M()->startTrans();
            $result = $orderModel->save($data);
            $resultOrderDetail = $orderDetailModel->add($dataDetail);
            if ($result && $resultOrderDetail) {
                $code = \Consts::REQUEST_SUCCESS;
                M()->commit();
            } else {
                $code = \Consts::REQUEST_ERROR;
                M()->rollback();
            }
            return $this->returnJson(array('code' => $code, 'message' => '订单金额已退', 'order_no' => $orderNo));

            //已确认状态，申请退款（需要人工确认）
        } elseif ($orderInfo['state'] == \Consts::ORDER_CONFIRM && $orderInfo['back_type'] == \Consts::CANCEL_APPLYING) {
            $data = array(
                'order_no' => $orderNo,
                'id' => $orderInfo['id'],
                'updatetime' => time(),
                'state' => \Consts::ORDER_CONFIRM,
                'back_type' => \Consts::CANCEL_APPLYING,
            );

            $dataDetail = array(
                'order_no' => $orderNo,
                'state' => \Consts::ORDER_CONFIRM,
                'back_type' => \Consts::CANCEL_APPLYING,
                'createtime' => time(),
            );

            M()->startTrans();
            $result = $orderModel->save($data);
            $resultOrderDetail = $orderDetailModel->add($dataDetail);
            if ($result && $resultOrderDetail) {
                $code = \Consts::REQUEST_SUCCESS;
                M()->commit();
            } else {
                $code = \Consts::REQUEST_ERROR;
                M()->rollback();
            }
            return $this->returnJson(array('code' => $code, 'message' => '平台已经为您留房了,请联系相关人员线下退订'));
        }
    }

    /** 订单列表
     * @param $userId 用户编号
     * @param $orderState 订单状态
     * * @param $backType 退款状态
     * @return array 返回结果
     */
    public function orderList($userId, $orderState, $backType, $page)
    {
        $orderModel = new OrderModel();
        $where = array(
            'user_id' => $userId,
            'state' => $orderState,
            'back_type' => $backType
        );
        //状态为-1则查全部
        if ($orderState == -1) {
            unset($where['state']);
            unset($where['back_type']);
        }
        if ($page < 1) {
            $page = 1;
        }

        $count = $orderModel->where($where)->field('id')->count();
        $pageOffSet = ($page - 1) * self::$PAGE_SIZE;
        $orderList = $orderModel->where($where)->limit($pageOffSet, self::$PAGE_SIZE)
            ->field('order_no,title,state,back_type,pay_type,remark,user_id,replace_money,total_money,img,createtime,
        total_money_rmb,real_money,real_money_rmb,discount_money,discount_money_rmb')->order('createtime desc')->select();
        if ($count % self::$PAGE_SIZE == 0) {
            $totalPage = $count / self::$PAGE_SIZE;
        } else {
            $totalPage = intval(($count / self::$PAGE_SIZE) + 1);
        }

        //获取订单数量(2020-07-24)
        $orderListSort = $orderModel->where(array('user_id' => $userId, 'back_type' => \Consts::CANCEL_NOT))
            ->field('order_no,state')->order('createtime desc')->select();
        //待支付订单数量
        $pay_not_count = 0;
        //待确认订单数量
        $wating_confirm_count = 0;
        //待出行订单数量
        $wating_enter_room = 0;
        foreach ($orderListSort as $item => $value) {
            if ($value['state'] == \Consts::ORDER_NOTPAY) {
                $pay_not_count++;
            } elseif ($value['state'] == \Consts::ORDER_PAYED) {
                $wating_confirm_count++;
            } elseif ($value['state'] == \Consts::ORDER_CONFIRM) {
                $wating_enter_room++;
            }
        }

        //订单状态转换
        foreach ($orderList as $item => &$value) {
            //订单说明：
            $value['remark'] = json_decode($value['remark'], true);
            $value['createtime'] = toDate($value['createtime']);
        }
        if ($orderList) {
            return $this->returnJson(array('code' => \Consts::REQUEST_SUCCESS, 'data' => $orderList,
                'watingPaying' => $pay_not_count,
                'watingConfirm' => $wating_confirm_count,
                'watingEnter' => $wating_enter_room,
                'count' => $count, 'totalPage' => $totalPage, 'page' => $page));
        } else {
            return $this->returnJson(array('code' => \Consts::REQUEST_SUCCESS, 'count' => 0, 'message' => '未找到相关订单信息'));
        }
    }

    //订单详情
    public function detail($orderNo)
    {
        $orderModel = new OrderModel();
        $value = $orderModel->where(array('order_no' => $orderNo))->find();
        if ($value) {
            //订单说明：
            $value['remark'] = json_decode($value['remark'], true);

            //状态
            $State = $value['state'];
            $roomModel = new RoomModel();
            $hotelId = $roomModel->where(array('id' => $value['remark']['roomId']))->getField('hotel_id');

            //酒店信息
            $hotelBase['hotel_name'] = $value['remark']['hotelName'];
            $hotelBase['room_name'] = $value['remark']['roomName'];
            $hotelBase['hotel_id'] = $hotelId;

            //入住信息
            $Room['enter_hotel_date'] = date('m月d日', strtotime($value['remark']['roomIn'])) . '-' . date('m月d日', strtotime($value['remark']['roomOut']));
            $Room['enter_num'] = count(dateNum($value['remark']['roomIn'], $value['remark']['roomOut'])) - 1;
            $Room['room_num'] = $value['remark']['roomNum'];
            $Room['telphone'] = $value['telphone'];
            $Room['usernames'] = str_replace(array('[', ']', "'"), '', json_decode($value['username'], true));

            //订单信息
            $orderInfo['order_no'] = $value['order_no'];
            $orderInfo['createtime'] = toDate($value['createtime']);
            $orderInfo['pay_type_txt'] = payType($value['pay_type']);
            $orderInfo['pay_type'] = $value['pay_type'];
            $orderInfo['total_money'] = (float)$value['total_money'];
            $orderInfo['total_money_rmb'] = (float)$value['total_money_rmb'];
            $orderInfo['real_money'] = (float)$value['real_money'];
            $orderInfo['real_money_rmb'] = (float)$value['real_money_rmb'];
            $orderInfo['pre_total_money'] = $value['total_money'] + $value['vip_discount'] + $value['discount_money'];
            $orderInfo['pre_total_money_rmb'] = $value['total_money_rmb'] + $value['vip_discount_rmb'] + $value['discount_money_rmb'];
            $orderInfo['replace_money'] = (float)$value['replace_money'];
            $orderInfo['vip_discount_rmb'] = (float)$value['vip_discount_rmb'];
            $orderInfo['discount_money'] = (float)$value['discount_money'];
            $orderInfo['discount_money_rmb'] = (float)$value['discount_money_rmb'];
            $orderInfo['is_index'] = $value['remark']['is_index'];

            $resultInfo = array(
                'state' => $State,
                'hotelInfo' => $hotelBase,
                'enterInfo' => $Room,
                'orderInfo' => $orderInfo,
                'refundRemark' => $value['remark']['refundRemark']
            );
            return $this->returnJson(array('code' => \Consts::REQUEST_SUCCESS, 'info' => $resultInfo));
        } else {
            return $this->returnJson(array('code' => \Consts::REQUEST_SUCCESS, 'message' => '未找到相关订单'));
        }
    }

    /** 酒店标签评价列表
     * @param $badge 标签名称
     * @param $hotel_id 酒店编号
     * @param $page 分页
     * @param $page_size 分页条数
     * @return array 返回数据
     */
    public function getCommentBadge($badge, $hotel_id, $page, $page_size)
    {
        if ($page < 1) {
            $page = 1;
        }
        if ($page_size != '') {
            self::$PAGE_SIZE = $page_size;
        }
        $commentModel = new CommentModel();
        $count = $commentModel->alias('c')->where(array('hotel_id' => $hotel_id, 'status' => 1, 'badge' => $badge))
            ->join('left join tns_user as u ON u.id=c.send_user_id')->field('id')->count();
        $pageOffSet = ($page - 1) * self::$PAGE_SIZE;
        $cooment_list = $commentModel->alias('c')->where(array('hotel_id' => $hotel_id, 'status' => 1, 'badge' => $badge))->order('sort asc')
            ->limit($pageOffSet, self::$PAGE_SIZE)->join('left join tns_user as u ON u.id=c.send_user_id')->select();
        if ($count % self::$PAGE_SIZE == 0) {
            $totalPage = $count / self::$PAGE_SIZE;
        } else {
            $totalPage = intval(($count / self::$PAGE_SIZE) + 1);
        }
        $data_list = array();
        foreach ($cooment_list as $item => &$value) {
            $data['hotel_id'] = $value['hotel_id'];
            $data['user_id'] = $value['send_user_id'];
            $data['comment'] = $value['comment'];
            $data['imgarr'] = json_decode($value['imgarr'], true);
            $data['create_time'] = toDate($value['create_time'], 'Y.m.d');
            $data['type'] = $value['type'];
            $data['typeTxt'] = commentLevel($value['type']);
            $data['nickname'] = $value['nickname'];
            $data['head_img'] = $value['head_img'];
            $data['is_vip'] = $value['is_vip'] == '1' ? '是' : '否';
            $data['vip_level'] = $value['vip_level'];
            $data_list[] = $data;
        }
        $info = array(
            'commonetList' => $data_list,
            'count' => $count,
            'totalPage' => $totalPage,
            'pageSie' => self::$PAGE_SIZE,
            'page' => $page
        );
        if (count($cooment_list) < 1) {
            return $this->returnJson(array('code' => \Consts::REQUEST_SUCCESS, 'message' => '未找到相关评论'));
        } else {
            return $this->returnJson(array('code' => \Consts::REQUEST_SUCCESS, 'info' => $info, 'message' => '获取评价列表成功'));
        }
    }


    /**酒店评论
     * @param $hotel_id 酒店编号
     * @return array 返回结果
     */
    public function getHotelComment($hotel_id, $page, $page_size)
    {
        $hotelModel = new HotelModel();
        $badgeInfo = $hotelModel->where(array('id' => $hotel_id))->field('badges,score')->find();
        if ($page < 1) {
            $page = 1;
        }
        if ($page_size != '') {
            self::$PAGE_SIZE = $page_size;
        }

        $commentModel = new CommentModel();
        $count = $commentModel->alias('c')->where(array('hotel_id' => $hotel_id, 'status' => 1))
            ->join('left join tns_user as u ON u.id=c.send_user_id')->field('id')->count();
        $pageOffSet = ($page - 1) * self::$PAGE_SIZE;
        $cooment_list = $commentModel->alias('c')->where(array('hotel_id' => $hotel_id, 'status' => 1))->order('sort asc')
            ->limit($pageOffSet, self::$PAGE_SIZE)->join('left join tns_user as u ON u.id=c.send_user_id')->select();
        if ($count % self::$PAGE_SIZE == 0) {
            $totalPage = $count / self::$PAGE_SIZE;
        } else {
            $totalPage = intval(($count / self::$PAGE_SIZE) + 1);
        }
        $badgesList = $commentModel->where(array('hotel_id' => $hotel_id, 'status' => 1))->field('badge,count(*) as sum')->group('badge')->select();
        $data_list = array();
        foreach ($cooment_list as $item => &$value) {
            $data['hotel_id'] = $value['hotel_id'];
            $data['user_id'] = $value['send_user_id'];
            $data['comment'] = $value['comment'];
            $data['imgarr'] = json_decode($value['imgarr'], true);
            $data['create_time'] = toDate($value['create_time'], 'Y.m.d');
            $data['type'] = $value['type'];
            $data['typeTxt'] = commentLevel($value['type']);
            $data['nickname'] = $value['nickname'];
            $data['head_img'] = $value['head_img'];
            $data['is_vip'] = $value['is_vip'] == '1' ? '是' : '否';
            $data['vip_level'] = $value['vip_level'];
            $data_list[] = $data;
        }
        $info = array(
            'badgesList' => $badgesList,
            'commonetList' => $data_list,
            'score' => $badgeInfo['score'],
            'scoreTxt' => getScoreTxt($badgeInfo['score']),
            'count' => $count,
            'totalPage' => $totalPage,
            'pageSie' => self::$PAGE_SIZE,
            'page' => $page
        );
        if (count($cooment_list) < 1) {
            return $this->returnJson(array('code' => \Consts::REQUEST_SUCCESS, 'message' => '未找到相关评论'));
        } else {
            return $this->returnJson(array('code' => \Consts::REQUEST_SUCCESS, 'info' => $info, 'message' => '获取评价列表成功'));
        }
    }


    /** 订单取消(支付超时取消)
     * @param $orderNo 订单编号
     * @return array 取消结果
     */
    public function orderPayOutCancel($orderNo)
    {
        $orderModel = new OrderModel();
        $orderInfo = $orderModel->where(array('order_no' => $orderNo))->find();
        if (!$orderInfo) {
            return $this->returnJson(array('code' => \Consts::PARAMES_ERROR, 'message' => '订单编号不存在'));
        }
        if ($orderInfo['state'] == \Consts::ORDER_CLOSE) {
            return $this->returnJson(array('code' => \Consts::PARAMES_ERROR, 'message' => '订单已超时关闭'));
        }

        $data = array(
            'order_no' => $orderNo,
            'id' => $orderInfo['id'],
            'updatetime' => time(),
            'state' => \Consts::ORDER_CLOSE,
            'back_type' => \Consts::CANCEL_NOT,
        );

        $dataDetail = array(
            'order_no' => $orderNo,
            'state' => \Consts::ORDER_CLOSE,
            'back_type' => \Consts::CANCEL_NOT,
            'createtime' => time(),
        );

        M()->startTrans();
        $result = $orderModel->save($data);
        $orderDetailModel = D('Orderdetail');
        $resultOrderDetail = $orderDetailModel->add($dataDetail);
        if ($result && $resultOrderDetail) {
            //订单优惠券状态由冻结恢复为正常
            D('usercoupon')->where(array('user_id' => $orderInfo['user_id'], 'order_no' => $orderNo))->save(array('status' => 1));
            $code = \Consts::REQUEST_SUCCESS;
            M()->commit();
        } else {
            $code = \Consts::REQUEST_ERROR;
            M()->rollback();
        }
        return $this->returnJson(array('code' => $code, 'order_no' => $orderNo));
    }


}
