<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/5/9
 * Time: 12:50
 */

namespace Api\Controller;


use Common\Model\UserModel;

class LoginController extends ApiBaseController
{
    /** 用户登录
     * @param string $openid
     * @param string $telphone
     * @param string $username
     * @param string $headImg
     * @return mixed
     */
    public function login($openid='', $telphone='', $username='',$headImg='https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=209621737,1953850165&fm=26&gp=0.jpg'){
        $userModel = new UserModel();
        $result =   $userModel->login($openid,$telphone,$username,$headImg);
        return $result;
    }
}
