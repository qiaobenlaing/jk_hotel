<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/7/17
 * Time: 13:33
 */

namespace Api\Controller;


use Common\Model\CouponModel;

class CouponController extends ApiBaseController
{


    //测试新增优惠券(免费体验券--平台券)
    public function demoTest()
    {

        $couponModel = new CouponModel();
        $data = array(
            'coupon_name' => '免费体验券',
            'coupon_code' => $couponModel->create_uuid(),
            'coupon_belonging' => 2,
            'coupon_type' => 6,
            'total_volume' => 100,
            'batch_nbr' => '062022',
            'remaining' => 100,
            'remark' => json_encode(
                array(
                    'title' => '这一生无论奋斗还是荣耀，我们都要高尚的活着；在金恪旅居，尽享人生所有。',
                    'rule' => array(
                        '1.此体验券不兑换现金，可免费抵扣一晚的房费',
                        '2.仅限本人使用及每人使用一张'
                    )
                ), JSON_UNESCAPED_UNICODE),
            'expire_time' => time() + 60 * 60 * 24 * 30 * 6,
            'start_taking_time' => time() - 60 * 60 * 24,
            'end_taking_time' => time() + 60 * 60 * 24 * 30 * 5,
            'function' => '免费入住一晚的任何酒店的房间',
            'validity_period' => 0
        );
        $vo = $couponModel->create($data);
        if (!$vo) {
            $error = $couponModel->getError();
            return $this->returnJson(array('code' => \Consts::REQUEST_ERROR, 'message' => $error));
        } else {
            $result = $couponModel->add($vo);
            if ($result) {
                $code = \Consts::REQUEST_SUCCESS;
            } else {
                $code = \Consts::REQUEST_ERROR;
            }
            return $this->returnJson(array('code' => $code));
        }
    }

    //测试新增优惠券(抵扣券--平台券)
    public function demoTest2()
    {
        $couponModel = new CouponModel();
        $data = array(
            'coupon_name' => '50元抵扣券',
            'coupon_code' => $couponModel->create_uuid(),
            'coupon_belonging' => 2,
            'coupon_type' => 3,
            'total_volume' => 100,
            'batch_nbr' => '062022',
            'remaining' => 100,
            'remark' => json_encode(
                array(
                    'title' => '这一生无论奋斗还是荣耀，我们都要高尚的活着；在金恪旅居，尽享人生所有。',
                    'rule' => array(
                        '1.该券可抵扣等值人民币房费',
                        '2.仅限本人使用及每人使用一张'
                    )
                ), JSON_UNESCAPED_UNICODE),
            'expire_time' => time() + 60 * 60 * 24 * 30 * 6,
            'start_taking_time' => time() - 60 * 60 * 24,
            'end_taking_time' => time() + 60 * 60 * 24 * 30 * 5,
            'instead_price' => 5000,
            'available_price' => 40000,
            'is_consume_required' => 1,
            'function' => '抵扣50元等值房费',
            'validity_period' => 0
        );
        $vo = $couponModel->create($data);
        if (!$vo) {
            $error = $couponModel->getError();
            return $this->returnJson(array('code' => \Consts::REQUEST_ERROR, 'message' => $error));
        } else {
            $result = $couponModel->add($vo);
            if ($result) {
                $code = \Consts::REQUEST_SUCCESS;
            } else {
                $code = \Consts::REQUEST_ERROR;
            }
            return $this->returnJson(array('code' => $code));
        }
    }

    /**
     * 测试发券
     */
    public function sendUser(){
     $arr =  D('Coupon')->where(array('id'=>2))->find();
       for ($i=0;$i<10;$i++){
           $data[]= array(
               'user_id' => 35,
               'coupon_id' => $arr['id'],
               'apply_time' => time(),
               'status' => 1,
               'start_using_time'=> $arr['start_using_time'],
               'expire_time'=>$arr['expire_time'],
           );
       }
        D('usercoupon')->addAll($data);
    }

    /** 获取用户的优惠券列表
     * @param $user_id 用户编号
     * @param $page 分页
     * @param $page_size 每页条数
     */
    public function userCouponList($user_id, $page, $page_size)
    {
        if ($page < 1) $page = 1;
        if ($page_size == '') self::$PAGE_SIZE = $page_size;

        $userCouponModel = D('usercoupon');
        $where = array('user_id' => $user_id, 'status' => 1);
        $count = $userCouponModel->where($where)->field('id')->count();
        $list = $userCouponModel->where($where)->alias('UC')->join('tns_coupon as C ON C.id=UC.coupon_id')
            ->field('coupon_img,coupon_name,function,UC.start_using_time,UC.expire_time,validity_period,coupon_type,remaining,
            hotel_ids,is_universal,remark,discount_percent,instead_price,coupon_code,limited_nbr')
            ->limit($pageOffSet = ($page - 1) * self::$PAGE_SIZE, self::$PAGE_SIZE)->select();

        foreach ($list as $item => &$value) {
            //1.判断优惠券有效期
            if ($value['validity_period'] != \Consts::VALIDE_NEVER) {
                if ($value['start_using_time'] > time()) { //未到可用时间
                    unset($list[$item]);
                    $count--;
                    continue;
                }
                if ($value['expire_time'] < time()) { //已过期
                    unset($list[$item]);
                    $count--;
                    continue;
                }
            }
            //判断优惠券数量
            if ($value['remaining'] < 1 && $value['remaining'] != -1) {
                unset($list[$item]);
                $count--;
                continue;
            }

            $value['remark'] = json_decode($value['remark'], true);
            $value['expire_time'] = toDate($value['expire_time'], 'Y-m-d');
            $value['start_using_time'] = toDate($value['start_using_time'], 'Y-m-d');
        }

        if ($count % self::$PAGE_SIZE == 0) {
            $totalPage = $count / self::$PAGE_SIZE;
        } else {
            $totalPage = intval(($count / self::$PAGE_SIZE) + 1);
        }

        $result = array(
            'count' => $count,
            'totalPage' => $totalPage,
            'couponList' => $list,
            'pageSie' => self::$PAGE_SIZE,
            'page' => $page
        );
        if ($count < 1) {
            return $this->returnJson(array('code' => \Consts::REQUEST_SUCCESS, 'message' => '暂无可用优惠券'));
        } else {
            return $this->returnJson(array('code' => \Consts::REQUEST_SUCCESS, 'info' => $result, 'message' => '获取优惠券列表成功'));
        }

    }

    /** 优惠券列表(提供给内容管理系统的查询优惠券接口)
     * @param $couponType 优惠券类型
     * @param $page 当前页
     * @param $page_size 每页显示条数
     */
    public function couponList($couponName, $couponDesc, $pageNo, $pageSize)
    {
        if ($pageNo < 1) $pageNo = 1;
        if ($pageSize == '') self::$PAGE_SIZE = $pageSize;
        //前置必须条件
        $where = array(
            'expire_time' => array('gt', time()),
            'start_using_time' => array('lt', time()),
            'remaining' => array(array(array('egt', 1), array('neq', -1), 'or'), array('eq', -1), 'or'),
            'coupon_name' => array('like', '%' . $couponName . '%'),
            'function' => array('like', '%' . $couponDesc . '%'),
        );

        $couponModel = new CouponModel();
        $count = $couponModel->where($where)->field('id')->count();
        $couponList = $couponModel->where($where)->limit($pageOffSet = ($pageNo - 1) * self::$PAGE_SIZE, self::$PAGE_SIZE)->select();

        $dataList = array();
        foreach ($couponList as $item => $value) {
            $data = array();
            $data['couponId'] = $value['id'];
            $data['couponName'] = $value['coupon_name'];
            $data['couponDesc'] = $value['function'];
            $data['total'] = $value['total_volume'];
            $data['type'] = $value['coupon_type'];
            $dataList[] = $data;
        }

        if (count($dataList) < 1 && $pageNo > 1) {
            return $this->returnJson(array('code' => \Consts::REQUEST_SUCCESS, 'message' => '没有更多了'));
        }
        if ($count % self::$PAGE_SIZE == 0) {
            $totalPage = $count / self::$PAGE_SIZE;
        } else {
            $totalPage = intval(($count / self::$PAGE_SIZE) + 1);
        }
        $result = array(
            'total' => $count,
            'totalPage' => $totalPage,
            'couponList' => $dataList,
        );
        if ($count < 1) {
            return $this->returnJson(array('code' => \Consts::REQUEST_SUCCESS, 'message' => '暂无相关优惠券'));
        } else {
            return $this->returnJson(array('code' => \Consts::REQUEST_SUCCESS, 'info' => $result, 'message' => '获取优惠券列表成功'));
        }
    }


    /** 用户免费领取(提供给内容管理系统的优惠券派发接口)
     * @param $user_id 用户编号
     * @param $couponId 优惠券编号
     * @return array 返回结果
     */
    public function sendCoupon($userId, $couponId)
    {
        //判断优惠券是否存在
        $couponModel = new CouponModel();
        $couponArr = implode(',',$couponId);
        $couponList = $couponModel->where(array('id' => array('IN', $couponArr)))->field('id,start_using_time,expire_time,send_type')->select();
        if (!$couponList) {
            return $this->returnJson(array('code' => \Consts::PARAMES_ERROR, 'message' => '未找到相关优惠券信息'));
        }
        $userArr = $userId;
        $dataList = array();
        foreach ($userArr as $item => $value) {
            foreach ($couponList as $ite => $couponInfo) {
                //领取优惠券
                $data = array(
                    'user_id' => $value,
                    'coupon_id' => $couponInfo['id'],
                    'apply_time' => time(),
                    'start_using_time' => $couponInfo['start_using_time'],
                    'expire_time' => $couponInfo['expire_time'],
                    'send_type' => $couponInfo['send_type'],
                    'status' => 1,
                );
                $dataList[]= $data;
            }
        }

        $result = D('usercoupon')->addAll($dataList);
        if ($result) {
            $code = \Consts::REQUEST_SUCCESS;
        } else {
            $code = \Consts::REQUEST_ERROR;
        }
        return $this->returnJson(array('code' => $code));
    }

    /** 用户使用优惠券
     * @param $user_id 用户编号
     * @param $coupon_code 优惠券编号
     * @param $order_no 订单编号（在哪笔订单中用到优惠券）
     * @return array 返回结果
     */
    public function useCoupon($user_id, $coupon_code, $order_no)
    {
        $couponModel = new CouponModel();
        $couponInfo = $couponModel->where(array('coupon_code' => $coupon_code))->find();
        if (!$couponInfo) {
            return $this->returnJson(array('code' => \Consts::PARAMES_ERROR, 'message' => '优惠券未找到'));
        }
        $userCouponModel = D('usercoupon');
        $result = $userCouponModel->where(array('user_id' => $user_id, 'coupon_id' => $couponInfo['id']))->find();
        if ($result['status'] == 2) {
            return $this->returnJson(array('code' => \Consts::PARAMES_ERROR, 'message' => '您已使用过该优惠券'));
        }
        if ($result['status'] == 1) {
            $data['order_no'] = $order_no;
            $data['used_time'] = time();
            $data['status'] = 2;
            $res = $userCouponModel->where(array('id' => $result['id']))->save($data);
            if ($res) {
                return $this->returnJson(array('code' => \Consts::REQUEST_SUCCESS));
            } else {
                return $this->returnJson(array('code' => \Consts::REQUEST_ERROR));
            }
        } else {
            return $this->returnJson(array('code' => \Consts::PARAMES_ERROR, 'message' => '未找到可使用的优惠券'));
        }
    }

}
