<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/4/11
 * Time: 16:01
 */

namespace Api\Controller;

use Think\Controller\JsonRpcController;
include_once 'Application/Common/Conf/const.php';
class ApiBaseController extends JsonRpcController
{
    protected static $PAGE_SIZE = 10;

    public function __construct()
    {
        parent::__construct();
        // 确保jsonrpc后面不被挂上一堆调试信息。
        C('SHOW_PAGE_TRACE', false);
    }

    public function returnJson($info)
    {
        if ($info['code'] == \Consts::REQUEST_SUCCESS) {
            return array_merge($info, array('result_code' => \Consts::REQUEST_SUCCESS, 'message' => $info['message'] == '' ? '请求接口成功' : $info['message']));
        } elseif ($info['code'] == \Consts::REQUEST_ERROR) {
            return array_merge($info, array('result_code' => \Consts::REQUEST_SUCCESS, 'message' => $info['message'] == '' ? '请求接口失败' : $info['message']));
        } else {
            return array_merge($info, array('result_code' => \Consts::PARAMES_ERROR, 'message' => $info['message']));
        }
    }

    function curlRequest($url, $params = array(), $is_post = false, $time_out = 10, $header = array())
    {
        $str_cookie = isset($ext_params['str_cookie']) ? $ext_params['str_cookie'] : '';
        $ch = curl_init();//初始化curl
        curl_setopt($ch, CURLOPT_URL, $url);//抓取指定网页
        curl_setopt($ch, CURLOPT_HEADER, 0);//设置是否返回response header
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);//要求结果为字符串且输出到屏幕上
        //当需要通过curl_getinfo来获取发出请求的header信息时，该选项需要设置为true
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, $time_out);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $time_out);
        curl_setopt($ch, CURLOPT_POST, $is_post);
        if ($is_post) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
        }
        if ($str_cookie) {
            curl_setopt($ch, CURLOPT_COOKIE, $str_cookie);
        }
        if ($header) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        }
        $response = curl_exec($ch);
        //打印请求的header信息
        $request_header = curl_getinfo($ch, CURLINFO_HEADER_OUT);
        curl_close($ch);
        return $response;
    }
}
