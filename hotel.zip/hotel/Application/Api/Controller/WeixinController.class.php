<?php
/**
 * Created by PhpStorm.
 * User: 98041
 * Date: 2020/7/7
 * Time: 17:47
 */

namespace Api\Controller;


use Common\Model\OrderModel;
use Common\Model\RoomStateModel;
use Think\Controller;

class WeixinController extends Controller
{

    /**会员卡退款
     */
    public function refund()
    {
        $xmls = file_get_contents('php://input');
        $jsonArr = json_decode($xmls,true);
        $orderNo = $jsonArr['data']['outRefundNo'];

        if($jsonArr['status']!='ok'){
            exit();
        }

        $orderModel = new OrderModel();
        $orderInfo = $orderModel->where(array('order_no' => $orderNo))->find();

        $usercouponModel =  D('usercoupon');
        $list =   $usercouponModel->where(array('order_no'=>$orderNo))->field('id')->select();
        $arr = array();
        foreach ($list as $item =>$value){
            $arr[] = $value['id'];
        }
        if($arr){
            $usercouponModel->where(array('id'=>array('IN',$arr)))->save(array('status'=>1,'used_time'=>0));
        }

        M()->startTrans();
        $dataOrder = array(
            'id' => $orderInfo['id'],
            'state' => \Consts::ORDER_CONFIRM_FAIL,
            'back_type' => \Consts::CANCEL_REFUND,
            'updatetime' => time(),
        );
        //订单详情数据
        $dataDetail = array(
            'order_no' => $orderInfo['order_no'],
            'state' => \Consts::ORDER_CONFIRM_FAIL,
            'back_type' => \Consts::CANCEL_REFUND,
            'createtime' => time(),
        );
        $resultPreOrder = $orderModel->save($dataOrder);
        $resultOrderDetail = D('Orderdetail')->add($dataDetail);
        if ($resultPreOrder && $resultOrderDetail) {
            M()->commit();
        } else {
            M()->rollback();
        }
    }

}
