/*
	说明：
		+ 该JS文件依赖Jquery1.11.0 和 layer-v3.0.1

	书写规范：
		+ 函数名称第一个字母，和不同英文单词第一个字符统一大写
*/
function side_menu(){
    w = $(".sidemenu").width();
    if(w >= 170){
        $('.sidemenu').css('width',0);
        $('.sidemain').css('padding-left',0);
    }else{
        $('.sidemenu').css('width',170);
        $('.sidemain').css('padding-left',170);
    }
}

// 点击选中
$(".sidemenu li").each(function(){

    $(this).click(function() {
        $(".sidemenu li").each(function(){
            $(this).attr("class","");
        });
        $(this).attr("class","sli");
    });
});

//显示或者关闭
function set_menu_open_close(obj){
    obj_dis = $(obj+"_box").css("display");
    if(obj_dis == "none"){
        $(obj+"_box").show(100);
        $(obj).attr("class","sidemenu_title icon-angle-up");
    }else{
        $(obj+"_box").hide(100);
        $(obj).attr("class","sidemenu_title icon-angle-down");
    }
}

//取得str2 的 value 填充 str1
function sel(str1,str2){document.all(str1).value = document.all(str2).options[document.all(str2).selectedIndex].text;}

//提示 + 加载隐藏的列表页，用于修改+刷新分页
var AlertLoad = function(json,setid){
    layer.msg(json.info, {
        time: 2000,
        shade: [0.5, '#666'],
        icon:json.status
    });
    //alert(json.info,json.status);
    if(json.status==1){
        $(setid).load($(setid+"PageUrl").val());
    }
}

//提示 + 重置表单，适合添加内容，单纯修改
var AlertReset = function(json){
    layer.msg(json.info, {
        time: 1000,
        shade: [0.5, '#666'],
        icon:json.status
    });
    //alert(json.info,json.status);
    if(json.status==1){
        s();
    }

}


//清空FORM表单中的内容
var s = function(){
    var count = document.getElementsByTagName("form").length;
    for (i=0;i<count;i++){
        document.forms[i].reset();
    }
    // 清除UI框架提示
    $('.form-reset').closest('form').find(".input-help").remove();
    $('.form-reset').closest('form').find('.form-submit').removeAttr('disabled');
    $('.form-reset').closest('form').find('.form-group').removeClass("check-error");
    $('.form-reset').closest('form').find('.form-group').removeClass("check-success");
}


// a name 书签跳转效果
function aname(values){
    window.location.href="#"+values;
}
/*
	说明：
		+ Ajax类型JS函数
*/
//取得页面内容
function GetView(id,url){

    $(id).html(''); //先清空，再赋值内容
    $.get(url,function(result){
        $(id).html(result);
    }, 'html');
}

//提交AJAX
var checkAjax = function(url,postData,id){
    $.post(url,postData,function(json){$(id).html(json.info);},'json');
}

//提交AJAX
var DelAjax = function(url,date,setid){
    $.post(url,date,function(json){AlertLoad(json,setid);},'json');
}

// AjaxPost 提示 + 重置表单
var AjaxPostAlertReset = function(formName,title){
        confirm(title,function(){
            var postData = $(formName).serialize();
            var url = $(formName).attr('action');
            $.post(url,postData,function(jsons){AlertReset(jsons);},'json');
        });
}

// AjaxPost 提示 + 加载隐藏链接
var AjaxPostAlertLoad = function(formName,title,setid){
        confirm(title,function(index){
            var postData = $(formName).serialize();
            var url = $(formName).attr('action');
            $.post(url,postData,function(jsons){AlertLoad(jsons,setid);},'json');
        });
}

// AjaxGet 提交 + 加载返回HTML文件
var AjaxGetHtml = function(formName,setid){
        var postData = $(formName).serialize();
        var url = $(formName).attr('action');
        $(setid).html("");
        $.get(url,postData,function(jsons){$(setid).html(jsons);},'html');
}
/**
 + HTML功能类型JS函数
 */
//功能：多选筐全选/反选
var CheckAll = function(form)  {
    for (var i=0;i<form.elements.length;i++)
    {
        var e = form.elements[i];
        if (e.name != 'chkall'&&e.type=="checkbox")
        {
            e.checked = form.chkall.checked;
        }
    }
}
//验证整数
function isInt(obj){
  var  text = obj.value;
   var num = parseInt(text);
    if(text.length>0){
        if(isNaN(num)){
            obj.value = 0;
        }else{
            obj.value = num;
        }
    }
    if(text<0){
        obj.value = 0;
    }
}

//默认获取当前日期，转换格式YYYY-MM-DD
function getNowFormatDate(date) {
    if (date == '' || date == undefined) {
        date = new Date();
    }
    var seperator1 = "-";
    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var strDate = date.getDate();
    if (month >= 1 && month <= 9) {
        month = "0" + month;
    }
    if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
    }
    var currentdate = year + seperator1 + month + seperator1 + strDate;
    return currentdate;
}

//保留两位小数
//功能：将浮点数四舍五入，取小数点后2位
function toDecimal(obj) {
    var f = parseFloat(obj.value);
    if (isNaN(f)) {
        obj.value = 0;
        return;
    }else{
        obj.value = Math.round(f *100)/100;
    }
}

//保留两位小数
//针对房态--现价
function toNowDecimal(obj) {
    var f = parseFloat(obj.value);
    if (isNaN(f)) {
        obj.value = '';
        return;
    }else{
        obj.value = Math.round(f *100)/100;
    }
}

/**
 + 删除类型JS函数
 */
//单条记录删除
function DelId(url,id,setid){
    confirm("删除将不能恢复！确定吗？",function(){
        DelAjax(url,"delId="+id,setid);
    });
}

//批量删除
function Del_All(url,checkBoxName,setid){
    icount = $("input[name='"+checkBoxName+"']:checked").length;
    if(icount<1){
        alert("没有选中删除选项！",5);
        return false;
    }else{
        confirm("您是否确认删除 "+icount+" 条记录？",function(){
            // 生存POST数据
            query = "1=1";
            $("input[name='"+checkBoxName+"']:checked").each(function(len){
                query += "&"+checkBoxName+"="+$(this).val();
            });
            DelAjax(url,query,setid);
        });
    }
}

/**
 + HTML5 上传图片前裁剪,固定尺寸裁剪
 +----------------------------------
 + file            图片来源地址
 + maxWidth        图片来源地址
 + maxHeight        图片来源地址
 + callback        回掉函数
 +----------------------------------
 */
function ImageFileFixed(file, maxWidth, maxHeight, callback) {
    var Img = new Image;
    var canvas = document.createElement('canvas');
    var ctx = canvas.getContext('2d');

    Img.onload = function () {

        //设定画布宽度
        canvas.width = maxWidth;
        canvas.height = maxHeight;

        // 取得图片缩放尺寸
        var img_width = 0;
        var img_height = 0;
        if (Img.width > maxWidth || Img.height > maxHeight) {
            var bili = Math.min(Img.width / maxWidth, Img.height / maxHeight);
            img_width = Img.width / bili;
            img_height = Img.height / bili;
        } else {
            img_width = Img.width;
            img_height = Img.height;
        }

        //取得图片剧中位置
        var width_left = 0;
        var heightt_top = 0;

        if (img_width > maxWidth) {
            width_left = -(img_width - maxWidth) / 2;
        }
        if (img_height > maxHeight) {
            heightt_top = -(img_height - maxHeight) / 2;
        }

        //执行裁剪
        ctx.drawImage(Img, width_left, heightt_top, img_width, img_height);

        //返回裁剪数据
        callback(canvas.toDataURL());
    };

    try {
        Img.src = window.URL.createObjectURL(file);
    } catch (err) {
        try {
            Img.src = window.webkitURL.createObjectURL(file);
        } catch (err) {
            $.toast(err.message, "forbidden");
        }
    }
}

// 重写 alert 提示
window.alert = function(str,icon,callback)
{
    // 第二个函数判断
    if(typeof icon === "function") {
        callback = icon;
    }

    // 默认提示图标
    if(parseInt(icon)!=icon || icon < 1){
        icon = 6;
    }
    // 弹出对话框
    layer.alert(
        str,
        {
            icon: icon,
            title:"提示",
            success:function(layero,index)
            {
                $(document).on('keydown', function(e){
                    if(e.keyCode == 13){
                        $("a.layui-layer-btn0").click();
                        layer.close(index);

                    }

                    if(e.keyCode == 27){
                        layer.close(index);
                    }

                    $(document).unbind('keydown');
                    e.preventDefault();
                })
            }
        },
        function(index)
        {
            if(typeof callback === "function") {
                callback();
            }else{
                layer.close(index);
            }
        }
    );
}

// 重写 confirm 提示
window.confirm = function(str,callback)
{
    layer.confirm(str,
        {
            icon: 3,
            title:"是否确认？",
            success: function(layero,index){

                $(document).bind('keydown', function(e){
                    if(e.keyCode == 13 ){
                        $("a.layui-layer-btn0").click();
                        layer.close(index);
                        $(document).unbind('keydown');
                        e.preventDefault();
                    }

                    if(e.keyCode == 27 ){
                        $("a.layui-layer-btn1").click();
                        layer.close(index);
                        $(document).unbind('keydown');
                        e.preventDefault();
                    }
                });


            }
        },
        function(index)
        {
            if(typeof callback === "function") {
                callback();
            }else{
                layer.close(index);
            }
        }

    );
}
